﻿	var browserLang = window.navigator.language || window.navigator.userLanguage || window.navigator.browserLanguage || window.navigator.systemLanguage; // get the browsers language
	var locales = ['en-US', 'fr']; 						// available locale files
	var locale = 'en-US'; 								// default locale

	// check browser language against available locale files
	for (var i = locales.length - 1; i >= 0; i--) {		//check if the locale file is available
		if (browserLang === locales[i]) {
			locale = browserLang;						//assign browser language to the variable locale
			break;
		}
	};
	console.log(locale);
	//even if locale isn't available, we have set en-US value in the locale variable
	extlocale.src='locale/ext-lang-' + locale + '.js';	//fetch the respective locale file from locale folder
	
	//new implementation - inject script ---------------ASYNCHRONOUS APPROACH ----------RISKY
/*	var s = document.createElement('script');
	s.type = 'text/javascript';
	s.async = false;
	s.src = 'locale/ext-lang-' + locale + '.js';
	console.log('injecting script');
	document.getElementsByTagName('head')[0].appendChild(s);
*/	
	//inject script------------------------------------SYNCHRONOUS APPROACH---------------guarantees locale file is loaded before all-classes.js
	// get some kind of XMLHttpRequest
	//var xhrObj = createXMLHTTPObject();
	/*var xmlHttpReq = false;
    var self = this;
    // Mozilla/Safari
    if (window.XMLHttpRequest) {
        self.xmlHttpReq = new XMLHttpRequest();
    }
    // IE
    else if (window.ActiveXObject) {
        self.xmlHttpReq = new ActiveXObject("Microsoft.XMLHTTP");
    }
    //self.xmlHttpReq.open('POST', strURL, true);
	// open and send a synchronous request
	self.xmlHttpReq.open('GET', "locale/ext-lang-" + locale + ".js", false);
	self.xmlHttpReq.send('');
	// add the returned content to a newly created script tag
	var se = document.createElement('script');
	se.type = "text/javascript";
	se.text = self.xmlHttpReq.responseText;
	console.log(document.getElementsByTagName('head')[0]);document.getElementsByTagName('head')[0].appendChild(se);
	*/
	//adding sencha script
	var s = document.createElement('script');
	s.type = 'text/javascript';
	s.async = false;
	s.src = 'all-classes.js';
	console.log('injecting script');
	document.getElementsByTagName('head')[0].appendChild(s);
	
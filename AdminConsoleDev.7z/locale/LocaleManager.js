﻿var browserLang = window.navigator.language || window.navigator.userLanguage || window.navigator.browserLanguage || window.navigator.systemLanguage; // get the browsers language
  //var locales = ['en-US', 'fr']; // available locale files
  //var locale = 'en-US'; // default locale

  // check browser language against available locale files
  /*for (var i = locales.length - 1; i >= 0; i--) { //check if the locale file is available
    if (browserLang === locales[i]) {
      locale = browserLang; //assign browser language to the variable locale
      break;
    }
  };
  console.log(locale);*/
  function getCookie(cname) {
      var name = cname + "=";
      var ca = document.cookie.split(';');
      for(var i=0; i<ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1);
        if (c.indexOf(name) == 0) return c.substring(name.length,c.length);
      }
      return "";
  }
  function myFunction(loc){
    loc=loc.toLowerCase();
      //alert('my fun'); 
    if(loc=='EN'|| loc=='en'){
		loc='en-US';
    }
    document.cookie = "myLocale="+loc+";path=/"; 
    window.location.reload();
    }


    var myLocale=getCookie('myLocale');
    if(myLocale==""){
     document.cookie = "myLocale="+browserLang+";path=/";
      extlocale.src='locale/ext-lang-en-US.js'; 
    }
    else{
    
      extlocale.src='locale/ext-lang-' + myLocale + '.js'; //fetch the respective locale file from locale folder
      
    }
   
   
  
  var s = document.createElement('script');
  s.type = 'text/javascript';
  s.async = false;
  s.src = 'all-classes.js';
  console.log('injecting script');
  document.getElementsByTagName('head')[0].appendChild(s); 
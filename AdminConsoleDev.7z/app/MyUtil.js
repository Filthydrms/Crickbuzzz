Ext.define("AdminConsole.MyUtil", {
singleton : true,
requires:['Ext.window.Window'],
myFlag:false,
logg : function(text) {
	console.log(text);
},
decodeAction:function(code){
	if(code=='0'){
	//User is logged successfully and token is generated
		return "success";
	}
	if(code=='1'){
	//User authentication fail because of invalid user name or password
		console.log("invalid username or password");
		return "fail";
	}
	if(code=='2'){
	//Token is in valid  (session expired)
		Ext.Msg.alert('','Session expired. Please re-login to continue',function(){
																				//Ext.Router.redirect('');
																				Ext.Router.redirect('login/'+Ext.util.Cookies.get('tenant'));
																			});
	}
	if(code=='3'){
	//Token not received or Token does not exist
		Ext.Msg.alert('','Session expired. Please re-login to continue',function(){
																				//Ext.Router.redirect('');
																				Ext.Router.redirect('login/'+Ext.util.Cookies.get('tenant'));
																			});
	}
	if(code=='4'){
	//first login
		console.log('>>>>>>>>>>>>>redirecting to reset password');
		Ext.Router.redirect('resetPassword');
	}
	if(code=='1001'){
		Ext.Msg.alert('','System Error Occurred. Please contact adminsitrator.');
	}
	if(code=='5'){
		Ext.Msg.alert('','Your account has been disabled. Please contact administrator.');
	}
	if(code=='6'){
		Ext.Msg.alert('','Your account has been locked. Please contact administrator.');
	}
	if(code=='7'){
		console.log('>>>>>>>>>>>>>redirecting to home');
		Ext.Msg.alert('','Sorry! This service is not provisioned to you.',function(){
																						//Ext.Router.redirect('');
																						Ext.Router.redirect('login/'+Ext.util.Cookies.get('tenant'));
																				});
		//Ext.Router.redirect('');
	}
	//temporary
	if(code=='success'){
	//User is logged successfully and token is generated
		return "success";
	}
},
//This method decodes the response send by backe-end system(e.g. team center).
backendSystemResponseDecodeAction:function(code){
		if(code=='000'){
			return AdminConsole.Constants.STATUS_SUCCESS;
		}else if(code=='001'){
			Ext.Msg.alert(fetch.label.error,fetch.label.invalidURL);
			return fetch.label.BACKEND_SYSTEM_ERROR;
		}else if(code=='002'){
			Ext.Msg.alert(fetch.label.error,fetch.label.invalidCredentials);
			return fetch.label.BACKEND_SYSTEM_ERROR;
		}else if(code=='003'){
			Ext.Msg.alert(fetch.label.error,fetch.label.unknownError);
			return fetch.label.BACKEND_SYSTEM_ERROR;
		}else if(code=='000A'){
			return AdminConsole.Constants.STATUS_SUCCESS;
		}else if(code=='001A'){
			Ext.Msg.alert(fetch.label.error,fetch.label.invalidCommodityRootClassId);
			return fetch.label.BACKEND_SYSTEM_ERROR;
		}else if(code=='002A'){
			Ext.Msg.alert(fetch.label.error,fetch.label.invalidClassStatusRootClassId);
			return fetch.label.BACKEND_SYSTEM_ERROR;
		}else if(code=='003A'){
			Ext.Msg.alert(fetch.label.error,fetch.label.invalidContRoleRootClassId);
			return fetch.label.BACKEND_SYSTEM_ERROR;
		}else if(code=='004A'){
			Ext.Msg.alert(fetch.label.error,fetch.label.unknownError);
			return fetch.label.BACKEND_SYSTEM_ERROR;
		}else if(code=='000L'){
			return AdminConsole.Constants.STATUS_SUCCESS;
		}else if(code=='001L'){
			Ext.Msg.alert(fetch.label.error,fetch.label.invalidCommodityRootClassIdLoad);
			return fetch.label.BACKEND_SYSTEM_ERROR;
		}else if(code=='002L'){
			Ext.Msg.alert(fetch.label.error,fetch.label.invalidClassStatusRootClassIdLoad);
			return fetch.label.BACKEND_SYSTEM_ERROR;
		}else if(code=='003L'){
			Ext.Msg.alert(fetch.label.error,fetch.label.invalidContRoleRootClassIdLoad);
			return fetch.label.BACKEND_SYSTEM_ERROR;
		}else if(code=='004L'){
			Ext.Msg.alert(fetch.label.error,fetch.label.unknownError);
			return fetch.label.BACKEND_SYSTEM_ERROR;
		}else{
			return AdminConsole.Constants.STATUS_FAIL;
		}
},

authenticate:function(){
//NOT USED
	console.log('inside AdminConsole.MyUtil.authenticate');
		Ext.Ajax.request({
		url:'/supcon-supplier-mgmt/authenticateUser.htm',
		method:'GET',
		success:function(response){
		console.log('response.responseText :'+response.responseText);
			if(response.responseText==="success"){
				console.log('User is logged in');
				return true;
			}else{
				console.log('User is not logged in');
				return false;
			}
		}
	});

	console.log("result value : "+result)
	return result;
},
popup:Ext.create("Ext.Window",{
			    //title : 'Supplier Details',
				style:{
					//'border':' 1px #dadada solid',
					'font-size':13, 
					'font-family':'Verdana, Geneva, sans-serif', 
					'color':'#000000', 
					//'border-radius': '25px',
					'box-shadow': '0 0 20px rgba(0, 0, 0, 0.3)'
				},				
				//hideHeaders:true,
			    closable : true,
			    modal : true,
				scrollable:true,
				id:'supconpopup',
				//layout:'auto',
				layout:{					
					type : 'vbox',
					align : 'center'
				},
			    listeners:{
			    	beforeclose: function( win, eOpts ){
						win.removeAll();
						win.hide();
						return false;
			    	}
				}
			}),
showPopUp:function(panel,title){
	//popup.add(panel);
	var me = this;
	//console.log(panel);
	me.popup.setTitle(title);
	me.popup.add(panel);
	me.popup.show();
},
hidePopUp:function(){
	var me = this;
	me.popup.close();
},
mask:null,
showMask: function(targetCmp,message){
	var me = this;
	me.mask = new Ext.LoadMask({target:targetCmp, msg:message}),
	me.mask.show();
	//Ext.getBody().mask().dom.style.zIndex = '999999';
},

hideMask: function(){
	var me = this;
	me.mask.hide();
},
checkAuthorisationOnButton : function(action, callback){
	var url = AdminConsole.Constants.baseURL+'/oem/authenticateUser.htm';
	Ext.Ajax.request({
		url:url,
		method:'GET',
		isSynchronous : true,
		params:{screenCode:action},
		success:function(response){
			console.log('response.responseText :'+response.responseText);
				if(response.responseText==="success"){
					console.log('User is logged in');
					callback(true);				
				}else{
					console.log('Access denied');		
					Ext.Msg.alert('error',response.responseText);
					callback(false);					
				}
		}
	});
}

});

Ext.define('AdminConsole.store.AssignTeamStore', {
    extend: 'Ext.data.Store',

  
    storeId: 'AssignTeamStore',
		fields : [{
				name : 'userId',
			   
			}, {
				name : 'userName',
				
			}, {
				name : 'role',
				
			},
			{
				name : 'approver',
				
			},
			{
				name : 'assigned',
				
			}
		]
        
        
    
});
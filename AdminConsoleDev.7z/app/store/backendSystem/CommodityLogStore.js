Ext.define('AdminConsole.store.backendSystem.CommodityLogStore', {
    extend: 'Ext.data.Store',
	requires: [
        'AdminConsole.model.CommodityLogModel'
    ],
	autoLoad:false,
	storeId: 'CommodityLogStore',
	model:'AdminConsole.model.CommodityLogModel',
	proxy: {
        type: 'memory',
        reader: {
            type: 'json',
			root: ''
        }
    }	
});
Ext.define('AdminConsole.store.AvailbleServiceStore', {
    extend: 'Ext.data.Store',  
		autoLoad:true,
        storeId: 'AvailbleServiceStore',
			
		fields: [
                {
                    name: 'id'
                },
                {
                    name: 'servicename'
                },
                {
                    name: 'url'
                },
				
                
            ],
	
});
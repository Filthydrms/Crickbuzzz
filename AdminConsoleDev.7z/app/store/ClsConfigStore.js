Ext.define('AdminConsole.store.ClsConfigStore',{
extend:'Ext.data.Store',
requires:[
'AdminConsole.model.ClsConfigModel'
],
storeId:'clsConfigStore',
model:'AdminConsole.model.ClsConfigModel',
							
							data : [
								{"Id":"1", "Value":"1"},
								{"Id":"2", "Value":"2"},
								{"Id":"3", "Value":"3"},
								{"Id":"4", "Value":"4"}								 
							]
							});
Ext.define('AdminConsole.store.QueryActionStore', {
    extend: 'Ext.data.Store',  
		autoLoad:false,
        storeId: 'QueryActionStore',
			
		fields: [
                
                {
                    name: 'screenCode'
                },
                {
                    name: 'screenName'
                },
                
            ],
		pageSize :5,	
		proxy:{
			type:'ajax',
			headers: {'Accept':'application/json' },
			url:AdminConsole.Constants.baseURL, 
			actionMethods: {
				create : 'POST',
				read   : 'POST',//default is get
				update : 'POST',
				destroy: 'POST'
			},
			api:{		
				read:AdminConsole.Constants.baseURL +'/oem/searchAction.htm'	
				//read:'queryResponse.json'
			},
			reader:{
				type:'json',
				root:'searchResult',
				totalProperty:'totalCount' 
			},
			timeout:180000
	
		},
		listeners: {
        load: function( me, records, successful, eOpts) {
           if(successful){			
				AdminConsole.MyUtil.decodeAction(me.getProxy().getReader().rawData);
        	   console.log("ActionStore: "+records.length+" records loaded successfully.");			  
			   console.log("me.getProxy().getReader().rawData : "+me.getProxy().getReader().rawData);
        	   }
           else{
        	   me.sync();
        	   console.log("SupplierStore: data load failed");
           }
		    AdminConsole.MyUtil.hideMask();
        },
        beforeload: function(store, operation,eOpts){
	        console.log("-------------operation---------------");
            if(operation.action=='read'){
				console.log(operation);				
				// update disabled filed value
				var formValues=Ext.getCmp('queryActionForm').getValues();				
				var queryData={
				screenCode:formValues.code,
				screenName:formValues.name,
				actionRole:null
				};
				if(operation.params==undefined){
					console.log("data missing -> adding data");
					operation.params={       			
						  data:Ext.JSON.encodeValue(queryData)
					};
				}
			}
		}
		}
});
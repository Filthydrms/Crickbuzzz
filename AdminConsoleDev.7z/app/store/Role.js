Ext.define('AdminConsole.store.Role', {
    extend: 'Ext.data.Store',
	storeId: 'Role',
	//autoLoad:false,
		
	 fields:[

		   {name: 'name'},
		    {name: 'description'}
	],
        
   });
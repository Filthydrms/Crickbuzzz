Ext.define('AdminConsole.store.RoleStore',{
extend:'Ext.data.Store',
requires:[
'AdminConsole.model.RoleModel'
],
storeId:'RoleStore',
model:'AdminConsole.model.RoleModel',
							
							data : [
								{"ID":"1", "Name":"OEM User"},
								{"ID":"2", "Name":"OEM Category Manager"},
								{"ID":"3", "Name":"OEM Administrator"},
																 
							]
							});
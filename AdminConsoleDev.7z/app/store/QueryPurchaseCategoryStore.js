Ext.define('AdminConsole.store.QueryPurchaseCategoryStore', {
    extend: 'Ext.data.Store',  
		
        storeId: 'QueryPurchaseCategoryStore',
			
		fields: [
                {
                    name: 'purCatId'
                },
                {
                    name: 'code'
                },
                {
                    name: 'name'
                },
				{
                    name: 'approver'
                },
                {
                    name: 'status'
                }
            ],
		pageSize :5,	
		proxy:{
			type:'ajax',
			headers: {'Accept':'application/json' },
			url:AdminConsole.Constants.baseURL, 
			actionMethods: {
				create : 'POST',
				read   : 'POST',//default is get
				update : 'POST',
				destroy: 'POST'
			},
			api:{		
				read:AdminConsole.Constants.baseURL +'/oem/searchPurchaseCategory.htm'			
			},
			reader:{
				type:'json',
				root:'searchResult',
				totalProperty:'totalCount' 
			},
			timeout:180000
	
		},
		listeners: {
        load: function( me, records, successful, eOpts) {
           if(successful){			
				AdminConsole.MyUtil.decodeAction(me.getProxy().getReader().rawData);
        	   console.log("SupplierStore: "+records.length+" records loaded successfully.");			  
			   console.log("me.getProxy().getReader().rawData : "+me.getProxy().getReader().rawData);
        	   }
           else{
        	   me.sync();
        	   console.log("SupplierStore: data load failed");
           }
		   AdminConsole.MyUtil.hideMask();
        },
        beforeload: function(store, operation,eOpts){
	        console.log("-------------operation---------------");
            if(operation.action=='read'){
				console.log(operation);
				console.log(operation.params);
				
				// update disabled filed value
				var queryData=Ext.getCmp('queryPCForm').getValues();
				
				// Updating productCategories field
				if(queryData.code==""){
					
					queryData.code=null;
				}
				if(queryData.name==""){
					
					queryData.name=null;
				}
				if(operation.params==undefined){
					console.log("data missing -> adding data");
					operation.params={       			
						  data:Ext.JSON.encodeValue(queryData)
					};
				}
			}
		}
		}
});
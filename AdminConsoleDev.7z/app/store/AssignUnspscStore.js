Ext.define('AdminConsole.store.AssignUnspscStore', {
    extend: 'Ext.data.Store',

    requires: [
      
    ],

    config: {
     
		autoLoad:true,
        storeId: 'AssignUnspscStore',
		fields : [{
				name : 'code',
			    type: 'string' 
			}, {
				name : 'description',
				type: 'string' 
			}
		]
        
        
    }
});
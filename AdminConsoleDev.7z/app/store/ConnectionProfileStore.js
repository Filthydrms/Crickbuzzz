/*No of items per page */
var itemsPerPage = 10;
Ext.define('AdminConsole.store.ConnectionProfileStore', {
    extend: 'Ext.data.Store',

    requires: [
        'AdminConsole.model.ConnectionProfileModel'
    ],
    autoload:false,
	storeId:'conProStore',
	id:'connectionProfileStore',
	model:'AdminConsole.model.ConnectionProfileModel',
    pageSize: itemsPerPage, // items per page

	proxy:{
    	type:'ajax',
    	headers: {'Accept':'application/json' },    	
	    actionMethods: {
	        create : 'POST',
	        read   : 'POST',//default is get
	        update : 'POST',
	        destroy: 'POST'
	    },
    	api:{
		read: AdminConsole.Constants.baseURL +'/oem/getAllConnectionProfiles.htm'		
		},
    	reader:{
			type:'json',
			root:'promSupDTO'	
			//totalProperty:'totalCount' 
		},
		timeout:180000
	
	},
	 listeners: {
        load: function( me, records, successful, eOpts) {
           if(successful){			
			   AdminConsole.MyUtil.decodeAction(me.getProxy().getReader().rawData);
        	   console.log("Connection Profile : "+records.length+" records loaded successfully.");			  
			   console.log("me.getProxy().getReader().rawData : "+me.getProxy().getReader().rawData);
        	   }
           else{
        	   me.sync();
        	   console.log("Connection Profile: data load failed");
           }
        }
        
		}
	}
	
	
);

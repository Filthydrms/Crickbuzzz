Ext.define('AdminConsole.store.Screens', {
    extend: 'Ext.data.Store',
	storeId: 'Screens',
	//autoLoad:false,
		
	 fields:[

		   {name: 'screenCode'},
		   {name: 'screenName'},
		   {name: 'actionRole'}
	],
        
   });
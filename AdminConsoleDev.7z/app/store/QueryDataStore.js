Ext.define('AdminConsole.store.QueryDataStore', {
    extend: 'Ext.data.Store',  
		autoLoad:false,
        storeId: 'QueryDataStore',
			
		fields: [
                {
                    name: 'dataPrivacyId'
                },
                {
                    name: 'privacyCode'
                },
                {
                    name: 'privacyText'
                },
                
            ],
		pageSize :5,	
		proxy:{
			type:'ajax',
			headers: {'Accept':'application/json' },
			url:AdminConsole.Constants.baseURL, 
			actionMethods: {
				create : 'POST',
				read   : 'POST',//default is get
				update : 'POST',
				destroy: 'POST'
			},
			api:{		
				read:AdminConsole.Constants.baseURL +'/oem/searchData.htm'	
				//read:'data.json'
			},
			reader:{
				type:'json',
				root:'searchResult',
				totalProperty:'totalCount' 
			},
			timeout:180000
	
		},
		listeners: {
        load: function( me, records, successful, eOpts) {
           if(successful){			
				AdminConsole.MyUtil.decodeAction(me.getProxy().getReader().rawData);
        	   console.log("Data Privacy store: "+records.length+" records loaded successfully.");			  
			   console.log("me.getProxy().getReader().rawData : "+me.getProxy().getReader().rawData);
        	   }
           else{
        	   me.sync();
        	   console.log("Data Privacy store: data load failed");
           }
		    AdminConsole.MyUtil.hideMask();
        },
        beforeload: function(store, operation,eOpts){
	        console.log("-------------operation---------------");
            if(operation.action=='read'){
				console.log(operation);
				console.log(operation.params);
				
				// update disabled filed value
				var formValues=Ext.getCmp('queryDataForm').getValues();
				
				queryData={
							privacyCode : formValues.code,
							privacyText:formValues.htmlEditorHiddenField,
							dataPrivacyId :formValues.id
						};
				if(operation.params==undefined){
					console.log("data missing -> adding data");
					operation.params={       			
						  data:Ext.JSON.encodeValue(queryData)
					};
				}
			}
		}
		}
});
Ext.define('AdminConsole.store.AssignedServiceStore', {
    extend: 'Ext.data.Store',  
		autoLoad:true,
        storeId: 'AssignedServiceStore',
			
		fields: [
                {
                    name: 'id'
                },
                {
                    name: 'servicename'
                },
                {
                    name: 'url'
                },
                
            ],
	
});
Ext.define('AdminConsole.store.AvailableUserStore', {
    extend: 'Ext.data.Store',

   
	storeId: 'AvailableUserStore',
	
	fields : [{
				name : 'userId',
			   
			}, {
				name : 'userName',
				
			}, {
				name : 'role',
				
			},
			{
				name : 'approver',
				
			},
			{
				name : 'assigned',
				
			}
		],
		pageSize :5,	
		proxy:{
			type:'ajax',
			headers: {'Accept':'application/json' },
			url:AdminConsole.Constants.baseURL, 
			actionMethods: {
				create : 'POST',
				read   : 'POST',//default is get
				update : 'POST',
				destroy: 'POST'
			},
			api:{		
				read:AdminConsole.Constants.baseURL + '/oem/getOemUsers.htm'			
			},
			reader:{
				type:'json',
				root:'teamList',
				totalProperty:'totalCount' 
			},
			timeout:180000
	
		},
		listeners: {
        load: function( me, records, successful, eOpts) {
           if(successful){			
				AdminConsole.MyUtil.decodeAction(me.getProxy().getReader().rawData);
        	   console.log("SupplierStore: "+records.length+" records loaded successfully.");			  
			   console.log("me.getProxy().getReader().rawData : "+me.getProxy().getReader().rawData);
        	   }
           else{
        	   me.sync();
        	   console.log("SupplierStore: data load failed");
           }
		   AdminConsole.MyUtil.hideMask();
        },
        beforeload: function(store, operation,eOpts){
	        console.log("-------------operation---------------");
            if(operation.action=='read'){
				console.log(operation);
				console.log(operation.params);
				
				// update disabled filed value
				var formValues=Ext.getCmp('queryAssignTeam').getValues();
				var data={
					
					firstName:formValues.firstName?formValues.firstName:null,
					lastName:formValues.lastName?formValues.lastName:null,
					role:formValues.role?formValues.role:null,
					username:formValues.userName?formValues.userName:null,
					enabled:formValues.enable?formValues.enable:false 
					
					
				};
				// Updating productCategories field
				
				if(operation.params==undefined){
					console.log("data missing -> adding data");
					operation.params={
						 data:Ext.JSON.encodeValue(data),
						purchaseCatId :purCatData.purchaseCatId
				
						 
					};
				}
			}
		}
		}
		
        
   });
Ext.define('AdminConsole.store.DataPrivacy', {
    extend: 'Ext.data.Store',
	storeId: 'DataPrivacy',
	//autoLoad:false,
		
	 fields:[
		   {name: 'id'},
		   {name: 'privacyCode'},
		   {name: 'privacyText'}
	],
        
   });
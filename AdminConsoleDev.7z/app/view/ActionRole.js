Ext.define('AdminConsole.view.ActionRole', {
    extend: 'Ext.panel.Panel',
	xtype:'action-role',
	itemId:'action-role',
	id:'action-role',
    requires: [
        'Ext.toolbar.Toolbar',
        'Ext.button.Button',       
        'Ext.toolbar.Spacer',     
    ],
	layout: {
		type : 'fit',
		
	},
	//autoScroll:true,
	title: '',
	items:[{
                    xtype: 'panel',
					//width : 900,
                    title: '',
					border:true,
                    layout: {
                        type: 'vbox',
                        align: 'center'
                    },
					bodyStyle:{
					'background-color':'#f6f6f6',
				    },
					 bodyPadding: '10 10 10 10',
					 //autoScroll:true,
					 items:[
					 {
                    xtype: 'panel',
					title:fetch.label.actRoleMap,
					titleAlign: 'center',
					
					
					border:true,
                    layout: {
                        type: 'vbox',
                        align: 'center'
                    },
					 bodyPadding: '10 10 10 10',
					 
					 items:[
					 {
						xtype:'panel',
						autoScroll:true,
						maxHeight:300,
						minWidth:800,
						id:'action-role-panel',
						//width : 750,
						//border:true,
						bodyPadding: '10 20 10 20',
						tpl: new Ext.XTemplate(
							 '<table align="center" style=" border-collapse:collapse;border:1px solid #0066a1;" >',
								'<th style="background:#0066a1">',								
							   '<tpl for="roles">', 
								'<td style="background:#0066a1; color:#ffffff;padding:10px">{description}</td>',
								'</tpl>',
								'</th>',								
								 '<tr>',
									 '<tpl for="screens">', 
										'<tr style="border-bottom:1px solid #0066a1;">',
											'<td style="padding:5px">{screenCode}-{screenName}</td>',
										   '<tpl foreach="actionRole">', 
										   
												   '<td align="center">',
									'<input type="checkbox" id="{parent.screenCode}" value="{#}"',
														'{[values === true ? "checked" : ""]}>',
													'</td>',
											'</tpl>',
										'</tr>',
									'</tpl>',
								 '</tr>',
							'</table>'							   
							),
						
						},
						{
							xtype:'tbspacer',
							height:10
						},
						 {
                            xtype: 'container',
                            layout: {
                                type: 'hbox',
                                align: 'stretch',
                                pack: 'center'
                            },
                            items: [
                              
									{
										text: fetch.label.submit,
										xtype:'button',
										
										handler: function checkvalue(btn) {
													var obj = Ext.select('input[type=checkbox]').elements;
													 var i = 0;
													 var cb = '';
													 var total = 0;
													 var screensStore=Ext.getStore('Screens');
													 var rolesStore=Ext.getStore('Role');
													 var slen=screensStore.getCount();
													 var rlen=rolesStore.getCount();
													 var k=0;
													for (i=0,j=0; i<obj.length;i++) {
													   //	console.log('i'+i+'j'+j+'k'+k);
														 var rec=screensStore.getAt(k);
														 rec.data.actionRole[j]=obj[i].checked;
														// console.log(obj[i].id+'***'+obj[i].value+'****'+obj[i].checked);
														 j=j+1;
														 if(j>=rlen)
														 j=0;									
														 k=Math.floor((i+1)/rlen);
														  }
														 var rolesList=[];
														rolesStore.each(function(rec,index){
														rolesList.push(rec.data);
														});
														 var screensList=[];
														screensStore.each(function(rec,index){
														screensList.push(rec.data);
														});												
													//userList=JSON.parse(JSON.stringify(userList));						
														
													var actionRoleData = {
															roles:rolesList,
															screens:screensList
														};
														console.log(Ext.JSON.encode(actionRoleData));
														var url;		
														//url = 'jsonResponse.json';
														
														AdminConsole.MyUtil.showMask(btn.up('panel'),fetch.label.saving);
														url = AdminConsole.Constants.baseURL + '/oem/saveActionRoles.htm';
														Ext.Ajax.request({
															url : url,
															method : 'POST',
															timeout:180000,
															params : Ext.JSON.encode(actionRoleData),
															headers :
															{
																'Content-Type' : 'application/json',
															},
															success : function(response) {
																	console.log(response.responseText);
																	var decodedData=Ext.JSON.decode(response.responseText);
																	/*if(decodedData.error){
																		Ext.Msg.alert(fetch.label.error,'Error Occured');
																		store.removeAll();
																		AdminConsole.MyUtil.hideMask();
																		store.sync();
																		return false;
																	}*/					
																	//else{
																		Ext.Msg.alert(fetch.label.success,'Action Role submitted successfully' ,function(btnId){
																		 if(btnId=='ok'){
																			// form.getForm().reset();
																			
																			AdminConsole.MyUtil.hideMask();
																			}
																		});
																//	}
																	
															},
															failure : function(response) {
																alert(fetch.label.serverCommunicationFailureMessage);
																AdminConsole.MyUtil.hideMask();
																
															}
														});
														
													
										  }
									},
									{
										xtype:'tbspacer',
										width:10
									},
								    {
											xtype: 'button',
											text: fetch.label.cancel,
											//text:'Cancel',
											action:'cancelButton'
									}
							]
						}
					]
					
				}
				]
            
			}]
			
       

});
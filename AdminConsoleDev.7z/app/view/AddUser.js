Ext.define('AdminConsole.view.AddUser', {
    extend: 'Ext.panel.Panel',
	xtype:'addUser',
	itemId:'addUser',
	
	requires: [
        'Ext.toolbar.Toolbar',
        'Ext.button.Button',
        'Ext.menu.Menu',
        'Ext.menu.Item',
        'Ext.form.Panel',
        'Ext.form.FieldSet',
        'Ext.form.field.Text',
        'Ext.toolbar.Spacer',
		'Ext.form.ComboBox',
			
    ],
	
	title: '',
	margin: '10 10 10 10',
	layout: {
		type : 'fit',
	},
	listeners:{
		activate:function(me){
		console.log('inside activate of add user');
		me.down('#role').getStore().load();
		
		}
	},
		  
		  items:[
					{
		  
						xtype: 'panel',
					//	width:400,
					//	border:true,
                        bodyPadding: '10 10 10 10',
						title: '',
						layout: {
							type: 'vbox',
							align: 'center'
						},
						bodyStyle:{
						'background-color':'#f6f6f6',
						},
						 bodyPadding: '10 10 10 10',
						 autoScroll:true,
					items: [
						{
						xtype: 'form',
						width : 700,
						//height:300,
						border:true,
						 bodyPadding: '10 20 10 20',
						itemId:'addUserForm',
						title: fetch.label.addUser,
						titleAlign: 'center',
						 layout: {
							type: 'vbox',
							align: 'center',
							pack: 'center'
						},
						
						items: [
							{
								xtype: 'fieldset',
								border: 0, 
								bodyPadding: '10 10 10 10',
								layout : {
										type : 'table',
										columns : 3,
										},
								
								items:[
								/*{
										
										xtype: 'textfield',
										hidden:false,
										name:'testId',
										
							    },*/
								{
										allowBlank : false,
										xtype: 'textfield',
										fieldLabel: fetch.label.userName+fetch.label.mandatory,
										name:'user',
										msgTarget:'side',
										emptyText:fetch.label.userName,
										listeners:{
												blur:function(me){
													var code=me.getValue();
													unique= true;
														console.log("---------checking if code is unique-------");
														if(!me.readOnly){
														Ext.Ajax.request(
														{
															url: AdminConsole.Constants.baseURL+'/oem/userIdExists.htm',
															params :code,
															async : false,
															headers: {'Accept':'application/json','Content-Type':'application/json' },
															success: function(response, opts) {
																console.log(response.responseText);
																var res=response.responseText;
																if (res=="Y") {
																	console.log('not unique');
																	 me.markInvalid('Already Exist');
																	 unique= false;
																	//Ext.Msg.alert(fetch.label.code , fetch.label.alreadyExistString);
																} else if(res=="N"){
																	console.log('unique');
																	unique= true;
																} 
															},
															failure: function (response, options) {
																Ext.Msg.alert(fetch.label.serverCommunicationFailureMessage);
															}
										 
														});
														}
													
												}
											}
							    },
							    {
										xtype: 'tbspacer',
										width: 20
								},
														
								{
									   allowBlank : false,
									   xtype: 'textfield',
									   fieldLabel: fetch.label.firstName+fetch.label.mandatory,
									   name:'firstName',
									   emptyText:fetch.label.firstName,
									   hideLabel: false,
									   msgTarget:'side'
								},
									
								{
										allowBlank : false,
										xtype: 'textfield',
										fieldLabel:fetch.label.lastName+fetch.label.mandatory,
										name:'lastName',
										 emptyText:fetch.label.lastName,
										msgTarget:'side'
								},
								{
										xtype: 'tbspacer',
										width: 20
								},
								
								{
										allowBlank : false,
										xtype: 'textfield',
										fieldLabel:fetch.label.email+fetch.label.mandatory,
									    name: 'email',
										emptyText:fetch.label.email,
										vtype: 'email'
										
								},
								
								{
										xtype: 'textfield',
										fieldLabel:fetch.label.contactNo,
										name:'contactNo',
										emptyText:fetch.label.contactNo,
										regex: /^(\+)?[0-9]+$/,
										msgTarget:'side'
								},
								{
										xtype: 'tbspacer',
										width: 20
								},
								
								{
										xtype: 'textfield',
										fieldLabel:fetch.label.address,
										name:'address',
										emptyText:fetch.label.address,
								},
								
								{
										xtype: 'textfield',
										fieldLabel:fetch.label.city,
										name:'city',
										emptyText:fetch.label.city
								},
								
								{
										xtype: 'tbspacer',
										width: 20
								},
								{
								
										xtype: 'textfield',
										fieldLabel:fetch.label.country,
										name:'country',
										emptyText:fetch.label.country
								},
								
								{
										
										xtype: 'checkbox',
										fieldLabel:fetch.label.enable,
										name:'enabled',
										
										
								},	
								
								{
									xtype: 'tbspacer',
									width: 20
								},
								{
										allowBlank : false,
										xtype: 'combobox',
										fieldLabel:fetch.label.prefLang+fetch.label.mandatory,
										name:'prefLang',
										queryCaching:false,
										emptyText:fetch.label.selLang,
										store:{
										autoLoad:true,
										fields: ['code','name'],   
										proxy:{
											type:'ajax',
											url:AdminConsole.Constants.baseURL+'/getAllLanguage.htm',
											headers: {'Accept':'application/json' },
											reader:{
													type:'json',
											},
										}
										
									},
									valueField: 'code',
									displayField: 'name',
									queryMode: 'remote',
									
									allowBlank:false,
									editable:false,
									msgTarget:'side',
										
																															
								},
								
								
								{
										allowBlank : false,
										xtype: 'combobox',
										queryCaching:false,
										itemId:'role',
										fieldLabel:fetch.label.role+fetch.label.mandatory,
											store:{
													//autoLoad:true,
													fields: ['code','name'],   
													proxy:{
														type:'ajax',
														url:AdminConsole.Constants.baseURL+'/oem/getAllRoles.htm',
														headers: {'Accept':'application/json' },
														reader:{
																	type:'json',
																},
													}
										
											},
										queryMode: 'remote',
										displayField: 'name',
										valueField: 'code',
										editable:false,
										
										emptyText:fetch.label.selRole,
										name:'role',
										listeners:{
											/*select:function(combo,records){
												var code= combo.getValue();
												console.log('Inside selct function of Role Combobox');
												if(code!=null && code!=""){
												Ext.Ajax.request(
															{
																url: AdminConsole.Constants.baseURL+'/oem/getServiceForRole.htm',
																params :{"cpRoleId":code},
																method:'GET',
																async : false,
																headers: {'Accept':'application/json','Content-Type':'application/json' },
																success: function(response, opts) {
																	//console.log(response.responseText);
																	var decodedData=Ext.JSON.decode(response.responseText);
																	combo.up('#addUser').down('#addUserForm').down('#services').update(decodedData);
																	
																	combo.up('#addUser').down('#addUserForm').down('#services').updateLayout();
																},
																failure: function (response, options) {
																	Ext.Msg.alert(fetch.label.serverCommunicationFailureMessage);
																}
											 
															});
															}
											
											},*/
											change:function(combo){
												console.log('change event ');
												var code= combo.getValue();
												console.log('Inside selct function of Role Combobox');
												if(code!=null && code!=""){
												Ext.Ajax.request(
															{
																url: AdminConsole.Constants.baseURL+'/oem/getServiceForRole.htm',
																params :{"cpRoleId":code},
																method:'GET',
																async : false,
																headers: {'Accept':'application/json','Content-Type':'application/json' },
																success: function(response, opts) {
																	//console.log(response.responseText);
																	var decodedData=Ext.JSON.decode(response.responseText);
																	combo.up('#addUser').down('#addUserForm').down('#services').update(decodedData);
																	
																	combo.up('#addUser').down('#addUserForm').down('#services').updateLayout();
																},
																failure: function (response, options) {
																	Ext.Msg.alert(fetch.label.serverCommunicationFailureMessage);
																}
											 
															});
															}
												
												//me.fireEvent('select',me);
											}
										}
								},	
								
								{
										xtype: 'tbspacer',
										width: 20
								},
								
								{
									xtype: 'container',
									bodyPadding: '10 10 10 10',
									itemId:'serviceContainer',
									layout: {
										type: 'hbox',
										align: 'center',
										pack: 'center'
									},
									items: [
										{
												xtype:'displayfield',
												fieldLabel:fetch.label.services,
												
										},
										
										
										{
												
												xtype: 'panel',
												//title:'<p style="background-color:#ffffff;color:#000000;padding:0px;margin:0px;">'+fetch.label.services+'</p>',
												//titleAlign:'left',
												
												border:true,
												height:60,
												width:180,
												itemId:'services',
												name:'services',
												autoScroll:true,
												//readOnly:true,
												tpl: new Ext.XTemplate(
												'<div>',
												//'<th >'+fetch.label.services+'</th>',								
												'<tpl for=".">', 
												'<div style="padding-left:5px" >{servicename}</div>',
												'</tpl>',
												'</div>'		
												),
												
										},
								
								
								]	
																
								
							},
								
							
																
							],
													
					},
					 {
								xtype: 'container',
								bodyPadding: '10 10 10 10',
								
								layout: {
									type: 'hbox',
									align: 'center',
									pack: 'center'
								},
								items: [
										{
											xtype: 'button',
											text: fetch.label.Save,
											action:'saveAddUserAction',
											
										},
										{
											xtype: 'tbspacer',
											width: 10
										},
										{
											xtype: 'button',
											text: fetch.label.Cancel,
											action:'cancelButton'
											
										}
									]
							}
				],
					
				}]	
					
		  
		 }]
					
});
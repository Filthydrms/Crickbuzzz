Ext.define('AdminConsole.view.AssignUNSPSCView', {
	extend : 'Ext.panel.Panel',
	xtype:'assign-unspsc',
	itemId:'assign-unspsc',
	id:'assign-unspsc',
	requires: ['Ext.tip.*'],
	title:'',
	style:{
		//'border':' 1px #dadada solid',
		'font-size':13, 
		'font-family':'Verdana, Geneva, sans-serif', 
		'color':'#000000', 
		//'border-radius': '25px',
		'box-shadow': '0 0 20px rgba(0, 0, 0, 0.3)'
	},
	width:'100%',
	//height:2500,
	margin:'10 0 10 0',
	bodyStyle:{
		'background-color':'#f6f6f6' 
	},
	//border:' 1px #dadada solid',
	layout : {
		type : 'vbox',
		align:'center'
		//pack:'center'
	},
	bodyPadding:50,
	autoScroll:true,
	items:[{
		xtype:'form',
		itemId:'reg-form',
		title:fetch.label.assUNSPSC,
			layout : {
				type : 'vbox',
				align:'left'
				//pack:'center'
			},
			bodyStyle:{
				'background-color':'#f6f6f6'
			},
			border:false,
			//autoScroll:true,
		fieldDefaults : {
		labelAlign : 'left',
		labelWidth : 130,
		//inputWidth : 200,
		labelSeparator:':',
		//afterLabelTpl :'<span style="float:right;">:&nbsp;</span>',
		labelCls : 'loginLabelCls',
		allowBlank : true,
		msgTarget:'side'
	},
	defaults : {
		//width:200
		//bodyPadding : '10px',
				//anchor : '100%',
		//	bodyPadding : '100px'
	},
	defaultType : 'textfield',
	items : [/*{
		xtype:'panel',
		border:false,
		bodyStyle:{
			'background-color':'#f6f6f6'
		},
		width:1000,
		html:'<h1>Assign UNSPSC</h1><hr />'
	
	},	*/	
	{
					xtype:'panel',
					border:false,
					bodyStyle:{
						'background-color':'#f6f6f6'
					},
					width:800,
					html:'<h3>'+fetch.label.selProdCat+'</h3>'
				
				},	
				{
					xtype:'prodcatselector',
					//title:'Select UNSPSC Category',
					width:900,
					border:false,
					bodyStyle:{
						background: '#F6F6F6'
					},
					dockedItems:{
						dock:'bottom',
						bodyStyle:{
							background: '#F6F6F6'
						},
					items : [
						{
							xtype:'button',
							text:fetch.label.assignProdCategory,
							itemId:'assignProdCatBtn',
							scale:'medium',
							margin:'10 0 30 360',
							disabled:true,
							
							handler:function(me){
								console.log("inside Assign");
								//if commodity has selection -> fetch it -> add it to the result store
								//else if class has selection -> fetch it -> add it to the result store ....
								
								//console.log(me.up('form'));
								var selectorForm = me.up('form');
								//set fromField - from which store to copy
								//var selected = parForm.getSelections(selectorForm.down('#commoditySelect').boundList);
								//if(selected.length > 0)
								//parFrom.fromField = selectForm.
								
								
								var parForm = me.up('form').up('form');
								parForm.toField = parForm.down('#finalSelect');
								var selected = parForm.getSelections(selectorForm.down('#commoditySelect').boundList);
								if( !selected.length > 0){
									selected = parForm.getSelections(selectorForm.down('#classSelect').boundList);
									if(!selected.length > 0){
										selected = parForm.getSelections(selectorForm.down('#familySelect').boundList);
										if(!selected.length > 0){
											selected = parForm.getSelections(selectorForm.down('#segmentSelect').boundList);
										}
									}									
								}
								parForm.moveRec(true,selected);
							}
						}
					]
					},
					buttonAlign:'center'
				},
				{
					xtype:'form',
					layout:'hbox',
					border:false,
					bodyStyle:{
						background:'#f6f6f6'
					},
					items:[
				{
					/** ******** SELECTED VALUES ********** */
					xtype: 'multiselect',
					title:fetch.label.selection,
					itemId:'finalSelect',
					msgTarget: 'side',
					//fieldLabel: 'Result',
					name: 'multiselect',
					labelAlign: 'top',
					width:400,
					height:250,
					//autoScroll:true,
					ddReorder: false,
					allowBlank:true,
					columnLines:true,
					submitValue:false,
					//store:'AssignUnspscStore',
					store:{
						autoLoad:true,
						//fields:['supplierid', 'company', 'legalform','division','supplierno'],
						fields:['productNo','description'],
						//data: {'segments':[
						//	{'v':'123','d':'One Hundred Twenty Three'},
						//	{'v':'1','d': 'One'},
						//]},
						proxy: {
							type: 'memory',
							reader: {
								type: 'json',
								root: 'segments'
							}
						}
					},
					valueField: 'productNo',
					displayField: 'description',
					listeners: {
						boundList: {
							scope: this,
							//itemclick: onAssignButtonClick
							itemclick:function(me){
								console.log('click result');
							}
							//drop: me.syncValue
						}
					}
				},
				{
					xtype:'panel',
					border:false,
					layout:'vbox',
					margin:'50 5 5 20',
					bodyStyle:{
						background:'#f6f6f6'
					},
					items:[
						{
							xtype:'button',
							margin:'0 0 10 0',
							text:fetch.label.removeUNSPSC,
							id:'track-tip',
							handler:function(me){
								//get parent form
								var parForm = me.up('form').up('form');
								var selectorForm = me.up('form');
								var selected = parForm.getSelections(selectorForm.down('#finalSelect').boundList);
								selectorForm.down('#finalSelect').boundList.getStore().remove(selected,true);
							}
							/*listeners:{
								added:function(me){
									console.log("*********quicktip*********");
									//console.log(me);
									var mytip = Ext.create('Ext.tip.ToolTip', {
										target: me.getEl(),
										//title: 'Mouse Track',
										width: 200,
										html: 'Select an item from the list and click on Remove to remove the item.',
										trackMouse: true
									});
								}
							}*/
						},{
							xtype:'button',
							text:'RemoveAll',
							id:'track-tip1',
							handler:function(me){
								//get parent form
								//var parForm = me.up('form').up('form');
								var resultForm = me.up('form');
								//var selected = parForm.getSelections(selectorForm.down('#finalSelect').boundList);
								resultForm.down('#finalSelect').boundList.getStore().removeAll();
							}
						}
					]
				}
				]
				
		},
		/*{
					xtype:'panel',
					layout:'hbox',
					itemId : 'privacyCheckBoxPanel',
					bodyStyle:{
						background:'#f6f6f6'
					},
					items:[
							{
								xtype : 'checkbox',
								itemId: 'privacyCheckBox',								
									
								padding : '20 0 0 0',
								//name : 'disabled',
								name : 'privacyCheck'
								//fieldLabel : 'I accept'
							}
						]
		},	*/

		
		{	xtype:'panel',
			width:300,
			border:false,
			//height:40,
			bodyStyle:{
				background:'#f6f6f6'
			},
			//margin:'109 0 0 0',
			margin:'60 0 0 350',
			
			layout:{
				type:'hbox',
				align:'center',
				pack:'center'
			},
			items:[
			{
				xtype: 'button', 
				text:fetch.label.submit,
				itemId:'createSupplierBtn',
				////ui:'supcon-submit',
				width:80,
				height:30,
				action:'create',
				style:{
					//'border-radius':'10px',										
					'box-shadow': '1px 1px 3px #000'
				},
				margin:'5 5 5 5',
				
			},{xtype:'tbspacer',width:20},
			{
				xtype: 'button', 
				text: fetch.label.cancel,
				////ui:'supcon-submit',	
				itemId:'supSelfRegCancelBtn',
				width:80,
				height:30,
				action:'Cancel',
				style:{
					//'border-radius':'10px',										
					'box-shadow': '1px 1px 3px #000'
				},
				margin:'5 5 5 5',
				handler:function(){
					Ext.Msg.confirm('','Are you sure you want to exit?',
										function(res){
											if(res=='yes'){
												
											}
										});
				}
			}]
		} 
		],
	

	/**	 FROM ITEMSELECTOR
     * Get the selected records from the specified list.
     * 
     * Records will be returned *in store order*, not in order of selection.
     * @param {Ext.view.BoundList} list The list to read selections from.
     * @return {Ext.data.Model[]} The selected records in store order.
     * 
     */
    getSelections: function(list) {
        var store = list.getStore();

        return Ext.Array.sort(list.getSelectionModel().getSelection(), function(a, b) {
            a = store.indexOf(a);
            b = store.indexOf(b);

            if (a < b) {
                return -1;
            } else if (a > b) {
                return 1;
            }
            return 0;
        });
    },
	 onAssignButtonClick : function() {
        var me = this,
            selected = me.getSelections(me.fromField.boundList);

        me.moveRec(true, selected);
        //me.toField.boundList.getSelectionModel().select(selected);
    },
	moveRec: function(add, recs) {
        var me = this,
            //fromField = me.fromField,
            toField   = me.toField,
            //fromStore = add ? fromField.store : toField.store,
            toStore   = add ? toField.store   : fromField.store;

        //fromStore.suspendEvents();
        toStore.suspendEvents();
        //fromStore.remove(recs);
        //CHECK IF IT ALREADY EXISTS
        Ext.Array.each(recs, function(rec){
        	//console.log(toStore.find('productNo', rec.get('productNo')));        	
        	//console.log(rec.get('productNo'));
        	if(toStore.find('productNo', rec.get('productNo'))==-1){
        		toStore.add(rec);
        	}
        });
        //toStore.add(recs);
        //fromStore.resumeEvents();
        toStore.resumeEvents();

        //fromField.boundList.refresh();
        toField.boundList.refresh();

        //me.syncValue();
    }
}]
});
Ext.onReady(function() {
	console.log("Registration : what up!");

	 Ext.create('Ext.tip.ToolTip', {
					target: 'track-tip',
					//title: 'Mouse Track',
					width: 200,
					//html: 'Select an item from the list and click to remove the item.',
					html: fetch.label.qFieldMsg,
					trackMouse: true
	});
	Ext.QuickTips.init();
});
/*View for qualification.*/
Ext.define('AdminConsole.view.ConnectionProfile', {
	extend : 'Ext.panel.Panel',
	xtype : 'connectionProfile',
	//id : 'login',
	itemId:'connectionProfile',
	layout : {
		type : 'vbox',
		align : 'center'
		//pack:'center'
	},
	//width:'100%',
	style:{
		margin:'2% 0 0 0'
	},
	items : [ 
		{
			xtype:'container',
			id:'connectionProfileMain',
			width:'100%',
			layout:{
				type:'vbox',
				align:'center'
			},
			autoScroll:true,
			items:[
					/* {
						bodyCls:'logintitle',
						style:{},
						width:750,
						html:	fetch.label.ConnectionProfile 
							//"Pending Approval Notifications"
							+'<div class="logindotSeparator"></div>'
							+'<br />'
					}	 */				
				]
		},
		  {
			xtype: 'button',
			text: fetch.label.CreateButton,	
			itemId :'createConnectionProfileBtn',
			action : 'createConnectionProfile',					
			//ui:'supcon-submit',					
			width:80,
			height:30,
			style:{																
				'box-shadow': '1px 1px 3px #000'
			},					
			margin:'5 0 5 0'
		}
	],
	activate:function(){
	console.log("inside Notifications");
	}
});

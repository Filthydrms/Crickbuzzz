Ext.define('AdminConsole.view.ProdCatSelector',{
	extend : 'Ext.form.Panel',
	itemId:'prodCatSelector',
	xtype:'prodcatselector',
	prodLevel:1,
	layout:{
				type : 'table',
				columns : 1,
			},
	mulHeight:250,
	mulWidth:225,
	bodyPadding:10,
	fieldDefaults:{
		width:225,
		height:250,
		//autoScroll:true,
		ddReorder:{
			scope:this
		},
		//allowBlank:true,
		//labelSeparator:'',
		
		
			// We don't want the multiselects themselves to act like fields,
            // so override these methods to prevent them from including
            // any of their values
            submitValue: false,
            getSubmitData: function(){
                return null;
            },
            getModelData: function(){
                return null;    
            }
	},
	items:[
		{
			xtype:'panel',
			title:'check444',
			itemId:'title1',
			hidden:false
			
		},
		{
			xtype:'panel',
			title:'check1',
			itemId:'title2',
			hidden:true
			
		},
		{
			xtype:'panel',
			title:'check1',
			itemId:'title3',
			hidden:true
			
		},
		{
			xtype:'panel',
			title:'check1',
			itemId:'title4',
			hidden:true
			
		},
		{
            /** ******** SEGMENTS ********** */
			xtype: 'multiselect',
			itemId:'segmentSelect',
            msgTarget: 'side',
			//title: fetch.label.segment,
            name: 'multiselect',
			labelAlign: 'top',
			hidden:false,
			//overflowY:'scroll',

           
			store:{
				fields: ['productNo','description','selType'],
				//autoLoad:false,
				proxy:{
					type:'ajax',
					headers: {
						//'Content-Type':'application/json',
						'Accept':'application/json' 
					},
			    	//url:'resources/data/Segments.json',
					//url:AdminConsole.Constants.baseURL+'/getAllProductSegment.htm',
					url:AdminConsole.Constants.baseURL+'/getSegments.htm',
					actionMethods: {
						create : 'POST',
						read   : 'POST',//default is get
						update : 'POST',
						destroy: 'POST'
					},
					method:'POST',			
					reader:{
						type:'json',
						root:''
						//totalProperty:'totalCount' 
					},
					timeout:180000				
				},
				listeners: {
					load: function( me, records, successful, eOpts) {
					   if(successful){
						   console.log("SegmentStore: "+records.length+" records loaded successfully.");
						   console.log("me.getProxy().getReader().rawData : "+me.getProxy().getReader().rawData);
					   }
					   else{
						   console.log("SegmentStore: data load failed");
					   }
					}
				}
			},
			valueField: 'productNo',
			displayField: 'description',
            //value: ['3', '4', '6'],
			listeners: {
                boundList: {
                    scope: this,
					
                    itemclick: function(me,record){
						console.log('clicked');						
						
						var parentForm = me.up('form');
						//console.log(parentForm.down('#familySelect'));
						/** enable/disable Assign button */
						var asgnBtn = parentForm.down('#assignProdCatBtn');
						//console.log(record);
						//console.log(record.data.selType);
						if(record.data.selType=="1" && asgnBtn.isDisabled()){
							asgnBtn.enable();
						}else if(record.data.selType=="0" && !asgnBtn.isDisabled())
							asgnBtn.disable();
							
						/** load family store */
						
						console.log(parentForm);
							parentForm.down('#title2').setVisible(false);
							parentForm.down('#title3').setVisible(false);
							parentForm.down('#title4').setVisible(false);
							parentForm.down('#familySelect').setVisible(false);
							parentForm.down('#classSelect').setVisible(false);
							parentForm.down('#commoditySelect').setVisible(false);
						if(parentForm.prodLevel>1){
							parentForm.getLayout().columns=2;
							parentForm.down('#familySelect').setVisible(true);
							parentForm.down('#title2').setVisible(true);
							parentForm.down('#familySelect').getStore().load({params:{code:record.data.productNo}});
							
							/** clear class and commodity store */
							parentForm.down('#classSelect').getStore().removeAll();
							parentForm.down('#commoditySelect').getStore().removeAll();
						}
						
							parentForm.doLayout();
					}
                    //drop: me.syncValue
                }
            }
        },{
			/** ******** FAMILY ********** */
            xtype: 'multiselect',
			itemId:'familySelect',
            msgTarget: 'side',
           // title: fetch.label.family,
            name: 'multiselect',
			hidden:true,
			labelAlign: 'top',
			/*store:{
				autoLoad:true,
				//fields:['supplierid', 'company', 'legalform','division','supplierno'],
				fields:['v','d'],
				data: {'segments':[
					{'v':'123','d':'One Hundred Twenty Three'},
                    {'v':'1','d': 'One'},
				]},
				proxy: {
					type: 'memory',
					reader: {
						type: 'json',
						root: 'segments'
					}
				}
			},*/
			store:{
				fields: ['productNo','description','selType'],
				autoLoad:false,
				proxy:{
					type:'ajax',
					headers: {
					//'Content-Type':'application/json'
					'Accept':'application/json' 
					},
			    	//url:'resources/data/Families.json',
					//url:AdminConsole.Constants.baseURL+'/getAllProductFamilyFromSegment.htm',	
					url:AdminConsole.Constants.baseURL+'/getFamiliesFromSegment.htm',	
					actionMethods: {
						create : 'POST',
						read   : 'POST',//default is get
						update : 'POST',
						destroy: 'POST'
					},					
					//method:'post',				
					reader:{
						type:'json',
						root:''
						//totalProperty:'totalCount' 
					},
					timeout:180000				
				},
				 listeners: {
					load: function( me, records, successful, eOpts) {
					   if(successful){
						   console.log("SegmentStore: "+records.length+" records loaded successfully.");
						   console.log("me.getProxy().getReader().rawData : "+me.getProxy().getReader().rawData);
						   }
					   else{
						   console.log("SegmentStore: data load failed");
					   }
					}
				}
			},
			valueField: 'productNo',
			displayField: 'description',
            //value: ['3', '4', '6'],
			listeners: {
                boundList: {
                    scope: this,
                    itemclick: function(me,record){
						console.log('clicked');
						var parentForm = me.up('form');
						/** enable Assign button */
						var asgnBtn = parentForm.down('#assignProdCatBtn');
						if(record.data.selType=="1" && asgnBtn.isDisabled()){
							asgnBtn.enable();
						}else if(record.data.selType=="0" && !asgnBtn.isDisabled())
							asgnBtn.disable();
						/** load class store */
						parentForm.down('#title3').setVisible(false);
						parentForm.down('#title4').setVisible(false);
						parentForm.down('#classSelect').setVisible(false);
						parentForm.down('#commoditySelect').setVisible(false);
						if(parentForm.prodLevel>2){
						parentForm.getLayout().columns=3;
						parentForm.down('#classSelect').setVisible(true);
						parentForm.down('#title3').setVisible(true);
						parentForm.down('#classSelect').getStore().load({params:{code:record.data.productNo}});
						
						/** clear commodity store */
						parentForm.down('#commoditySelect').getStore().removeAll();
						}
						
						parentForm.doLayout();
					}
                    //drop: me.syncValue
                }
            }
        },{
            /** ******** CLASS ********** */
			xtype: 'multiselect',
			itemId:'classSelect',
            msgTarget: 'side',
           // title: fetch.label.prodClass,
            name: 'multiselect',
			hidden:true,
			labelAlign: 'top',
			store:{
				fields: ['productNo','description','selType'],
				autoLoad:false,
				proxy:{
					type:'ajax',
					//headers: {'Content-Type':'application/json','Accept':'application/json' },
			    	//url:'resources/data/Classes.json',
					url:AdminConsole.Constants.baseURL+'/getClassesFromFamily.htm',
					//method:'post',				
					actionMethods: {
						create : 'POST',
						read   : 'POST',//default is get
						update : 'POST',
						destroy: 'POST'
					},					
					reader:{
						type:'json',
						root:''
						//totalProperty:'totalCount' 
					},
					timeout:180000				
				},
				 listeners: {
					load: function( me, records, successful, eOpts) {
					   if(successful){
						   console.log("SegmentStore: "+records.length+" records loaded successfully.");
						   console.log("me.getProxy().getReader().rawData : "+me.getProxy().getReader().rawData);
					   }
					   else{
						   console.log("SegmentStore: data load failed");
					   }
					}
				}
			},
			valueField: 'productNo',
			displayField: 'description',
			listeners: {
                boundList: {
                    scope: this,
                    itemclick: function(me,record){
						console.log('clicked');
						var parentForm = me.up('form');
						/** enable Assign button */
						var asgnBtn = parentForm.down('#assignProdCatBtn');
						if(record.data.selType=="1" && asgnBtn.isDisabled()){
							asgnBtn.enable();
						}else if(record.data.selType=="0" && !asgnBtn.isDisabled())
							asgnBtn.disable();
						/**load commodity store */
						parentForm.down('#commoditySelect').setVisible(false);
						parentForm.down('#title4').setVisible(false);
						if(parentForm.prodLevel>3){
						parentForm.getLayout().columns=4;
						parentForm.down('#commoditySelect').setVisible(true);
						parentForm.down('#title4').setVisible(true);
						parentForm.down('#commoditySelect').getStore().load({params:{code:record.data.productNo}});
						}
						
						parentForm.doLayout();
					}
                    //drop: me.syncValue
                }
            }

        },{
			/** ******** COMMODITIES ********** */
            xtype: 'multiselect',
			itemId:'commoditySelect',
            msgTarget: 'side',
          //  title: fetch.label.commodity,
            name: 'multiselect',
			hidden:true,
			labelAlign: 'top',
			store:{
				fields: ['productNo','description','selType'],
				autoLoad:false,
				proxy:{
					type:'ajax',
					headers: {
					//'Content-Type':'application/json',
					'Accept':'application/json' },
			    	//url:'resources/data/Commodities.json',
					//url:AdminConsole.Constants.baseURL+'/getAllProductCommodityFromClass.htm',
					url:AdminConsole.Constants.baseURL+'/getCommoditiesFromClass.htm',
					//method:'post',				
					actionMethods: {
						create : 'POST',
						read   : 'POST',//default is get
						update : 'POST',
						destroy: 'POST'
					},					
					reader:{
						type:'json',
						root:''
						//totalProperty:'totalCount' 
					},
					timeout:180000				
				},
				 listeners: {
					load: function( me, records, successful, eOpts) {
					   if(successful){
						   console.log("SegmentStore: "+records.length+" records loaded successfully.");
						   console.log("me.getProxy().getReader().rawData : "+me.getProxy().getReader().rawData);
					   }
					   else{
						   console.log("SegmentStore: data load failed");
					   }
					}
				}
			},
			valueField: 'productNo',
			displayField: 'description',
			listeners: {
                boundList: {
                    scope: this,
                    itemclick: function(me,record){
						console.log('clicked');
						var parentForm = me.up('form');
						/** enable Assign button */
						var asgnBtn = parentForm.down('#assignProdCatBtn');						
						if(asgnBtn.isDisabled()){
							asgnBtn.enable();
						}
					}
                    //drop: me.syncValue
                }
            }

        }	
	]	
});
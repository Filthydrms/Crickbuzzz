Ext.define('AdminConsole.view.QueryUser', {
    extend: 'Ext.panel.Panel',
	xtype:'queryUser',
	itemId:'queryUser',
	
	requires: [
        'Ext.toolbar.Toolbar',
        'Ext.button.Button',
        'Ext.menu.Menu',
        'Ext.menu.Item',
        'Ext.form.Panel',
        'Ext.form.FieldSet',
        'Ext.form.field.Text',
        'Ext.toolbar.Spacer',
		'Ext.form.ComboBox',
	   ],
	
	title: '',
	margin: '10 10 10 10',
	layout: {
		type : 'fit',
	}, 
	
	title:'',
		  items:[
					{
		  
						xtype: 'panel',
						//width:400,
						//border:true,
                        bodyPadding: '10 10 10 10',
						title: '',
						layout: {
							type: 'vbox',
							align: 'center'
						},
						bodyStyle:{
						'background-color':'#f6f6f6',
						},
						 bodyPadding: '10 20 10 20',
						 autoScroll:true,
					items: [
						{
						xtype: 'form',
						//width : 700,
						//height:400,
						border:true,
						bodyPadding: '10 20 10 20',
						itemId:'queryUserForm',
						id:'queryUserForm',
						title: fetch.label.queryUser,
						titleAlign: 'center',
						 layout: {
							type: 'vbox',
							align: 'center',
							pack: 'center'
						},
						
						items: [
							{
								xtype: 'fieldset',
								border: 0, 
								layout : {
										type : 'table',
										columns : 3,
										},
								
								items:[
								{
										
										xtype: 'textfield',
										fieldLabel: fetch.label.firstName, 
										name:'firstName',
										
										
							    },
							    {
										xtype: 'tbspacer',
										width: 20
								},
														
								{
									  
									   xtype: 'textfield',
									   fieldLabel:fetch.label.lastName,
									   name:'lastName',
									  
									  
								},
									
								{
										
										
										xtype: 'textfield',
										fieldLabel: fetch.label.userName,
										name:'user',
										
								},
								{
										xtype: 'tbspacer',
										width: 20
								},
								
								{
										xtype: 'textfield',
										fieldLabel:fetch.label.role,
										name:'role',
										
										
								},				
							]
							
							},
							{
									xtype: 'container',
									bodyPadding: '10 10 10 10',
									itemId:'queryUserButtonContainer',
									layout: {
									type: 'hbox',
									align: 'stretch',
									pack: 'center'
									},
									items: [
											{
												xtype: 'button',
												text: fetch.label.Search,
												action:'searchUser'
												
											},
											{
												xtype: 'tbspacer',
												width: 10
											},
											{
												xtype: 'button',
												text:  fetch.label.Cancel,
												action:'cancelButton'
											}	
										]
									
							},
						]
							
	},
	             {
					xtype:'tbspacer',
					height:10
				 },
			    {
				 xtype:'user-grid',
				 titleAlign:'center',
				 itemId:'userGrid',
				 hidden:false,
				 //height:400,
				 width:650,
				}
				
	
	],
	
}],	
});
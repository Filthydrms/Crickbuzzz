/* Details of Supplier List*/
Ext.define('AdminConsole.view.ConnectionProfileGrid', {
	extend : 'Ext.grid.Panel',
	requires : [ 'Ext.grid.column.Action' ],
	xtype : 'connectionProfileGrid',
	itemId : 'connectionProfileGridPanel',
	stateful : true,
	collapsible : false,
	//multiSelect : true,
	stateId : 'stateGrid',
	//height : 240,
	width : 700,	
	store : 'ConnectionProfileStore',
	autoScroll:true,
	border:true,
	margin:'10 0 10 0',
	columnLines :true,
	title:fetch.label.ConnectionProfile,
	titleAlign:'center',
	
	viewConfig: { 
		stripeRows: true,
		enableTextSelection : true,
		getRowClass: function(record, rowIndex, rowParams, store) { 				
			return record.get('disabled')? 'row-disabled' : 'row-enabled'; 
		} 
	} ,
	style:{
		//'border':' 1px #dadada solid',
		'font-size':13, 
		'font-family':'Verdana, Geneva, sans-serif', 
		'color':'#000000', 
		//'border-radius': '25px',
		'box-shadow': '0 0 20px rgba(0, 0, 0, 0.3)'
	},
	columns : [
	     {
			text : fetch.label.systemId,
			flex:1,
			sortable : true,			
			dataIndex : 'systemId',
			hidden : true
		},
		{
			text : fetch.label.systemCode,
			flex:1,
			sortable : true,			
			dataIndex : 'code',
			hidden : true
		},{
			text : fetch.label.systemName,
			flex:1,			
			sortable : true,
			dataIndex : 'name'
		},
		{
			text : fetch.label.systemUrl,
			flex:2,			
			sortable : true,
			dataIndex : 'sysUrl'
		},
		
		{
			text : fetch.label.isProxyEnabled,
			xtype : 'checkcolumn',
			flex : 1,
			sortable : true,
			dataIndex : 'proxyEnabled',
			processEvent: function () { return false; }
		},
		{
			text : fetch.label.commodityCodeAttribute,
			flex:1,			
			sortable : true,
			dataIndex : 'commCodeAttr',
			hidden : true
		},
		{
			text : fetch.label.classStatusRootClassId,
			flex:1,			
			sortable : true,
			dataIndex : 'classStatusRootClassId',
			hidden : true
		},
		{
			text : fetch.label.contRoleRootClassId,
			flex:1,			
			sortable : true,
			dataIndex : 'contRoleRootClassId',
			hidden : true
		},
		{
			text : fetch.label.classificationStatusAttribute,
			flex:1,			
			sortable : true,
			dataIndex : 'classStatAttr',
			hidden : true
		},
		{
			text : fetch.label.contactRoleAttribute,
			flex:1,			
			sortable : true,
			dataIndex : 'contRoleAttr',
			hidden : true
		},
		
		{
			text : fetch.label.systemIp,
			flex:1,			
			sortable : true,
			dataIndex : 'ipAddress',
			hidden : true
		},{
			text : fetch.label.port,
			flex:1,	
			sortable : true,
			dataIndex : 'port',
			hidden : true
		},{
			text : fetch.label.protocol,
			flex:1,		
			sortable : true,
			dataIndex : 'protocol',
			hidden : true
		},/* {
			text : fetch.label.proxy,
			flex:1,			
			sortable : true,
			dataIndex : 'proxy',
			hidden : true			
		},{
			text : fetch.label.proxyPort,
			flex:1,		
			sortable : true,
			dataIndex : 'proxyPort',
			hidden : true
		},{
			text : fetch.label.proxyUser,
			flex:1,			
			sortable : true,
			dataIndex : 'proxyUser',
			hidden : true
		},{
			text : fetch.label.proxyPassword,
			flex:1,			
			sortable : true,
			dataIndex : 'proxyPassword',
			hidden : true
		}, */
		{
		xtype:'actioncolumn',
		width:30,
		items: [	{
						icon: './resources/images/details.png',
						tooltip: fetch.label.display,
						handler: function(grid, rowIndex, colIndex) {
							var connectionProfileRec = grid.getStore().getAt(rowIndex);
							AdminConsole.app.getController('ConnectionProfileController').viewConnectionProfile(this,connectionProfileRec);
						}
					}
				]
		},
		{
			xtype:'actioncolumn',
			width:30,
			items: [	{
							icon: './resources/images/editRecord.png',
							tooltip: fetch.label.edit,
							handler: function(grid, rowIndex, colIndex) {
								var connectionProfileRec = grid.getStore().getAt(rowIndex);
								AdminConsole.app.getController('ConnectionProfileController').editConnectionProfile(this,connectionProfileRec);
							}
							
						}
					]
		},
		{
			xtype:'actioncolumn',
			width:30,
			items: [{
						icon: './resources/images/remove.jpg', 
						tooltip: fetch.label.remove,
						handler: function(grid, rowIndex, colIndex) {
						
							var connectionProfileRec = grid.getStore().getAt(rowIndex);
							AdminConsole.app.getController('ConnectionProfileController').deleteConnectionProfile(this,connectionProfileRec);															
						}
					}]
		}
	],
	/*dockedItems : [ {
		xtype : 'pagingtoolbar',
		id : 'connectionProfile-grid-paging',
		store : 'ConnectionProfileStore',
		dock : 'bottom',
		displayInfo : true
	} ] */
	
	


});
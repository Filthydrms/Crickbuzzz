Ext.define('AdminConsole.view.TranslateData', {
    extend: 'Ext.panel.Panel',
	xtype:'translate-data',
	itemId:'translate-data',
    requires: [
        'Ext.toolbar.Toolbar',
        'Ext.button.Button',
        'Ext.menu.Menu',
        'Ext.menu.Item',
        'Ext.form.Panel',
        'Ext.form.FieldSet',
        'Ext.form.field.Text',
        'Ext.toolbar.Spacer',
		//'Ext.form.field.ComboBoxView'
    ],

    title: '',
	layout: {
		type : 'fit',
		//align : 'stretch',
		//pack: 'stretch'
	},
	style:{
		  margin:'10 10 10 10'
		  },
	
	//autoScroll:true,
	//scrollable:'vertical',
	items:[{
                    xtype: 'panel',
					width : '100%',
					border:true,
                    bodyPadding: '10 10 10 10',
                    title: '',
                    layout: {
                        type: 'vbox',
                        align: 'center'
                    },
					//autoScroll:true,
					//overflowX: 'scroll',
				items: [
                {
                    xtype: 'form',
                    width : 550,
					border:true,
                    bodyPadding: '10 10 10 10',
					//itemId:'createDataForm',
					bodyStyle:{
					'background-color':'#f6f6f6',
				    },
				
                    title: fetch.label.translate,
                    titleAlign: 'center',
                    layout: {
                        type: 'vbox',
                        align: 'center',
                        //pack: 'center'
						
                    },
					//autoScroll:true,
                    items: [
                        {
                            xtype: 'fieldset',
                            border: 0, 
							width : 500,
							//bodyPadding: '10 10 10 10',
                            layout: {
                               
								type : 'table',
								columns : 3,
                              
                            },
                            items: [
								{
									xtype: 'textfield',
									name:'entityId',
									hidden:true,
								},
								{
									xtype: 'textfield',
									name:'entityTableId',
									hidden:true,
								},
								{
									xtype: 'textfield',
									name:'langCode',
									hidden:true,
								},
								{
									xtype: 'textfield',
									name:'colName',
									hidden:true,
								},
								{
									xtype: 'textfield',
									name:'langEntityId',
									hidden:true,
								},
								{
									
                                    xtype: 'textarea',
									name:'actual',
									labelAlign:'top',
                                    fieldLabel: fetch.label.english,
									grow: true,
									readOnly:true,
									width:230,
									height:150
									
									
                                },
								{
                                    xtype: 'tbspacer',
                                    width: 20
                                },
								{
									
                                    xtype: 'textarea',
									name:'translated',
                                    fieldLabel: fetch.label.translated,									
									emptyText: fetch.label.typeTranslated,
									labelAlign:'top',
									grow: true,
									width:230,
									height:150
									
                                },
                               
								
								
                            ]
                        },
					    {
                            xtype: 'container',
							bodyPadding: '10 10 10 10',
							//itemId:'createDataButtonContainer',
                            layout: {
                                type: 'hbox',
                                align: 'center',
                                pack: 'center'
                            },
                            items: [
                                {
                                    xtype: 'button',
                                    text: fetch.label.save,
									action:'saveTranslatedData'
                                },
								{
                                    xtype: 'tbspacer',
                                    width: 10
                                },                                
                                {
                                    xtype: 'tbspacer',
                                    width: 10
                                },
                                
                                {
                                    xtype: 'button',
                                    text: fetch.label.cancel,
									action:'cancelButton'
                                }
                            ]
                        },
						
                    ]
                },										
            ]
		}	
	]    
});
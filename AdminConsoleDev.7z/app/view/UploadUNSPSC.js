Ext.define('AdminConsole.view.UploadUNSPSC', {
	extend : 'Ext.panel.Panel',
	xtype : 'upload-UNSPSC',
	itemId : 'uploadUNSPSC',
	//cls : 'fontCls',
	/*requires : [ 'Ext.layout.container.Table', 'Ext.form.FieldSet',
		'Ext.form.field.File',
		'Ext.form.field.Number',
		'Ext.form.Panel',
		'Ext.window.MessageBox' ,'SupCon.Constants'],*/
	layout : {
		type : 'fit',
		align : 'center',
		pack: 'center'
		
	},
	autoScroll:true,
	
	items : [{
				xtype:'panel',
				layout:{
					type:'vbox',
					align:'center'
				},
				margin: '10 0 10 0',
				autoScroll:true,
				//overflowX: 'scroll',
				items:[
						
						{
							xtype:'panel',
							title: fetch.label.uploadUnspsc,
							titleAlign: 'center',
							//margin: '10 0 10 0',
							//bodyPadding:20,							
							items:[								
								{
									xtype : 'form',
									//title: 'Upload UNSPSC',
									//titleAlign: 'center',
									//width:600,
									border:true,
									height:170,
									
									bodyStyle:{
										'background-color':'#f6f6f6',
									},									
									id : 'upload-unspsc-form',
									layout : {
										type : 'vbox',
										align:'center',
										pack:'center'
									},
									
									items : [ {
											xtype: 'filefield',
											name: 'file',
											fieldLabel: fetch.label.file,
											labelAlign: 'left',
											regex:/^.*\.(xlsx|xls)$/,
											labelWidth: 50,
											msgTarget:'side',
											regexText:'Only excel file can be uploaded',
											allowBlank: false,
											//buttonText: 'Browse',
											buttonText: fetch.label.browse,
											margin:'50 0 0 0',
											//buttonConfig: {
											//	iconCls: 'upload-icon'
											//},
										},
										{	
											xtype:'panel',
											width:500,
											height:50,
											border:false,
											bodyStyle:{
												background:'#f6f6f6'
											},
											
											layout:{
												type:'hbox',
												align:'center',
												pack:'center'
											},
											margin:'25 0 0 100',
											
											items:[
												{
													xtype: 'button', 
													
													text : fetch.label.Upload,
													////ui:'supcon-submit',
													//action:'uploadUnspsc',
													//width:80,
													//height:30,
													
													//margin:'5 5 5 5',
													handler: function(btn) {
														
														
														var newme = this;	
															AdminConsole.MyUtil.checkAuthorisationOnButton(AdminConsole.Constants.UPLOAD_UNSPSC_PRODUCT_CLASSIFICATION,function(authorised){
															if(authorised){
																							
																	
														var form = btn.up('form').getForm();
														//AdminConsole.MyUtil.showMask(btn.up('form'),fetch.label.uploading);
														if(form.isValid()){
															form.submit({
															timeout:180000,
															
															url: AdminConsole.Constants.baseURL + '/oem/uploadUnspsc.htm',
															//waitMsg: fetch.label.uploadFileMsg,
															waitMsg: 'Uploading file...',
															success: function(fp, o) {
																console.log("upload unspsc",fp,o);
																console.log(fp);
																console.log(o.result);
																//Ext.Msg.alert('Success', 'File "' + o.result.file + '" has been uploaded.');
																
																console.log("o.result.success "+o.result.success);
																if(o.result.success=="success"){
																	Ext.Msg.alert('SUCCESSFUL', 'File  has been uploaded.');
																	//Ext.Msg.alert(fetch.label.succful, fetch.label.uploadSucMsg);
																}
																else{
																	Ext.Msg.show({
																		cls:'upload-error',
																		//title:' WARNING',
																		//msg:'File has been uploaded with errors.',
																		title:fetch.label.warning,
																		msg: fetch.label.uploadWithErr,
																		
																		icon: Ext.Msg.INFO,
																		//iconCls:Ext.Msg.ERROR,
																		//frame:true,
																		//border: true,
																		closable: false,
																		//border:'5px thick red',
																		//border:true,
																		buttons: Ext.Msg.OK,
																		fn: function(){
																			Ext.create('Ext.data.Store', {
																				storeId:'errorStore',
																				fields:['rowNo','errorMessage','errorType','fieldName'],
																				data:o.result,
																				//data:{'errors':[
																				//		{ 'rowNo': 'Lisa' },
																				//		{ 'rowNo': 'Bart'}
																				//		]},
																				proxy: {
																					type: 'memory',
																					reader: {
																						type: 'json',
																						root: 'errors'
																					}
																				}
																			});
																				var gridPanel = Ext.create('Ext.grid.Panel', {
																						//title:'Error log',
																						width : 500,
																						height: 200,
																						 store: Ext.data.StoreManager.lookup('errorStore'),
																						columns : [
																							/*{
																								//text : 'Row No',
																								text : fetch.label.rawNo,
																								width : 100,
																								sortable : true,
																								// renderer : 'usMoney',
																								dataIndex : 'rowNo'
																							},*/
																							{
																								//text : 'Error Type',
																								text : fetch.label.errType,
																								//width : 150,
																								sortable : true,
																								flex:1,
																								// renderer : 'usMoney',
																								dataIndex : 'errorType'
																							}, {
																								//text : 'Field Name',
																								text : fetch.label.fieldName,
																								//width : 150,
																								flex:1,
																								sortable : true,
																								// renderer : 'usMoney',
																								dataIndex : 'fieldName'
																							}, {
																								//text : 'Error Message',
																								text : fetch.label.errMsg,
																								//width : 200,
																								flex:1,
																								sortable : true,
																							    renderer :function(value, cell)
																											{
																												
																											   if(value=='ALLREADY_EXIT')
																											   return 'Already exist';
																											   else
																											   return value;
																												
																											},
																								dataIndex : 'errorMessage'
																							}
																					]
																				});
																				var windo = Ext.create("Ext.Window",{
																				//title : 'Error Details',
																				title : fetch.label.errDet,
																				//width : 750,
																			   // height: 500,
																				//header:false,
																				hideHeaders:true,
																				closable : true,     
																				modal : true,
																				scrollable:true,
																				//layout:'auto',
																				layout:{					
																					type : 'vbox',
																					align : 'center'
																				},
																				//frame:false,
																				listeners:{
																					beforeclose: function( panel, eOpts ){
																						//panel.hide();
																						//return false;
																					}
																				}
																			});
																			console.log(windo);
																			//windo.add(formPanel);
																			windo.add(gridPanel);
																			//windo.showAt(200,10,true)
																			windo.show();
																			/*{
																				 duration: 5000,
																			   to: {
																				  opacity: 0
																			   }
																			})*/
																		}
																	});
																}
																
															},
															failure:function(){
																Ext.Msg.alert(fetch.label.error, fetch.label.uploadFail);
															}
															 /*failure: function(form, action){
															 console.log('failure',form,action);
																	/*if (action.failureType === Ext.form.action.Action.CONNECT_FAILURE) {
																		Ext.Msg.alert('Error',
																			'Status:'+action.response.status+': '+
																			action.response.statusText);
																	}
																	if (action.failureType === Ext.form.action.Action.SERVER_INVALID){
																		// server responded with success = false
																		Ext.Msg.alert('Invalid', action);
																	}
																}*/
														});
														//AdminConsole.MyUtil.hideMask();
														}
														}
													}
													);
														
													}
												
												},{
													xtype: 'tbspacer',
													width: 10
												},
												{
													xtype: 'button',
													text: fetch.label.cancel,
													action:'cancelButton'
												}
															
											]
										}
									],
									
									
								buttonAlign : 'center'
								}
							]		
						}
				]
			}],

	//listeners:{}

});

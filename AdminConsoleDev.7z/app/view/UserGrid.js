Ext.define('AdminConsole.view.UserGrid', {
	 extend: 'Ext.grid.Panel',
	 xtype: 'user-grid',
	 requires:'Ext.grid.plugin.DragDrop',
	 itemId:'userGrid',
	 title: fetch.label.userGrid,
	 store: 'UserStore',
	 hidden:false,
	
	columns: [
		{
			xtype: 'gridcolumn',
			dataIndex: 'oemUser',
			text: fetch.label.userId,
			flex: 1
		},
		{
			xtype: 'gridcolumn',
			dataIndex: 'UserName',
			text:fetch.label.userName2 ,
			flex: 1,
			renderer:function(value,p,r)
			{
			 return r.data['firstName']+ ' '+r.data['lastName'];
			}
		},
	
		{
			xtype: 'gridcolumn',
			dataIndex: 'role',
			text:  fetch.label.role,
			flex: 1
		},
	
	
	],
	dockedItems : [ {
						xtype : 'pagingtoolbar',
						//id : 'supplier-grid-paging',
						store : 'UserStore',/* store same as the grid */
						dock : 'bottom',
						displayInfo : true
					} ],
				
	
	})
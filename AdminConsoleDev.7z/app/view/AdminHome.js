/* Details of Menu*/
var homePageTxt=fetch.label.AdminHomeText;
var supmgttxt=fetch.label.supmgttxt;
Ext.define('AdminConsole.view.AdminHome', {
	extend : 'Ext.panel.Panel',
	id : 'adminhome',
	itemId : 'homePage',
	xtype : 'adminHome',
	layout : 'card',
	requires: ['Ext.toolbar.Spacer'],
	items : [ 
		{
			xtype:'panel',
			style:{
				margin:'10% 0 0 15%'
			},
			width:'100%',
			layout:{
				type:'vbox'							
			},
			items:[
				{
					bodyCls:'logintitle',
					style:{},
					width:'80%',
					html:homePageTxt
						+'<div class="logindotSeparator"></div>'
						+'<br />'
				},
				{
					xtype:'panel',
					layout:{
						type:'hbox'
					},
					width:'120%',
					items:[
						{
							xtype:'image',
							src:'resources/images/supmgt.jpg',
							width:212,
							height:215
						},
						{
							xtype : 'panel',
							//height : 490,
							width : '100%',
							padding:'0 0 0 20',
							//html:'<div style=" width:100%; height:100%; background: rgb(0,0,0)"><img src="resources/images/SupplierHub.jpg" style="width:100%; height:100%;"/></div>'
							html:'<div class="supmgttxt">'+fetch.label.homeMsg+'<br /><ul></div>'
						}				
					]
				}
				
			]
		}		
		,{
			xtype : 'connectionProfile'
			//id:'connectionProfile'
	    } ,
		{
			xtype:'create-product-category'
		},
		{
			xtype:'query-purchase-category'
		},
		{
			xtype : 'upload-UNSPSC'
			
	    },
		{
			xtype:'query-action'
		},
		{
			xtype:'query-role'
		},
		{
			xtype:'create-action'
		},
		{
			xtype:'create-role'
		},
		{
			xtype:'action-role'
		},
		{
			xtype:'create-data'
		},
		{
			xtype:'query-data'
		},
		{
			xtype : 'fetchBackendSystemData',
		},
		{
			xtype : 'translate',
		},
		{
			xtype : 'template',
		},
		{
			xtype : 'query-template',
		},
		{
		  xtype:'addUser',
		},
		{
		  xtype:'queryUser',
		},
		{
		 xtype:'cls-Config',
		},
		{
			xtype : 'contact-page'
		}
		
	],
	
	
	dockedItems : [{
		xtype : 'toolbar',
				ui:'footer',//so that buttons ui is displayed normally

				baseCls:'menupanel',//apply the background image
				//cls : 'suppliermenu',
				padding:'8 0 0 20',
				items : [
				   {
					text : fetch.label.Home,
					ui:'supcon-menu',					
					handler : function() {
						Ext.Router.redirect('home');
					}
			     },{ xtype: 'tbspacer', width: 10 },
				   {
					text : fetch.label.Admin,
					ui:'supcon-menu',					
					menu : {
						items : [ 	
									{
										text : fetch.label.ConnectionProfile,
										//iconCls : 'add',
										handler : function() {									
												Ext.Router.redirect('connectionProfile');							
										}
									}, 
									{ xtype: 'tbspacer', width: 10 },
									{	
										text: fetch.label.privacyData,
										ui:'supcon-menu',
										handler : function() {									
												Ext.Router.redirect('queryData');							
										}
										/*menu: {
												xtype: 'menu',
												width: 120,
												items: [
													{
														xtype: 'menuitem',
														text: fetch.label.create,
														id : 'createData',
														handler : function() {									
														Ext.Router.redirect('createData');							
													}
													},
													{
														xtype: 'menuitem',
														text: fetch.label.query,
														id : 'queryData',
														handler : function() {									
														Ext.Router.redirect('queryData');							
													}
													}
												]
											},*/
									}, 
									{ xtype: 'tbspacer', width: 10 },
									{
										text : fetch.label.fetchStatus,
										//tooltip:fetch.label.fetchStatusFromBackendSystem,
										handler : function() {									
												Ext.Router.redirect('fetchDataFromTeamcenter');							
										}
									}
						
						
						

						 ]
					},
					menuAlign:'tl-bl'

				},
					/*{ xtype: 'tbspacer', width: 10 },
				   {
						text:fetch.label.action,
						ui:'supcon-menu',
                            menu: {
                                xtype: 'menu',
                                width: 120,
                                items: [

                                    {
                                        xtype: 'menuitem',
                                        text: fetch.label.create,
										id : 'createAction',
										handler : function() {									
										Ext.Router.redirect('createAction');							
									}
                                    },
                                    {
                                        xtype: 'menuitem',
                                        text: fetch.label.query,
										id : 'queryAction',
										handler : function() {									
										Ext.Router.redirect('queryAction');							
									}
                                    }
                                ]
                            },
							
					
					},*/
				  
				  
					 /*{ xtype: 'tbspacer', width: 10 },
					  {
						text: fetch.label.role,
						ui:'supcon-menu',
                            menu: {
                                xtype: 'menu',
                                width: 120,
                                items: [
                                    {
                                        xtype: 'menuitem',
                                        text: fetch.label.create,
										id : 'createRole',
										handler : function() {									
										Ext.Router.redirect('createRole');							
									}
                                    },
                                    {
                                        xtype: 'menuitem',
                                        text: fetch.label.query,
										id : 'queryRole',
										handler : function() {									
										Ext.Router.redirect('queryRole');							
									}
                                    }
                                ]
                            },
							
					
					},*/
					{ xtype: 'tbspacer', width: 10 },
					
					/*{
							text : fetch.label.ActionRole,
							ui:'supcon-menu',					
							handler : function() {
								Ext.Router.redirect('actionRole');
							}
					},*/
					 //{ xtype: 'tbspacer', width: 10 },
				  {
						text: fetch.label.actionRole,
						ui:'supcon-menu',
                            menu: {
                                xtype: 'menu',
                                width: 180,
                                items: [ 
				   {
						text:fetch.label.action,
						ui:'supcon-menu',
                            menu: {
                                xtype: 'menu',
                                width: 120,
                                items: [

                                    {
                                        xtype: 'menuitem',
                                        text: fetch.label.create,
										id : 'createAction',
										handler : function() {									
										Ext.Router.redirect('createAction');							
									}
                                    },
                                    {
                                        xtype: 'menuitem',
                                        text: fetch.label.query,
										id : 'queryAction',
										handler : function() {									
										Ext.Router.redirect('queryAction');							
									}
                                    }
                                ]
                            },
							
					
					},
					 { xtype: 'tbspacer', width: 10 },
				   {
						text: fetch.label.role,
						ui:'supcon-menu',
                            menu: {
                                xtype: 'menu',
                                width: 120,
                                items: [
                                    {
                                        xtype: 'menuitem',
                                        text: fetch.label.create,
										id : 'createRole',
										handler : function() {									
										Ext.Router.redirect('createRole');							
									}
                                    },
                                    {
                                        xtype: 'menuitem',
                                        text: fetch.label.query,
										id : 'queryRole',
										handler : function() {									
										Ext.Router.redirect('queryRole');							
									}
                                    }
                                ]
                            },
							
					
					},{

							text : fetch.label.ActionRole,
							handler : function() {
							Ext.Router.redirect('actionRole');								
							}
						}
					
					]}},
					
				  
				   {
						text: fetch.label.purchaseCategory,
						ui:'supcon-menu',
                            menu: {
                                xtype: 'menu',
                                width: 220,
                                items: [
                                    {
                                        xtype: 'menuitem',
                                        text: fetch.label.create,
										id : 'createPurchaseCategory',
										handler : function() {									
										Ext.Router.redirect('createPurchaseCategory');							
									}
                                    },
                                    {
                                        xtype: 'menuitem',
                                        text: fetch.label.query,
										id : 'queryPurchaseCategory',
										handler : function() {									
										Ext.Router.redirect('queryPurchaseCategory');							
									}
                                    },
									{

										text : fetch.label.uploadUNSPSC,
										handler : function() {
											Ext.Router.redirect('uploadUNSPSC');								
											
										}

									},
									{
									  xtype:'menuitem',
									  text:fetch.label.clsConfig,
									  id:'clsConf',
									  handler:function(){
									   Ext.Router.redirect('clsConfig');
									  }
									
									}
                                ]
                            },
							//menuAlign:'tl-bl'
					
					},
					 
					/*{ xtype: 'tbspacer', width: 10 },
					{
							text : fetch.label.translate,
							ui:'supcon-menu',					
							handler : function() {
								Ext.Router.redirect('translateEntity');
							}
					},*/
					{
						text: fetch.label.translate,
						ui:'supcon-menu',
						menu : {
						items : [ 	
									{
										text : fetch.label.translate,
										//iconCls : 'add',
										handler : function() {
											Ext.Router.redirect('translateEntity');		
										}
									}, 
								//	{ xtype: 'tbspacer', width: 10 },
									{	
										text: fetch.label.template,
										ui:'supcon-menu',
										handler : function() {									
														Ext.Router.redirect('queryTemplate');							
													}
										/*menu: {
												xtype: 'menu',
												width: 120,
												items: [
													{
														xtype: 'menuitem',
														text: fetch.label.create,														
														handler : function() {									
														Ext.Router.redirect('createTemplate');							
													}
													},
													{
														xtype: 'menuitem',
														text: fetch.label.query,														
														handler : function() {									
														Ext.Router.redirect('queryTemplate');							
													}
													}
												]
											},*/
										}
									]
								} 									
						 
					},
					/*{ xtype: 'tbspacer', width: 10 },
					menuAlign:'tl-bl',										
					},*/
					/*{ xtype: 'tbspacer', width: 10 },
					{	
										text: fetch.label.template,
										ui:'supcon-menu',
										menu: {
												xtype: 'menu',
												width: 120,
												items: [
													{
														xtype: 'menuitem',
														text: fetch.label.create,														
														handler : function() {									
														Ext.Router.redirect('createTemplate');							
													}
													},
													{
														xtype: 'menuitem',
														text: fetch.label.query,														
														handler : function() {									
														Ext.Router.redirect('queryTemplate');							
													}
													}
												]
											},
					},*/
					 { xtype: 'tbspacer', width: 10 },//for space
					   {
					   
					   		text: fetch.label.user,
							ui:'supcon-menu',	
							menu: {
                                xtype: 'menu',
                                width: 160,
                                items: [
                                    {
                                        xtype: 'menuitem',
                                        text: fetch.label.addUser,
										id : 'addUser',
										handler : function() {									
										Ext.Router.redirect('addUser');							
									}
                                    },
                                    {
                                        xtype: 'menuitem',
                                        text: fetch.label.queryUser,
										id : 'queryUser',
										handler : function() {									
										Ext.Router.redirect('queryUser');							
									}
                                    },
									
                                ]
                            }
						},	
					{ xtype: 'tbspacer', width: 10 },
				  {
					text : fetch.label.contactUS,
					ui:'supcon-menu',										
					handler : function() {
					Ext.Router.redirect('showContactUs');								
					}			

				}, '->',
				   {
						text : fetch.label.welcome,
						id:'welcomeText',
						//align : 'right',
						ui:'supcon-menu'
					},'-',
					{
						text : fetch.label.logout,
						icon : 'resources/images/logout.png',
						//align : 'right',
						ui:'supcon-menu',
						//baseCls:'menuButton',
						handler : function() 
						{
							var tenantKey = Ext.util.Cookies.get('tenant');
							console.log(tenantKey);
							var token ="login/"+tenantKey;
							if(Ext.util.Cookies.get('userType')=='supplier'){
								token=token+'/supplier';
							}
							var url;
								url = AdminConsole.Constants.baseURL
										+ '/oem/logout.htm';
								Ext.Ajax.request({
								  url:url,
								  method:'GET',
									async:false,//synchronous call
								  success: function(response){
										console.log("logout successful");
								  },
									failure:function(response){
									  console.log("logout error");            	
									}
								});
								Ext.Router.redirect(token);
						}
					} 
				]
	}],
			listeners:{
				beforeactivate:function(me){ 
					console.log('SuppMgmtHome : activated');
					var value = Ext.util.Cookies.get('userName');
					console.log(value);
					Ext.getCmp('welcomeText').setText(fetch.label.welcome+' '+value+'!');
					//me.removeComponent('');
				}
			}

});
Ext.define('AdminConsole.view.ContactUsPage', {
    extend: 'Ext.panel.Panel',
	xtype:'contact-page',
	itemId:'contact-page',
	
    requires: [
        'Ext.toolbar.Toolbar',
        'Ext.button.Button',
        'Ext.menu.Menu',
        'Ext.menu.Item',
        'Ext.form.Panel',
        'Ext.form.FieldSet',
        'Ext.form.field.Text',
        'Ext.toolbar.Spacer',
		'Ext.toolbar.Paging',
    ],
	layout: {
		type : 'vbox',
	
		align:'center'
		
	},
	
	margin:'20 10 0 10',
	width:'100%',
	title: '',
	items:[
			/* {
					bodyCls:'logintitle',
					style:{
						margin:'10% 10 10 10'
					},
					width:'80%',
					html:fetch.label.contactUS+'<div class="logindotSeparator"></div>'+'<br />'
			}, */
			{
                    xtype: 'panel',
                    title: fetch.label.contactUS,
					border:true,
                    layout: {
                        type: 'vbox',
                        align: 'left',
						
                    },
					width:700,
					bodyPadding: '10 10 10 10',					
					items: [    
						{
							xtype:'container',
							html:'<div>'+fetch.label.contactUsPageTxt+'<br /></div>'
						}
					]
			},
			
			{
				xtype:'form',
				bodyPadding: '10 20 1 20',
				border:true,
				itemId:'contact-us-query-details',
				width:700,
				layout: {
                        type: 'vbox',
                        align: 'center',
                        //pack: 'center'
						
                },
				items:[
					{
						xtype:'fieldset',
						padding: '1 5 0 5',
						border:false,
						width:700,
						layout: {
                                type: 'hbox',
                                align: 'left',
                              //pack: 'left'
                        },
						items:[
							{	
								xtype:'textfield',
								name:'sendTo',
								fieldLabel:fetch.label.sendTo,
								width:600,
								readOnly:true,
								allowBlank:false,
							}
						]
					},
					{
						xtype:'fieldset',
						padding: '1 5 1 5',
						border:false,
						width:700,
						layout: {
                                type: 'vbox',
                                align: 'left',
                              //pack: 'left'
                        },
						items:[
							{	
								xtype:'textfield',
								name:'subject',
								fieldLabel:fetch.label.subject+fetch.label.mandatory,
								width:600,
								emptyText:fetch.label.emptySubject,
								msgTarget:'side',
								allowBlank:false,
							},
							{
								xtype:'tbspacer',
								height:5
							},
							{	
								xtype:'htmleditor',
								name:'message',
								fieldLabel:fetch.label.message,
								height:150,
								width:600,
								allowBlank:false,
							}
						]
					},
					{
						xtype:'panel',
						padding: '0 1 0 1',
						border:false,
						width:700,
						itemId:'userInfo',
						tpl:new Ext.XTemplate(
								'<div style="color:#0066a1;">',
								'<table>',
								'<tr><td>'+fetch.label.senderName+'</td><td>:</td><td><b> {senderName}</b></td></tr>',								
								'<tr><td>'+fetch.label.contact+'</td><td>:</td><td><b> {phone}</b></td></tr>',
								'<tr><td>'+fetch.label.companyName+'</td><td>:</td><td><b> {companyName}</b></td></tr>',
								'<tr><td>'+fetch.label.email+'</td><td>:</td><td><b> {email}</b></td></tr>',								
								'<tr><td>'+fetch.label.tenantName+'</td><td>:</td><td><b> {tenant}</b></td></tr>',
								'</table>',
								'</div>'
							)
						
					},
					{
						xtype:'container',
						padding: '5 5 5 5',
						border:false,
						width:700,
						layout: {
                                type: 'hbox',
                                align: 'center',
								pack: 'center'
                        },
						items:[
							{	
								xtype:'button',
								name:'submiit',
								text:fetch.label.submit,
								handler:function(btn){
									var form= btn.up('#contact-page').down('#contact-us-query-details').getForm();
									if(!form.isValid()){
										
										return;
									}
									var formValues =form.getValues();
									Ext.getBody().mask(fetch.label.emailWaitMsg);
									Ext.Ajax.request({
										url : AdminConsole.Constants.baseURL + '/submitUserQuery.htm',
										method : 'POST',
										timeout:180000,
										params : {
											'userType':Ext.util.Cookies.get('userType'),
											'userName':Ext.util.Cookies.get('userName'),
											'subject':formValues.subject,
											'message':formValues.message
										},
										success : function(response) {
												console.log(response.responseText);
												Ext.getBody().unmask();
												//var decodedData=Ext.JSON.decode(response.responseText);
												if(response.responseText=='success')
												{
													Ext.Msg.alert(fetch.label.thankYou,fetch.label.querySubmittedSucessfully,function(btnn){
														Ext.Router.redirect('home');
													});
													
												}
												else{
													Ext.Msg.alert(fetch.label.error,fetch.label.errorOccured);
												}
												
										},
										failure : function(response) {
											alert(fetch.label.serverCommunicationFailureMessage);
											Ext.getBody().unmask();
											
										}
									});
									
								}
								
							},
							{
								xtype:'tbspacer',
								width:20
							},
							{	
								xtype:'button',
								name:'cancel',
								text:fetch.label.cancel,
								action:'cancelButton'
							}
						]
					},
					
				]
			}
	],
	listeners:{
			activate:function(me,e){
				console.log('activate contact us ');
				
				
			//	Ext.util.Cookies.set('userName','skhan');
			//	Ext.util.Cookies.set('userType','Supplier');
				
				
				var view = me.down('#contact-us-query-details');
				view.getForm().reset();
				Ext.Ajax.request({
					url : AdminConsole.Constants.baseURL + '/getLoggedInUserInfo.htm',
					method : 'POST',
					timeout:180000,
					params : {
						'userType':Ext.util.Cookies.get('userType'),
						'userName':Ext.util.Cookies.get('userName')
					},
					success : function(response) {
							console.log(response.responseText);
							var decodedData=Ext.JSON.decode(response.responseText);
							//decodedData.tenant=Ext.util.Cookies.get('tenant');
							view.down('#userInfo').update(decodedData);
							view.getForm().findField('sendTo').setValue(decodedData.sendTo);
					},
					failure : function(response) {
						alert(fetch.label.serverCommunicationFailureMessage);
						
					}
				});
			}
	}
});
Ext.define('AdminConsole.view.Template', {
    extend: 'Ext.panel.Panel',
	xtype:'template',
	itemId:'template',
    requires: [
        'Ext.toolbar.Toolbar',
        'Ext.button.Button',
        'Ext.menu.Menu',
        'Ext.menu.Item',
        'Ext.form.Panel',
        'Ext.form.FieldSet',
        'Ext.form.field.Text',
        'Ext.toolbar.Spacer',
		//'Ext.form.field.ComboBoxView'
    ],

    title: '',
	layout: {
		type : 'fit',
		//align : 'stretch',
		//pack: 'stretch'
	},
	style:{
		  margin:'10 10 10 10'
		  },
	
	//autoScroll:true,
	//scrollable:'vertical',
	items:[{
                    xtype: 'panel',
					width : '100%',
					border:true,
                    bodyPadding: '10 10 10 10',
                    title: '',
                    layout: {
                        type: 'vbox',
                        align: 'center'
                    },
					//autoScroll:true,
					//overflowX: 'scroll',
				items: [
                {
                    xtype: 'form',
                    width : 500,
					border:true,
                    bodyPadding: '10 20 10 20',
					itemId:'createTemplateForm',
					bodyStyle:{
					'background-color':'#f6f6f6',
				    },
				
                    title: fetch.label.template,
                    titleAlign: 'center',
                    layout: {
                        type: 'vbox',
                        align: 'center',
                        //pack: 'center'
						
                    },
					//autoScroll:true,
                    items: [
                        {
                            xtype: 'fieldset',
                            border: 0, 
							//width : 500,
							bodyPadding: '10 10 10 10',
                            layout: {
                               
								type : 'table',
								columns : 1,
                              
                            },
							
                            items: [
								{
									
                                    xtype: 'textfield',
                                    fieldLabel: 'Id',
									name:'id',
									emptyText: 'Id',
									hidden:true
										
                                },
								{
									allowBlank : false,
                                    xtype: 'textfield',
                                    fieldLabel: fetch.label.code+fetch.label.required,
									name:'code',
									emptyText: fetch.label.code,
									width:400,
									msgTarget:'side',
									listeners:{
												blur:function(me){
													var code=me.getValue();
													templateCodeUnique= true;
														console.log("---------checking if code is unique-------");
														Ext.Ajax.request(
														{
															url: AdminConsole.Constants.baseURL+'/oem/templateCodeExists.htm',
															params :code,
															async : false,
															headers: {'Accept':'application/json','Content-Type':'application/json' },
															success: function(response, opts) {
																console.log(response.responseText);
																var res=response.responseText;
																if (res=="Y") {
																	console.log('not unique');
																	 me.markInvalid('Already Exist');
																	 templateCodeUnique= false;
																	//Ext.Msg.alert(fetch.label.code , fetch.label.alreadyExistString);
																} else if(res=="N"){
																	console.log('unique');
																	templateCodeUnique= true;
																} 
															},
															failure: function (response, options) {
																Ext.Msg.alert(fetch.label.serverCommunicationFailureMessage);
															}
										 
														});
													
												}
									}
                                },
								{
									allowBlank : false,
                                    xtype: 'textfield',
                                    fieldLabel: fetch.label.subject+fetch.label.required,
									name:'subject',
									emptyText: fetch.label.subject,
									msgTarget:'side',
									width:400,
									
                                },
								{
								xtype:'panel',
								itemId:'emailTextEditorPanel',
								layout:{
									type : 'hbox',
								},
								padding:'0 0 0 0px',
								bodyStyle:{
										'background-color':'#f6f6f6',
									},
									//bodyPadding:10,
									items:[
										{
											xtype:'component',
											width:97,
											html:fetch.label.body+fetch.label.required+':'
										},
										
										{	
												xtype : 'button',
												name:'htmlEditorPanelBtn',
												text : fetch.label.emailBtnText,
												itemId : 'htmlEditorPanelBtn',
												action : 'openTemplateEditor',
												margin:'0 0 0 10',
												listeners: {
															mouseover: function(btn) {
																btn.setTooltip(btn.up('#emailTextEditorPanel').down('#htmlEditorHiddenField').getValue());
															}
														}
											},
											{	
												allowBlank : false,
												name : 'htmlEditorHiddenField',
												xtype : 'textfield',
												itemId : 'htmlEditorHiddenField',
												hidden : true,
												msgTarget:'side'	
											},
										]	
							}
								
                            ]
                        },
					    {
                            xtype: 'container',
							bodyPadding: '10 10 10 10',
							//itemId:'createDataButtonContainer',
                            layout: {
                                type: 'hbox',
                                align: 'center',
                                pack: 'center'
                            },
                            items: [
                                {
                                    xtype: 'button',
                                    text: fetch.label.save,
									action:'saveTemplate'
                                },
								{
                                    xtype: 'tbspacer',
                                    width: 10
                                },
                                /*
                                {
                                    xtype: 'button',
                                    text: fetch.label.DeleteButton,
									action:'deleteTemplate'
                                },
                                
                                {
                                    xtype: 'tbspacer',
                                    width: 10
                                },*/
                                
                                {
                                    xtype: 'button',
                                    text: fetch.label.cancel,
									action:'cancelButton'
                                }
                            ]
                        },
						
                    ]
                },
				
				
				
            ]
		}	
		]
       

});
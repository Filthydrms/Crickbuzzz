Ext.define('AdminConsole.view.CreateRole', {
    extend: 'Ext.panel.Panel',
	xtype:'create-role',
	itemId:'create-role',
    requires: [
        'Ext.toolbar.Toolbar',
        'Ext.button.Button',
        'Ext.menu.Menu',
        'Ext.menu.Item',
        'Ext.form.Panel',
        'Ext.form.FieldSet',
        'Ext.form.field.Text',
        'Ext.toolbar.Spacer',
		//'Ext.form.field.ComboBoxView'
    ],

    title: '',
	layout: {
		type : 'fit',
		//align : 'stretch',
		//pack: 'stretch'
	},
	style:{
		  margin:'10 10 10 10'
		  },
	
	//autoScroll:true,
	//scrollable:'vertical',
	items:[{
                    xtype: 'panel',
					width : '100%',
					border:true,
                    bodyPadding: '10 10 10 10',
                    title: '',
                    layout: {
                        type: 'vbox',
                        align: 'center'
                    },
					//autoScroll:true,
					//overflowX: 'scroll',
				items: [
                {
                    xtype: 'form',
                    width : 500,
					border:true,
                    bodyPadding: '10 20 10 20',
					itemId:'createRoleForm',
					bodyStyle:{
					'background-color':'#f6f6f6',
				    },
				
                    title: fetch.label.createRole,
                    titleAlign: 'center',
                    layout: {
                        type: 'vbox',
                        align: 'center',
                        //pack: 'center'
						
                    },
					//autoScroll:true,
                    items: [
                        {
                            xtype: 'fieldset',
                            border: 0, 
							//width : 500,
							bodyPadding: '10 10 10 10',
                            layout: {
                               
								type : 'table',
								columns : 1,
                              
                            },
                            items: [
								
                                {
									
                                    xtype: 'textfield',
                                    fieldLabel: 'roleId',
									name:'roleId',
									hidden :true
									
                                },
								{
									
                                    xtype: 'textfield',
                                    //fieldLabel: 'roleId',
									name:'cpRoleId',
									hidden :true
									
                                },
								{
									allowBlank : false,
                                    xtype: 'textfield',
                                    fieldLabel: fetch.label.name+fetch.label.required,
									name:'name',
									emptyText: 'Name',
									msgTarget:'side',
									listeners:{
												blur:function(me){
													var code=me.getValue();
													unique= true;
														console.log("---------checking if code is unique-------");
														Ext.Ajax.request(
														{
															url: AdminConsole.Constants.baseURL+'/oem/nameExists.htm',
															params :code,
															async : false,
															headers: {'Accept':'application/json','Content-Type':'application/json' },
															success: function(response, opts) {
																console.log(response.responseText);
																var res=response.responseText;
																if (res=="Y") {
																	console.log('not unique');
																	 me.markInvalid('Already Exist');
																	 unique= false;
																	//Ext.Msg.alert(fetch.label.code , fetch.label.alreadyExistString);
																} else if(res=="N"){
																	console.log('unique');
																	unique= true;
																} 
															},
															failure: function (response, options) {
																Ext.Msg.alert(fetch.label.serverCommunicationFailureMessage);
															}
										 
														});
													
												}
											}
                                },
                                {
									allowBlank : false,
                                    xtype: 'textfield',
                                    fieldLabel: fetch.label.description+fetch.label.required,
									name:'description',
									emptyText: 'Description',
									msgTarget:'side'
                                }
								
                            ]
                        },
					    {
                            xtype: 'container',
							bodyPadding: '10 10 10 10',
							itemId:'createRoleButtonContainer',
                            layout: {
                                type: 'hbox',
                                align: 'center',
                                pack: 'center'
                            },
                            items: [
                                {
                                    xtype: 'button',
                                    text: fetch.label.save,
									action:'saveRole'
                                },
								/*{
                                    xtype: 'tbspacer',
                                    width: 10
                                },
                                
                                {
                                    xtype: 'button',
                                    text: fetch.label.DeleteButton,
									action:'deleteRole'
                                },*/
                                
                                {
                                    xtype: 'tbspacer',
                                    width: 10
                                },
								{
                                    xtype: 'button',
                                    text: fetch.label.assignService,
									action:'assignService',
									disabled:true
                                },
                                
                                {
                                    xtype: 'tbspacer',
                                    width: 10
                                },
                                
                                {
                                    xtype: 'button',
                                    text: fetch.label.cancel,
									action:'cancelButton'
                                }
                            ]
                        },
						
                    ]
                },
				
				
				
            ]
		}	
		]
       

});
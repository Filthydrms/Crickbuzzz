Ext.define('AdminConsole.view.ResetPasswordView', {
	extend : 'Ext.panel.Panel',
	xtype : 'resetpasswordpage',
	cls : 'loginpopup',
	itemId : 'resetpassword',
	layout : 'fit',
	items : [ 
		{
			xtype:'panel',
			layout : {
				type : 'vbox',
				align : 'center'
				//pack:'center'
			},
			//width:'100%', 
			style:{
				margin:'10% 0 0 0'
			},
			items : [ 
			{
				bodyCls:'logintitle',
				style:{},
				width:550,
				html:fetch.label.RESETPASSWORD
					+'<div class="logindotSeparator"></div>'
					+'<br />'
			},
			{
				xype:'panel',
				layout:{
					type:'hbox'
				},
				items:[
					{
						xtype:'image',
						//style : 'float:left',
						src : 'resources/images/resetpass.jpg',
						width : 161,
						height:177
					},	
					{
						id : 'resetpwdform',
						itemid : 'resetpwddata',
						xtype : 'form',
						//title : 'Reset Password',
						bodyCls : 'bodypanel',
						//frame : true,
						//width : 400,
						bodyPadding : 10,
						defaultType : 'textfield',
						defaults : {
							//height:30,
							labelWidth:170,
							inputWidth:200,
							labelCls : 'loginLabelCls',
							labelSeparator:'',
							msgTarget:'side',
							allowBlank:false,
							afterLabelTpl :'<span style="float:right;">:&nbsp;</span>'
						},
						items : [ 
						{	
							fieldLabel :fetch.label.userName,
							name : 'userName',
							emptyText : fetch.label.userName
						},
						 {	
							fieldLabel : fetch.label.currentPassword,
							name : 'currentPassword',
							emptyText : fetch.label.currentPassword,
							inputType : 'password'

						}, {
							fieldLabel : fetch.label.newPassword,
							name : 'newPassword',
							emptyText : fetch.label.newPassword,
							inputType : 'password',
							regex:/^(?!.*(.)\1{3})((?=.*[\d])(?=.*[a-z])(?=.*[A-Z])|(?=.*[a-z])(?=.*[A-Z])(?=.*[^\w\d\s])|(?=.*[\d])(?=.*[A-Z])(?=.*[^\w\d\s])|(?=.*[\d])(?=.*[a-z])(?=.*[^\w\d\s]))[\x21-\x7E]{8,28}$/,
							regexText:fetch.label.passwordRegex,
							//msgTarget:'under'
						},
						{
							fieldLabel : fetch.label.confirmNewPassword,
							name : 'confirmPassword',
							emptyText : fetch.label.confirmNewPassword,
							inputType : 'password'
						}
					

						],
						dockedItems: [{
							xtype: 'toolbar',
							dock: 'bottom',

							ui: 'footer',
							layout:{
								type:'vbox',
								align:'center'
							},
							style:{
								background:'white'
							},
							margin:'20 0 0 55',
							defaults: {minWidth: 100},
							items: [
								{ xtype: 'component', flex: 1 },
								{
									xtype: 'button', 
									text: fetch.label.submit,
									//ui:'supcon-submit',
									id:'changePassword',
									width:80,
									height:30,
									margin:'5 0 5 0',
									style:{
										//'border-radius':'10px',										
										'box-shadow': '1px 1px 3px #000'
									},
									handler : function() {
										//data=Ext.getCmp('loginform').getValues();
										console.log(">>>>>>>>>>>>>>>>>>>>>>>>username"+Ext.getCmp('resetpwdform').getForm().getValues().userName);
										var form = this.up("form");
										var formValues=form.getForm().getValues();
										
										if (!form.getForm().isValid()) {
											console.log("reset form invalid");

											return;
										}
										
										if(formValues.confirmPassword!=formValues.newPassword){
											Ext.Msg.alert(fetch.label.error,fetch.label.passwordMismatch);
											return ;
										}
										var dataCP=Ext.JSON.encode({
												userName:formValues.userName,
												currentPassword:formValues.currentPassword,
												newPassword:formValues.newPassword
											});
											console.log("dataCP"+dataCP);
											var userType=AdminConsole.app.getController('LoginController').userType;

										   var url;
												//if(userType=="OEM"){
													url = AdminConsole.Constants.baseURL+'/oem/resetUserPassword.htm';
												/*}else
													url = AdminConsole.Constants.baseURL+'/resetSupplierUserPassword.htm';*/
										Ext.Ajax.request({
											url:url,
											method:'POST',
											//headers : {'Content-Type':'application/json'},	
											params:{data : dataCP},
											timeout : 3600000,
											success: function(response){
												console.log(">>>>>>>>>>>>>>>>esponse.responseText"+response.responseText);
												if(response.responseText=='true'){
													console.log("Reset password successful");
													Ext.Msg.alert(fetch.label.success,fetch.label.resetPasswordReloginMessage);

													Ext.getCmp('resetpwdform').getForm().reset();
													//logout the user
													Ext.Ajax.request({
															url: SupCon.Constants.baseURL+'/logout.htm',
															method:'GET',
															async:false,//synchronous call
															success: function(response){
																console.log("logout successful");
															},
															failure:function(response){
																console.log("logout error");            	
															}
														});
													//redirect to login page
													Ext.getCmp('loginform').getForm().reset();
													var token ="login/"+Ext.util.Cookies.get('tenant');
													var userType = Ext.util.Cookies.get('userType');
													if(userType == 'supplier')
														token = token+'/supplier';					
													console.log(token);
													Ext.Router.redirect(token);
												}else{
												  console.log("Reset password failed");
												  Ext.Msg.alert(fetch.label.error,fetch.label.resetPasswordFailureMessage);
												}
											},
											failure:function(response){
												alert(fetch.label.communicationMsg);         	
											}
										});
									}
								}
							]
						}]/*,
							buttons : [ {
								text : 'Change Password',
								id:'changePassword',
								
								
							},
							{
								text : 'Reset',
								handler : function() {
									Ext.getCmp('loginform').getForm().reset();
								}
							},
						]*/
					}
				]
			}
		]
	}],
	listeners : {
		afterrender : function(me) {
			console.log("afterrender: Reset Password");
			console.log(me);
			/*form submit on enter
			this.keyNav = Ext.create('Ext.util.KeyNav', this.el, {
				enter: this.fnLogin,
				scope: this
			});*/

			/*registering history change listener
			Ext.History.on('change', function(token) {
				console.log('History.onChange()');

				var parts, tabPanel, length, i;
				// debugger;
				if (token) {
					parts = token.split(':');
					length = parts.length;
					// console.log('length->' + length);
					// console.log('parts[0]->'+parts[0]);
					// setActiveTab in all nested tabs
					if (length < 2) {
						Ext.getCmp('index').getLayout().setActiveItem(0);
					} else {
						Ext.getCmp('index').getLayout().setActiveItem(1);
						for (i = 0; i < length - 1; i++) {
							Ext.getCmp(parts[i]).setActiveTab(
									Ext.getCmp(parts[i + 1]));
						}
					}
				}
			});*/
				/*add to history the current page*/
				//Ext.History.add(me.id);
		},
		activate : function(me) {
			console.log("activate:" + me.id);
//			Ext.History.add(me.id);
		}
	}
});
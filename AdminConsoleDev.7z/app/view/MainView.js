Ext.define('AdminConsole.view.MainView', {
    extend: 'Ext.panel.Panel',
    requires:[
		'Ext.panel.Panel',
        'Ext.layout.container.Card'
    ],
    
    xtype: 'app-main-view',

    layout: {
		type : 'card',
		align : 'center',
		pack : 'center'
    },
	id : 'index',
	//height : '775px',
	requires : [ 'Ext.util.History' ],
	defaults : {
		bodyStyle : {
			//background : '#F2F6F8'
		}
	},
    items: [ {
		xtype : 'loginpage'
	}, {
		xtype : 'panel'
	}, {
		xtype : 'adminHome'
	},{
		xtype : 'resetpasswordpage'

	},
	{
		xtype : 'panel',
		itemId : 'userLoogedInErrorPage',
		html : '<h1 style="padding:20px">' + fetch.label.userLoginMsg +'</h1>'
	},
	
	{

		xtype : 'panel',
		itemId : 'errorPage',
		html : '<h1 style="padding:20px">'+fetch.label.incorrectURL +'</h1>'
	} 
	],
	
	dockedItems:[
		{
			xtype:'panel',
			width:'100%',
			layout:'vbox',
			items:[
				{	
					xtype : 'image',
					dock : 'top',
					style : 'float:left',
					src : 'resources/images/header.jpg',
					width : "100%",
					height:100,
					margin : '0 0 1 0'
					//height : 50
				}/*,
				{
					width:'100%',
					html:'<div class="menupanel">&nbsp;</div>'
				}*/
			]
		},
		{
            xtype:'panel',
            itemId:'languageLink',
            dock: 'right',
            border:false,
            bodyPadding:10,
            //margin:'0 0 100 100',
            html:'<a href="javascript:myFunction(\'en-US\')">English</a>',
            
		},
		{
					xtype : 'panel',
					dock:'bottom',
					frame : false,
					border : false,
					bodyCls:'footer',
					height:30,
					layout : {
						type : 'vbox',
						pack : 'center',
						align : 'center'
					},
					items:[
						{
							bodyCls:'footer',
							html:fetch.label.disclaimer
						}
					]
		}]
	
});
Ext.define('AdminConsole.view.CreateData', {
    extend: 'Ext.panel.Panel',
	xtype:'create-data',
	itemId:'create-data',
    requires: [
        'Ext.toolbar.Toolbar',
        'Ext.button.Button',
        'Ext.menu.Menu',
        'Ext.menu.Item',
        'Ext.form.Panel',
        'Ext.form.FieldSet',
        'Ext.form.field.Text',
        'Ext.toolbar.Spacer',
		//'Ext.form.field.ComboBoxView'
    ],

    title: '',
	layout: {
		type : 'fit',
		//align : 'stretch',
		//pack: 'stretch'
	},
	style:{
		  margin:'10 10 10 10'
		  },
	
	//autoScroll:true,
	//scrollable:'vertical',
	items:[{
                    xtype: 'panel',
					width : '100%',
					border:true,
                    bodyPadding: '10 10 10 10',
                    title: '',
                    layout: {
                        type: 'vbox',
                        align: 'center'
                    },
					//autoScroll:true,
					//overflowX: 'scroll',
				items: [
                {
                    xtype: 'form',
                    width : 500,
					border:true,
                    bodyPadding: '10 20 10 20',
					itemId:'createDataForm',
					bodyStyle:{
					'background-color':'#f6f6f6',
				    },
				
                    title: fetch.label.data,
                    titleAlign: 'center',
                    layout: {
                        type: 'vbox',
                        align: 'center',
                        //pack: 'center'
						
                    },
					//autoScroll:true,
                    items: [
                        {
                            xtype: 'fieldset',
                            border: 0, 
							//width : 500,
							bodyPadding: '10 10 10 10',
                            layout: {
                               
								type : 'table',
								columns : 1,
                              
                            },
                            items: [
								{
									
                                    xtype: 'textfield',
                                    fieldLabel: 'Id',
									name:'id',
									emptyText: 'Id',
									hidden:true
										
                                },
								{
									allowBlank : false,
                                    xtype: 'textfield',
                                    fieldLabel: fetch.label.code+fetch.label.required,
									name:'code',
									emptyText: fetch.label.code,
									msgTarget:'side'	
                                },
                                /*{
									allowBlank : false,
                                    xtype: 'textfield',
                                    fieldLabel: fetch.label.text+fetch.label.required,
									name:'text',
									emptyText: 'Text',
									msgTarget:'side'	
									
                                },*/
								{
								xtype:'panel',
								itemId:'emailTextEditorPanel',
								layout:{
									type : 'hbox',
								},
								padding:'0 0 0 0px',
								bodyStyle:{
										'background-color':'#f6f6f6',
									},
									//bodyPadding:10,
									items:[
										{
											xtype:'component',
											width:97,
											html:fetch.label.text+fetch.label.required+':'
										},
										
										{	
												xtype : 'button',
												name:'htmlEditorPanelBtn',
												text : fetch.label.emailBtnText,
												itemId : 'htmlEditorPanelBtn',
												action : 'htmlEditorPanel',
												margin:'0 0 0 10',
												listeners: {
															mouseover: function(btn) {
																btn.setTooltip(btn.up('#emailTextEditorPanel').down('#htmlEditorHiddenField').getValue());
															}
														}
											},
											{	
												allowBlank : false,
												name : 'htmlEditorHiddenField',
												xtype : 'textfield',
												itemId : 'htmlEditorHiddenField',
												hidden : true,
												msgTarget:'side'	
											},
										]	
							}
								
                            ]
                        },
					    {
                            xtype: 'container',
							bodyPadding: '10 10 10 10',
							itemId:'createDataButtonContainer',
                            layout: {
                                type: 'hbox',
                                align: 'center',
                                pack: 'center'
                            },
                            items: [
                                {
                                    xtype: 'button',
                                    text: fetch.label.save,
									action:'saveData'
                                },
								{
                                    xtype: 'tbspacer',
                                    width: 10
                                },
                                
                                {
                                    xtype: 'button',
                                    text: fetch.label.DeleteButton,
									action:'deleteData'
                                },
                                
                                {
                                    xtype: 'tbspacer',
                                    width: 10
                                },
                                
                                {
                                    xtype: 'button',
                                    text: fetch.label.cancel,
									action:'cancelButton'
                                }
                            ]
                        },
						
                    ]
                },
				
				
				
            ]
		}	
		]
       

});
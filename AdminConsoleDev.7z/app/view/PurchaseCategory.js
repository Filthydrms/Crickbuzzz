Ext.define('AdminConsole.view.PurchaseCategory', {
    extend: 'Ext.panel.Panel',
	xtype:'create-product-category',
	itemId:'create-product-category',
    requires: [
        'Ext.toolbar.Toolbar',
        'Ext.button.Button',
        'Ext.menu.Menu',
        'Ext.menu.Item',
        'Ext.form.Panel',
        'Ext.form.FieldSet',
        'Ext.form.field.Text',
        'Ext.toolbar.Spacer'
    ],

    title: '',
	layout: {
		type : 'fit',
		//align : 'stretch',
		//pack: 'stretch'
	},
	style:{
		  margin:'10 10 10 10'
		  },
	
	autoScroll:true,
	items:[{
                    xtype: 'panel',
					width : '100%',
					border:true,
                    bodyPadding: '10 10 10 10',
                    title: '',
                    layout: {
                        type: 'vbox',
                        align: 'center'
                    },
					autoScroll:true,
					//overflowX: 'scroll',
				items: [
                {
                    xtype: 'form',
                    width : 600,
					border:true,
                    bodyPadding: '10 20 10 20',
					itemId:'createPurchaseCategoryForm',
					bodyStyle:{
					'background-color':'#f6f6f6',
				    },
				
                    title: fetch.label.purCat,
                    titleAlign: 'center',
                    layout: {
                        type: 'vbox',
                        align: 'center',
                        //pack: 'center'
						
                    },
					//autoScroll:true,
                    items: [
                        {
                            xtype: 'fieldset',
                            border: 0, 
							//width : 600,
							bodyPadding: '10 10 10 10',
                            layout: {
                               
								type : 'table',
								columns : 1,
                              
                            },
                            items: [
								
                                {
									
                                    xtype: 'textfield',
                                    fieldLabel: 'Id',
									itemId:'pcId',
									name:'purchaseCatId',
									hidden:true
                                },
								 {
									allowBlank : false,
                                    xtype: 'textfield',
                                    fieldLabel: fetch.label.code+fetch.label.required,
									name:'code',
									emptyText: fetch.label.code,
									msgTarget:'side'	
                                },
                                {
									allowBlank : false,
                                    xtype: 'textfield',
                                    fieldLabel: fetch.label.name+fetch.label.required,
									name:'name',
									emptyText: fetch.label.name,
									msgTarget:'side'	
                                },
                               
                                {
									allowBlank : true,
                                    xtype: 'textfield',
                                    fieldLabel: fetch.label.description,
									name:'description',
									emptyText: fetch.label.description,
										
                                },
								{
										xtype : 'checkbox',
										fieldLabel: fetch.label.publish,
										name:'publish',
										disabled:true,
										
										

								},
								
								{
                                    xtype: 'textfield',
                                    fieldLabel: 'Status',
									name:'status',
									hidden:true,
									listeners:{
										change:function(me,newValue,oldValue,eOpts){
											if(newValue==AdminConsole.Constants.STATUS_RELEASED_CODE){
											me.up('form').down('checkbox').setValue(true);
											me.up('form').down('button[action="releaseButton"]').setDisabled(true);
											}
											else{
											
											me.up('form').down('checkbox').setValue(false);
											me.up('form').down('button[action="releaseButton"]').setDisabled(false);
											}
											
										}
									}
                                }
                            ]
                        },
					    {
                            xtype: 'container',
							bodyPadding: '10 10 10 10',
							itemId:'createButtonContainer',
                            layout: {
                                type: 'hbox',
                                align: 'center',
                                pack: 'center'
                            },
                            items: [
                                {
                                    xtype: 'button',
                                    text: fetch.label.save,
									action:'savePCButton'
                                },
                                {
                                    xtype: 'tbspacer',
                                    width: 10
                                },
                                {
                                    xtype: 'button',
                                    text: fetch.label.unspsc,
									action:'assignUnspscButton',
									disabled:true
                                },
                                {
                                    xtype: 'tbspacer',
                                    width: 10
                                },
                                {
                                    xtype: 'button',
                                    text: fetch.label.team,
									action:'assignTeamButton',
									disabled:true
                                },
                                {
                                    xtype: 'tbspacer',
                                    width: 10
                                },
                                {
                                    xtype: 'button',
                                    text: fetch.label.publish,
									action:'releaseButton',
									disabled:true
									
                                },
								{
                                    xtype: 'tbspacer',
                                    width: 10
                                },
                                {
                                    xtype: 'button',
                                    text: fetch.label.cancel,
									action:'cancelButton'
                                }
                            ]
                        },
						
                    ]
                },
				{
                     xtype: 'tbspacer',
					 height:10
				},
				{
					 xtype: 'assign-unspsc-grid', 
				     width : 600,
					 maxHeight:196,
				    // bodyPadding : '10 10 10 10',
					 hidden:true
				},
				{
                     xtype: 'tbspacer',
					 height:10
				},
				{
					 xtype: 'assign-team-grid',	
					width : 600,
					maxHeight:400,
					//bodyPadding : '10 10 10 10',
					
				     hidden:true

				},
				{
                    xtype: 'tbspacer',
                    height: 10
                },
				{
                            xtype: 'container',
							itemId:'editButtonContainer',
							hidden:true,
                            layout: {
                                type: 'hbox',
                                align: 'center',
                                pack: 'center'
                            },
                            items: [
                                {
                                    xtype: 'button',
                                    text: fetch.label.edit,
									action:'editPCButton'
                                },
                                {
                                    xtype: 'tbspacer',
                                    width: 10
                                },
                                {
                                    xtype: 'button',
                                    text: fetch.label.cancel,
									action:'cancelButton'
									
                                }
                               
                            ]
                }
            ]
		}	
		]
       

});
Ext.define('AdminConsole.view.ConnectionProfileDetail', {
    extend: 'Ext.panel.Panel',
	xtype: 'connectionProfileDetail',
	itemId: 'connectionProfileDetail',
    requires: ['Ext.toolbar.Toolbar',
        'Ext.button.Button',
        'Ext.menu.Menu',
        'Ext.menu.Item',
        'Ext.form.Panel',
        'Ext.form.FieldSet',
        'Ext.form.field.Text',
        'Ext.toolbar.Spacer'
    ],

    title: '',
	layout: {
		type : 'fit',
		//align : 'stretch',
		//pack: 'stretch'
	},
	style:{
		  margin:'10 10 10 10'
		  },
	
	autoScroll:true,
	items:[{
				xtype: 'panel',
				width : '100%',
				itemId:'connectionProfileFormPanel',
				border:true,
				bodyPadding: '10 10 10 10',
				title: '',
				layout: {
					type: 'vbox',
					align: 'center'
				},
				autoScroll:true,
				//overflowX: 'scroll',
				items: [
                {
                    xtype: 'form',
                    width : 950,
					border:true,
                    bodyPadding: '10 20 10 20',
					itemId:'connectionProfileForm',
					bodyStyle:{
					'background-color':'#f6f6f6',
				    },					
					fieldDefaults : {
							labelAlign : 'left',
							labelWidth : 220,
							labelSeparator:'',
							afterLabelTpl :'<span style="float:right;">:&nbsp;</span>',
							labelCls : 'loginLabelCls',
							msgTarget:'side'
					},
					title:fetch.label.createConnectionProfile,
                    titleAlign: 'center',
                    layout: {
                        type: 'vbox',
                        align: 'center',
                    },
					//autoScroll:true,
                    items: [
                        {
                            xtype: 'fieldset',
							itemId:'createConnectionProfileFieldset',
                            border: 0, 
							//width : 500,
							bodyPadding: '10 10 10 10',
                            layout: {                               
								type : 'table',
								columns : 2,                              
                            },
							defaults:{
								xtype : 'textfield',
								padding:'7 7 7 7'
							},
							
							//title:fetch.label.generalConfig,
																					
                            items: [
								{
									allowBlank : true,
									fieldLabel : fetch.label.systemId,
									name : 'systemId',
									itemId:'systemId',
									emptyText : fetch.label.systemId,										
									regexText:fetch.label.enaterNum,					
									hidden:true,
								},
								{
									allowBlank : false,
									fieldLabel : fetch.label.systemCode+fetch.label.required,
									name : 'code',					
									itemId:'systemCode',
									emptyText : fetch.label.systemCode,										
									regexText:fetch.label.enaterNum,
									hidden:true,
									//value :'syndicateWithTC',
								},
								//WHEN ONE OF THE RECORD IS SELECTED FROM THE LIST OF COMBO BOX, CODE ASSOCIATED WITH THE SSYSTEM IS ASSIGNED TO THE SYSTEMCODE HIDDEN FORM FIELD.
								//WILL WORK ONLY FOR SINGLE SELECT.
								{
									anchor: '100%',
									allowBlank : false,
									xtype: 'combobox',
									msgTarget: 'side',
									fieldLabel: fetch.label.systemName+fetch.label.required,
									name: 'name',
									itemId:'systemNameCombo',
									emptyText : fetch.label.plzSelect,
									store:{	
										fields: [ 'code', 'name' ],
										proxy: {
											type: 'ajax',
											isSynchronous : true,
											//url: Qual.Constants.baseURL+'/oem/getSystemName.htm',
											url:'resources/data/SystemNames.json',
											reader: {
												type:'json',
												root:'synSystem'
											},
											timeout : 360000
										},
										autoLoad: false
									},
									//store:'ProductCategoryStore',
									valueField: 'name',
									displayField: 'name',
									editable:false,
									listeners:{
												activate : function(me){
																	me.getStore().load();
																},
												select : function( combo, records, eOpts ){										
													console.log('Inside system name combo box select listener:Start');
													console.log('Selected value:-'+combo.valueField);
													console.log('Selected code:-'+records[0].data.code);
													
													var systemName = combo.getValue();	
													var connectionProfileForm = combo.up('#connectionProfileForm').getForm();
													var teamCenterFieldset = combo.up('#connectionProfileForm').down('#createConnProfileTeamCenterConfigFieldset');
													
													var systemNameCombo = combo.up('#connectionProfileForm').down('#createConnectionProfileFieldset').down('#systemNameCombo');
													//combo.up('#createConnectionProfileFieldset').down('#databasePartition').setVisible(AdminConsole.Constants.STATUS_FALSE);													
													if(AdminConsole.Constants.TEAMCENTER.toUpperCase() == systemName.toUpperCase()){
														console.log('Teamcenter selected.');
														//teamCenterFieldset.defaults.allowBlank = false;															
														teamCenterFieldset.setVisible(true);
														
								
														connectionProfileForm.reset();
														//Setting the combobox field as we have reseted the form.																														
														systemNameCombo.displayField=systemName;
														//systemNameCombo.valueField=systemName;
														systemNameCombo.setValue(systemName);
														
														combo.up('#createConnectionProfileFieldset').down('#systemCode').setValue(records[0].data.code);
														combo.up('#connectionProfileFormPanel').down('#connectionProfileBtnContainer').down('#testTCAttributeBtn').setVisible(true);
														
														combo.up('#createConnectionProfileFieldset').down('#proxyEnabledFlag').setVisible(AdminConsole.Constants.STATUS_TRUE);
														combo.up('#createConnectionProfileFieldset').down('#proxy').setVisible(AdminConsole.Constants.STATUS_TRUE);												
														combo.up('#createConnectionProfileFieldset').down('#proxyPort').setVisible(AdminConsole.Constants.STATUS_TRUE);												
														combo.up('#createConnectionProfileFieldset').down('#proxyUser').setVisible(AdminConsole.Constants.STATUS_TRUE);												
														combo.up('#createConnectionProfileFieldset').down('#proxyPassword').setVisible(AdminConsole.Constants.STATUS_TRUE);
														
														combo.up('#createConnectionProfileFieldset').down('#databasePartition').setVisible(AdminConsole.Constants.STATUS_FALSE);
														combo.up('#connectionProfileFormPanel').down('#connectionProfileBtnContainer').down('#tbspacerUpdate').hidden=true;
														//INITIAL CONSUMPTION VALUE SHOULD ALWAYS BE ZERO. 						
														teamCenterFieldset.down('#vendContLicenseConsume').setValue(0);
														
														
													}else if(AdminConsole.Constants.SUGARCRM.toUpperCase() == systemName.toUpperCase()){
														console.log('SUGARCRM selected.');
														//teamCenterFieldset.defaults.allowBlank = true;
														teamCenterFieldset.setVisible(false);
														
														
														connectionProfileForm.reset();
														systemNameCombo.displayField=systemName;
														//systemNameCombo.valueField=systemName;
														systemNameCombo.setValue(systemName);
														
														combo.up('#createConnectionProfileFieldset').down('#systemCode').setValue(records[0].data.code);
														combo.up('#connectionProfileFormPanel').down('#connectionProfileBtnContainer').down('#testTCAttributeBtn').setVisible(false);
														
														combo.up('#createConnectionProfileFieldset').down('#proxyEnabledFlag').setVisible(AdminConsole.Constants.STATUS_TRUE);
														combo.up('#createConnectionProfileFieldset').down('#proxy').setVisible(AdminConsole.Constants.STATUS_TRUE);												
														combo.up('#createConnectionProfileFieldset').down('#proxyPort').setVisible(AdminConsole.Constants.STATUS_TRUE);												
														combo.up('#createConnectionProfileFieldset').down('#proxyUser').setVisible(AdminConsole.Constants.STATUS_TRUE);												
														combo.up('#createConnectionProfileFieldset').down('#proxyPassword').setVisible(AdminConsole.Constants.STATUS_TRUE);
														
														combo.up('#createConnectionProfileFieldset').down('#databasePartition').setVisible(AdminConsole.Constants.STATUS_FALSE);
													}else if(AdminConsole.Constants.SAP.toUpperCase() == systemName.toUpperCase()){
														console.log('SAP selected.');
														//teamCenterFieldset.defaults.allowBlank = true;
														teamCenterFieldset.setVisible(false);
														
														connectionProfileForm.reset();
														
														systemNameCombo.displayField=systemName;
														//systemNameCombo.valueField=systemName;
														systemNameCombo.setValue(systemName);
														
														combo.up('#createConnectionProfileFieldset').down('#systemCode').setValue(records[0].data.code);
														combo.up('#connectionProfileFormPanel').down('#connectionProfileBtnContainer').down('#testTCAttributeBtn').setVisible(false);
														
														combo.up('#createConnectionProfileFieldset').down('#proxyEnabledFlag').setVisible(AdminConsole.Constants.STATUS_TRUE);
														combo.up('#createConnectionProfileFieldset').down('#proxy').setVisible(AdminConsole.Constants.STATUS_TRUE);												
														combo.up('#createConnectionProfileFieldset').down('#proxyPort').setVisible(AdminConsole.Constants.STATUS_TRUE);												
														combo.up('#createConnectionProfileFieldset').down('#proxyUser').setVisible(AdminConsole.Constants.STATUS_TRUE);												
														combo.up('#createConnectionProfileFieldset').down('#proxyPassword').setVisible(AdminConsole.Constants.STATUS_TRUE);
														
														combo.up('#createConnectionProfileFieldset').down('#databasePartition').setVisible(AdminConsole.Constants.STATUS_FALSE);
													}
													else if(AdminConsole.Constants.SCF_DATABASE.toUpperCase() == systemName.toUpperCase()){
														console.log('SCF selected.');
														//teamCenterFieldset.defaults.allowBlank = true;
														teamCenterFieldset.setVisible(false);
														
														connectionProfileForm.reset();
														
														systemNameCombo.displayField=systemName;
														//systemNameCombo.valueField=systemName;
														systemNameCombo.setValue(systemName);
														combo.up('#createConnectionProfileFieldset').down('#databasePartition').setVisible(AdminConsole.Constants.STATUS_TRUE);
														combo.up('#createConnectionProfileFieldset').down('#systemCode').setValue(records[0].data.code);
														combo.up('#connectionProfileFormPanel').down('#connectionProfileBtnContainer').down('#testTCAttributeBtn').setVisible(false);
														combo.up('#createConnectionProfileFieldset').down('#proxyEnabledFlag').setVisible(AdminConsole.Constants.STATUS_FALSE);
														combo.up('#createConnectionProfileFieldset').down('#proxy').setVisible(AdminConsole.Constants.STATUS_FALSE);												
														combo.up('#createConnectionProfileFieldset').down('#proxyPort').setVisible(AdminConsole.Constants.STATUS_FALSE);												
														combo.up('#createConnectionProfileFieldset').down('#proxyUser').setVisible(AdminConsole.Constants.STATUS_FALSE);												
														combo.up('#createConnectionProfileFieldset').down('#proxyPassword').setVisible(AdminConsole.Constants.STATUS_FALSE);
														
														//combo.up('#createConnectionProfileFieldset').down('#databasePartition').setVisible(AdminConsole.Constants.STATUS_TRUE);
														
														//combo.up('#createConnectionProfileFieldset').down('#').setVisible(false);
													}
													console.log('Inside system name combo box select listener:End');	
												}
											}
								},
								
								
								
								{
									allowBlank : false,
									fieldLabel : fetch.label.username+fetch.label.required,
									name : 'userName',
									emptyText : fetch.label.username,
									//value :'infodba'
								},
								{
									allowBlank : false,
									fieldLabel :  fetch.label.Password+fetch.label.required,
									name : 'password',
									emptyText : fetch.label.Password,
									//inputType : 'password',
									//value :'infodba'
								},
								
									{
										allowBlank : false,
										fieldLabel : fetch.label.systemUrl+fetch.label.required,
										name : 'sysUrl',
										emptyText : fetch.label.systemUrl,
										//value :'http://172.18.1.32:10001/tc'
									},
									{
										//allowBlank : false,
										fieldLabel : fetch.label.databasePartition+fetch.label.required,
										name : 'databasePartition',
										itemId:'databasePartition',
										emptyText : fetch.label.databasePartition,
										hidden:true
									//value :'infodba'
									},
									{
										allowBlank : false,
										xtype:'checkbox',
										fieldLabel : fetch.label.isProxyEnabled,
										itemId:'proxyEnabledFlag',
										name : 'proxyEnabledFlag',
										emptyText : fetch.label.isProxyEnabled,
										checked : false,
										listeners:{
											change: function(me, newValue, oldValue, eOpts){
												console.log(newValue);
												//console.log(me);
												//console.log(me.up('#createConnectionProfileFieldset'));
												var createConnectionProfileFieldset = me.up('#createConnectionProfileFieldset');
												if(newValue){												
													createConnectionProfileFieldset.down('#proxy').setDisabled(AdminConsole.Constants.STATUS_FALSE);												
													createConnectionProfileFieldset.down('#proxyPort').setDisabled(AdminConsole.Constants.STATUS_FALSE);												
													createConnectionProfileFieldset.down('#proxyUser').setDisabled(AdminConsole.Constants.STATUS_FALSE);												
													createConnectionProfileFieldset.down('#proxyPassword').setDisabled(AdminConsole.Constants.STATUS_FALSE);
													
												}else{
													createConnectionProfileFieldset.down('#proxy').setDisabled(AdminConsole.Constants.STATUS_TRUE);
													createConnectionProfileFieldset.down('#proxyPort').setDisabled(AdminConsole.Constants.STATUS_TRUE);												
													createConnectionProfileFieldset.down('#proxyUser').setDisabled(AdminConsole.Constants.STATUS_TRUE);												
													createConnectionProfileFieldset.down('#proxyPassword').setDisabled(AdminConsole.Constants.STATUS_TRUE);												
												}
												
											}
										}
										
									},
									{
										allowBlank : false,
										fieldLabel : fetch.label.proxy+fetch.label.required,
										name : 'proxy',
										itemId:'proxy',
										emptyText : fetch.label.proxy,									
										regexText:fetch.label.enaterNum,
										disabled:true
									},{
										allowBlank : false,
										fieldLabel : fetch.label.proxyPort+fetch.label.required,
										name : 'proxyPort',
										itemId:'proxyPort',
										emptyText : fetch.label.proxyPort,									
										regexText:fetch.label.enaterNum,
										disabled:true
									},
									{
										
										fieldLabel : fetch.label.proxyUser,
										name : 'proxyUser',
										itemId:'proxyUser',
										emptyText : fetch.label.proxyUser,									
										regexText:fetch.label.enaterNum,
										disabled:true
									},{
										
										fieldLabel : fetch.label.proxyPassword,
										name : 'proxyPassword',
										itemId:'proxyPassword',
										emptyText : fetch.label.proxyPassword,									
										regexText:fetch.label.enaterNum,
										//inputType : 'password',
										disabled:true
									},								
								{
									
									fieldLabel : fetch.label.systemIp+fetch.label.required,
									name : 'ipAddress',
									emptyText : fetch.label.systemIp,										
									regexText:fetch.label.enaterNum,
									hidden :true					
								},{
									
									fieldLabel : fetch.label.port+fetch.label.required,
									name : 'port',
									emptyText : fetch.label.port,							
									regexText:fetch.label.enaterNum,
									hidden :true					
								},{
									
									fieldLabel : fetch.label.protocol,
									name : 'protocol',
									emptyText : fetch.label.protocol,
									hidden:true,
									regexText:fetch.label.enaterNum	
								}
								
                            ]
                        },
						{
							xtype: 'fieldset',
							itemId:'createConnProfileTeamCenterConfigFieldset',
                            border: 0, 
							//width : 500,
							bodyPadding: '10 10 10 10',
                            layout: {                               
								type : 'table',
								columns : 2,                              
                            },
							defaults:{
								xtype : 'textfield',
								padding:'7 7 7 7',
							},
							fieldDefaults:{
								msgTarget:'side'
							},
							//title:fetch.label.teamCenterConfig,
							//titleAlign: 'center',
							
							items: [
									{
										
										xtype:'checkbox',
										fieldLabel : fetch.label.withoutClassification,
										itemId:'withoutClassification',
										name : 'withoutClassification',
										
										listeners:{
											change: function(me, newValue, oldValue, eOpts){
												console.log(newValue);
												
												var createConnectionProfileFieldset = me.up('#connectionProfileDetail');
												if(newValue){		
												createConnectionProfileFieldset.down('#commCodeAttr').setDisabled(AdminConsole.Constants.STATUS_TRUE);
												createConnectionProfileFieldset.down('#classStatusRootClassId').setDisabled(AdminConsole.Constants.STATUS_TRUE);												
												createConnectionProfileFieldset.down('#contRoleRootClassId').setDisabled(AdminConsole.Constants.STATUS_TRUE);												
												createConnectionProfileFieldset.down('#classStatAttr').setDisabled(AdminConsole.Constants.STATUS_TRUE);
												
												createConnectionProfileFieldset.down('#contRoleAttr').setDisabled(AdminConsole.Constants.STATUS_TRUE);
												createConnectionProfileFieldset.down('#classificationClassName').setDisabled(AdminConsole.Constants.STATUS_TRUE);												
												createConnectionProfileFieldset.down('#maxNoOfRoles').setDisabled(AdminConsole.Constants.STATUS_TRUE);												
												createConnectionProfileFieldset.down('#testTCAttributeBtn').setDisabled(AdminConsole.Constants.STATUS_TRUE);
													
													
												}else{
												
												createConnectionProfileFieldset.down('#commCodeAttr').setDisabled(AdminConsole.Constants.STATUS_FALSE);
												createConnectionProfileFieldset.down('#classStatusRootClassId').setDisabled(AdminConsole.Constants.STATUS_FALSE);												
												createConnectionProfileFieldset.down('#contRoleRootClassId').setDisabled(AdminConsole.Constants.STATUS_FALSE);												
												createConnectionProfileFieldset.down('#classStatAttr').setDisabled(AdminConsole.Constants.STATUS_FALSE);
												
												createConnectionProfileFieldset.down('#contRoleAttr').setDisabled(AdminConsole.Constants.STATUS_FALSE);
												createConnectionProfileFieldset.down('#classificationClassName').setDisabled(AdminConsole.Constants.STATUS_FALSE);												
												createConnectionProfileFieldset.down('#maxNoOfRoles').setDisabled(AdminConsole.Constants.STATUS_FALSE);												
												createConnectionProfileFieldset.down('#testTCAttributeBtn').setDisabled(AdminConsole.Constants.STATUS_FALSE);
																									
												}
												
											}
										}
										
									},
									{
										//allowBlank : false,
										fieldLabel : fetch.label.commodityCodeAttribute+fetch.label.required,
										name : 'commCodeAttr',
										itemId : 'commCodeAttr',
										emptyText : fetch.label.commodityCodeAttribute,
										//value:'ICM',
									},
									{
										//allowBlank : false,
										fieldLabel : fetch.label.classStatusRootClassId+fetch.label.required,
										name : 'classStatusRootClassId',
										itemId : 'classStatusRootClassId',
										emptyText : fetch.label.classStatusRootClassId,
										//value:'-10002',
									},
									{
										//allowBlank : false,
										fieldLabel : fetch.label.contRoleRootClassId+fetch.label.required,
										name : 'contRoleRootClassId',
										itemId : 'contRoleRootClassId',
										emptyText : fetch.label.contRoleRootClassId,
										//value:'-10003'
									},								
									{
										//allowBlank : false,
										fieldLabel : fetch.label.classificationStatusAttribute+fetch.label.required,
										name : 'classStatAttr',
										itemId : 'classStatAttr',
										emptyText : fetch.label.classificationStatusAttribute
									},
									{
										//allowBlank : false,
										fieldLabel : fetch.label.contactRoleAttribute+fetch.label.required,
										name : 'contRoleAttr',
										itemId : 'contRoleAttr',
										emptyText : fetch.label.contactRoleAttribute																	
									},
									{
										allowBlank : false,
										fieldLabel : fetch.label.classificationClassName+fetch.label.required,
										name : 'classificationClassName',
										itemId : 'classificationClassName',
										emptyText : fetch.label.classificationClassName																	
									},
									{
										allowBlank : false,
										xtype: 'numberfield',
										fieldLabel : fetch.label.maxNoOfRoles+fetch.label.required,
										name : 'maxNoOfRoles',
										editable : false,
										itemId : 'maxNoOfRoles',
										minValue:0,
										maxValue:10,
										emptyText : fetch.label.maxNoOfRoles
									},
									{
										//allowBlank : false,
										xtype: 'numberfield',
										fieldLabel : fetch.label.vendorContactLicenses+fetch.label.required,
										name : 'vendContLicense',
										itemId : 'vendContLicense',
										emptyText : fetch.label.vendorContactLicenses
									},
									{
										//allowBlank : false,
										xtype: 'numberfield',
										fieldLabel : fetch.label.vendorContactLicensesConsumed+fetch.label.required,
										itemId:'vendContLicenseConsume',
										name : 'vendContLicenseConsume',
										emptyText : fetch.label.vendorContactLicensesConsumed,
										readOnly: true
									},
							
							]						
						}
						
                    ]
                },{
                    xtype: 'tbspacer',
                    height: 10
                },
					{
						xtype: 'container',
						bodyPadding: '10 10 10 10',
						itemId:'connectionProfileBtnContainer',
						layout: {
							type: 'hbox',
							align: 'center',
							pack: 'center'
						},
						items: [							
							{
								xtype: 'button',
								text: fetch.label.testConnection,					
								action : 'testConnectionProfile',
								itemId:	'testConnectionProfileBtn',							
								//ui:'supcon-submit',					
								minWidth:80,
								height:30,
								style:{																
									'box-shadow': '1px 1px 3px #000'
								},					
								margin:'5 0 5 0'
							},{ xtype: 'tbspacer', width: 10 },
							{
								xtype: 'button',
								text: fetch.label.testTCAttribute,					
								action : 'testTCAttribute',
								itemId:	'testTCAttributeBtn',							
								//ui:'supcon-submit',					
								minWidth:80,
								height:30,
								style:{																
									'box-shadow': '1px 1px 3px #000'
								},					
								margin:'5 0 5 0'
							},{ xtype: 'tbspacer', itemId:'tbspacerSave',width: 10 },
							{
								xtype: 'button',
								text: fetch.label.SaveButton,					
								action : 'saveConnectionProfile',
								itemId:	'saveConnectionProfileBtn',							
								//ui:'supcon-submit',					
								minWidth:80,
								height:30,
								style:{																
									'box-shadow': '1px 1px 3px #000'
								},					
								margin:'5 0 5 0',
								hidden : true,
							},{ xtype: 'tbspacer', itemId:'tbspacerUpdate',width: 10 },
							{
								xtype: 'button',
								text: fetch.label.UpdateButton,					
								action : 'updateConnectionProfile',
								itemId:	'updateConnectionProfileBtn',							
								//ui:'supcon-submit',					
								minWidth:80,
								height:30,
								style:{																
									'box-shadow': '1px 1px 3px #000'
								},					
								margin:'5 0 5 0',
								hidden : true,
							},{ xtype: 'tbspacer', width: 10 },
							{
								xtype: 'button',
								text: fetch.label.CancelButton,					
								action : 'cancelConnectionProfile',																
								//ui:'supcon-submit',					
								minWidth:80,
								height:30,
								style:{																
									'box-shadow': '1px 1px 3px #000'
								},					
								margin:'5 0 5 0'
							},{ xtype: 'tbspacer', width: 10 },
							 
							{
								xtype: 'button',
								text: fetch.label.DeleteButton,					
								action : 'deleteConnectionProfile',
								itemId:	'deleteConnectionProfileBtn',							
								//ui:'supcon-submit',					
								minWidth:80,
								height:30,
								style:{																
									'box-shadow': '1px 1px 3px #000'
								},					
								margin:'5 0 5 0',
								hidden:true
							}
							
						]
					},				
			]
		}	
		]
       

});
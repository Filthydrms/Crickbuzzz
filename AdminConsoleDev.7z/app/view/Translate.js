Ext.define('AdminConsole.view.Translate', {
    extend: 'Ext.panel.Panel',
	xtype:'translate',
	itemId:'translate',
	id:'translate',
    requires: [
        'Ext.toolbar.Toolbar',
        'Ext.button.Button',
        'Ext.menu.Menu',
        'Ext.menu.Item',
        'Ext.form.Panel',
        'Ext.form.FieldSet',
        'Ext.form.field.Text',
        'Ext.toolbar.Spacer',
		//'Ext.form.field.ComboBoxView'
    ],

    title: '',
	layout: {
		type : 'fit',
		//align : 'stretch',
		//pack: 'stretch'
	},
	style:{
		  margin:'10 10 10 10'
		  },
	
	//autoScroll:true,
	//scrollable:'vertical',
	items:[{
                    xtype: 'panel',
					width : '100%',
					border:true,
                    bodyPadding: '10 10 10 10',
                    title: '',
                    layout: {
                        type: 'vbox',
                        align: 'center'
                    },
					//autoScroll:true,
					//overflowX: 'scroll',
				items: [
                {
                    xtype: 'form',
                    width : 750,
					border:true,
                    bodyPadding: '10 10 10 10',
					itemId:'translateForm',
					bodyStyle:{
					'background-color':'#f6f6f6',
				    },
				
                    title: fetch.label.translate,
                    titleAlign: 'center',
                    layout: {
                        type: 'vbox',
                        align: 'center',
                        //pack: 'center'
						
                    },
					//autoScroll:true,
                    items: [
                        {
                            xtype: 'fieldset',
                            border: 0, 
							//width : 500,
							bodyPadding: '10 10 10 10',
                            layout: {
                               
								type : 'table',
								columns : 3,
                              
                            },
							defaults:{
									labelWidth:70,
									//width:300
							},
                            items: [
								{
									xtype: 'combobox',
									fieldLabel: fetch.label.entity+fetch.label.required,
									name: 'entity',
									itemId:'entity',
									queryCaching:false,
									store:{
										fields: ['id','desc'],   
										
										proxy:{
											type:'ajax',
											url:'/supcon-supplier-mgmt/getAllEntity.htm',
											headers: {'Accept':'application/json' },
											reader:{
													type:'json',
											},
										}
										//data:[{'id':'1','name':'Section'},{'id':'2','name':'Question'}]
									},
									valueField: 'id',
									displayField: 'desc',
									//typeAhead: true,
									queryMode: 'remote',
									emptyText: fetch.label.selectEntity,
									allowBlank:false,
									msgTarget:'side',
									editable:false,
									listeners:{
										'beforeselect':function(combo,rec,index,e){
											//console.log('beforeselect');
											combo.up('#translateForm').down('#column').reset();
										
										}
									}
								},
								{
                                    xtype: 'tbspacer',
                                    width: 5
                                },
								{
									xtype: 'combobox',
									fieldLabel: fetch.label.column+fetch.label.required,
									name: 'column',
									itemId:'column',
									store:{
										fields: ['id','desc'],   
										proxy:{
											type:'ajax',
											url:'/supcon-supplier-mgmt/getColumnForEntity.htm',
											headers: {'Accept':'application/json' },
											reader:{
													type:'json',
											},
										}
										//data:[{'id':'1','name':'name'},{'id':'2','name':'description'}]
									},
									listeners:{
										'beforequery':function(qplan,e){
											//console.log('inside column combo');
											
											var entityCombo=qplan.combo.up('#translateForm').down('#entity');
											
											if(entityCombo.getValue()){
												qplan.query=entityCombo.getValue();
											}else{
												return false;
											}
										}
									},
									valueField: 'id',
									displayField: 'desc',
									//typeAhead: true,
									queryMode: 'remote',
									emptyText: fetch.label.selectColumn,
									allowBlank:false,
									msgTarget:'side',
									editable:false,
									labelWidth:170
								},                              
								{
									xtype: 'combobox',
									fieldLabel: fetch.label.language+fetch.label.required,
									name: 'lang',
									itemId: 'lang',
									queryCaching:false,
									store:{
										fields: ['code','name'],   
										proxy:{
											type:'ajax',
											url:'/supcon-supplier-mgmt/getAllLanguageExceptDefault.htm',
											headers: {'Accept':'application/json' },
											reader:{
													type:'json',
											},
										}
										//data:[{'id':'1','name':'French'},{'id':'2','name':'German'}]
									},
									valueField: 'code',
									displayField: 'name',
									//typeAhead: true,
									queryMode: 'remote',
									emptyText: fetch.label.selectLang,
									allowBlank:false,
									editable:false,
									msgTarget:'side',
								},
								{
                                    xtype: 'tbspacer',
                                    width: 5
                                },
								{
                                    xtype: 'tbspacer',
                                    width: 5
                                },
								{
									
                                    xtype: 'textfield',
									name:'search',
                                    fieldLabel: fetch.label.search,									
									emptyText: fetch.label.searchText,
									
                                }					
                            ]
                        },
					    {
                            xtype: 'container',
							bodyPadding: '10 10 10 10',
							//itemId:'createRoleButtonContainer',
                            layout: {
                                type: 'hbox',
                                align: 'center',
                                pack: 'center'
                            },
                            items: [
                                {
                                    xtype: 'button',
                                    text: fetch.label.search,
									action:'searchTranslatedColumn'
                                },
                                {
                                    xtype: 'tbspacer',
                                    width: 10
                                },
                                
                                {
                                    xtype: 'button',
                                    text: fetch.label.cancel,
									action:'cancelButton'
                                }
                            ]
                        },	
					]
				},
				{
							xtype: 'tbspacer',
							height: 10
				},
				{
					xtype: 'gridpanel',
					width : 750,
					title: fetch.label.list,
					titleAlign: 'center',
					border:true,
					itemId:'searchTranslatedColumnResult',
					columns: [															
						{
						  xtype: 'gridcolumn',
						  dataIndex: 'code', 
						  text: fetch.label.code,
						  flex: 1
						},

						{
							xtype: 'gridcolumn',
							dataIndex: 'actual',							
							text: fetch.label.actual,
							flex: 1
						},
						{	
							xtype: 'gridcolumn',
							dataIndex: 'translated',							
							text: fetch.label.translated,
							flex: 1
						},							
					],							
					dockedItems : [ {
						xtype : 'pagingtoolbar',
						store : 'QueryTranslatedStore',/* store same as the grid */
						dock : 'bottom',
						displayInfo : true
					} ],
					store:'QueryTranslatedStore',
					hidden:true
				}
            ]
		}	
	]
});
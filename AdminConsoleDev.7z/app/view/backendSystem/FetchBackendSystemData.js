/*View for qualification.*/
Ext.define('AdminConsole.view.backendSystem.FetchBackendSystemData', {
	extend : 'Ext.panel.Panel',
	xtype : 'fetchBackendSystemData',
	
	itemId:'fetchBackendSystemData',
	layout : {
		type : 'vbox',
		align : 'center'
		//pack:'center'
	},
	//width:'100%',
	style:{
		margin:'4% 0 0 0'
	},
	autoScroll:true,
	items : [
				{
					xtype:'container',
					width:'100%',
					layout:{
						type:'vbox',
						align:'center'
					},
					items:[
							{
								bodyCls:'logintitle',
								style:{},
								width:750,
								html:	fetch.label.fetchBackendSystemData 
									//"Pending Approval Notifications"
									+'<div class="logindotSeparator"></div>'
									+'<br />'
							}				
						]
				},
				{
					xtype: 'button',
					text: fetch.label.fetchBackendSystemData,	
					itemId :'fetchBackendSystemDataBtn',
					action : 'fetchBackendSystemData',
					//ui:'supcon-submit',					
					minWidth:80,
					height:30,
					style:{																
						'box-shadow': '1px 1px 3px #000'
					},					
					margin:'5 0 5 0'
				}
	]
	
});

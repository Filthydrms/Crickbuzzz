Ext.define('AdminConsole.view.backendSystem.StatusLogGrid', {
	extend: 'Ext.grid.Panel',
	xtype: 'statusLogGrid',
	itemId:'statusLogGridPanel',
	
	//store: Ext.data.StoreManager.lookup('CommodityLogStore'),
	
	store:{
			model : 'AdminConsole.model.StatusLogModel',
			proxy: {
			type: 'memory',
			reader: {
				type: 'json',
				root: ''
			},
			listeners: {
                exception: function(proxy, response, operation){
                    Ext.MessageBox.show({
                        title: fetch.label.remoteException,
                        msg: operation.getError(),
                        buttons: Ext.Msg.OK
                    });
                }
            }
		}
	},
	
	title: fetch.label.statusLog,
	titleAlign: 'center',

	autoScroll : true,
	width:800,
	minHeight: 100,
	maxHeight:200,
	columnLines : true,
	viewConfig : {
		stripeRows : true
	},
	style : {
		'font-size' : 13,
		'font-family' : 'Verdana, Geneva, sans-serif',
		'color' : '#000000'
	},	
	columns: [
		{
			dataIndex: 'code',
			text:  fetch.label.code,
			sortable : true,
			flex: 1
		},
		{
			dataIndex: 'description',
			text:  fetch.label.description,
			sortable : true,
			flex: 1
		},
		{
			dataIndex: 'action',
			text:  fetch.label.action,
			sortable : true,
			flex: 1
		}		
	]
	
	
});
/*View for qualification.*/
Ext.define('AdminConsole.view.backendSystem.FetchBackendSystemDataLog', {
	extend : 'Ext.panel.Panel',
	xtype : 'fetchBackendSystemDataLog',
	
	itemId:'fetchBackendSystemDataLog',
	 requires: [
        'Ext.toolbar.Toolbar',
        'Ext.button.Button',
        'Ext.menu.Menu',
        'Ext.menu.Item',
        'Ext.form.Panel',
        'Ext.form.FieldSet',
        'Ext.form.field.Text',
        'Ext.toolbar.Spacer'
    ],
	
    title: '',
	layout: {
		type : 'fit',
		//align : 'stretch',
		//pack: 'stretch'
	},
	style:{
		  margin:'10 10 10 10'
		  },
	
	autoScroll:true,
	
	items:[{
				xtype: 'panel',
				width : '100%',
				border:true,
				bodyPadding: '10 10 10 10',
				title: '',
				layout: {
					type: 'vbox',
					align: 'center'
				},
				autoScroll:true,
				items: [
						{
							xtype: 'commodityLogGrid'
						},
						{
							xtype: 'tbspacer',
							width: 10
						},
						{
							xtype: 'statusLogGrid'
						},
						{
							xtype: 'tbspacer',
							width: 10
						},
						{
							xtype: 'roleLogGrid'
						},{
							xtype: 'tbspacer',
							width: 10
						},{
							xtype: 'panel',
							bodyCls:'logintitle',
							itemId:'messagePanel',
							hidden:true
						},{
							xtype: 'tbspacer',
							width: 10
						},{
                            xtype: 'container',
							itemId:'buttonContainer',
							layout: {
                                type: 'hbox',
                                align: 'center',
                                pack: 'center'
                            },
                            items: [{
										xtype: 'button',
										text: fetch.label.downloadLog,
										itemId:'downloadLogBtn',
										hidden:true,
										action:'downloadBackendSysDataLog'
									}]
						}
					]
		}]
});

Ext.define('AdminConsole.view.ClsConfig',{
  extend: 'Ext.panel.Panel',
  xtype:'cls-Config',
  itemId:'clsConfig',
		
		
		requires: [
        'Ext.toolbar.Toolbar',
        'Ext.button.Button',
        'Ext.menu.Menu',
        'Ext.menu.Item',
        'Ext.form.Panel',
        'Ext.form.FieldSet',
        'Ext.form.field.Text',
        'Ext.toolbar.Spacer',
		'Ext.form.ComboBox',
			
    ],
    title: '',
	margin: '10 10 10 10',
	layout: {
		type : 'fit',
	}, 
		  title:'',
		   items:[
					{
		  
						xtype: 'panel',
					//	width:400,
					//	border:true,
                        bodyPadding: '10 10 10 10',
						title: '',
						layout: {
							type: 'vbox',
							align: 'center'
						},
						bodyStyle:{
						'background-color':'#f6f6f6',
						},
						 bodyPadding: '10 10 10 10',
						// autoScroll:true,
						
						items: [
						{
						xtype: 'form',
						width : 700,
						//height:300,
						border:true,
						 bodyPadding: '10 20 10 20',
						id:'clsConfigForm',
						title: fetch.label.clsConfig,
						titleAlign: 'center',
						 layout: {
							type: 'vbox',
							align: 'center',
							pack: 'center'
						},
						
						 items: [
							{
								xtype: 'fieldset',
								border: 0, 
								bodyPadding: '10 10 10 10',
								layout : {
										type : 'table',
										columns : 3,
										},
									
								items:[
								      
									  {
										xtype:'textfield',
										fieldLabel:fetch.label.clsId,
										hidden:true,
										name:'classConfId',
									  },
									  
									{
									    allowBlank:false,
										xtype:'combobox',
										fieldLabel:fetch.label.levels+fetch.label.mandatory,
										name:'levels',
										editable:false,
										store:'ClsConfigStore', 
										queryMode: 'local',
										displayField: 'Value',
										valueField: 'Id',
										labelWidth:90,
										emptyText:fetch.label.selLevel,
										listeners:{			
													select:function(combo, records, eOpts){
													console.log("inside combobox");
													//console.log(combo.getValue('levels'));
													var form=combo.up('#clsConfigForm').getForm();
													//console.log(form.findField('label1Text'));
													//console.log(form.findField('Label1Pattern'));
														
														if(combo.getValue('levels')==AdminConsole.Constants.ONE)
														{
															form.findField('label1Text').allowBlank=false,
															form.findField('label1Text').setFieldLabel(fetch.label.label1Text+fetch.label.mandatory);
															form.findField('Label1Pattern').allowBlank=false,
															form.findField('Label1Pattern').setFieldLabel(fetch.label.label1Pattern+fetch.label.mandatory);
															form.findField('label2Text').allowBlank=true,
															form.findField('label2Text').setFieldLabel(fetch.label.label2Text);
															form.findField('Label2Pattern').allowBlank=true,
															form.findField('Label2Pattern').setFieldLabel(fetch.label.label2Pattern);
															form.findField('label3Text').allowBlank=true,
															form.findField('label3Text').setFieldLabel(fetch.label.label3Text);
															form.findField('Label3Pattern').allowBlank=true,
															form.findField('Label3Pattern').setFieldLabel(fetch.label.label3Pattern);
															form.findField('label4Text').allowBlank=true,
															form.findField('label4Text').setFieldLabel(fetch.label.label4Text);
															form.findField('Label4Pattern').allowBlank=true
															form.findField('Label4Pattern').setFieldLabel(fetch.label.label4Pattern);
														}
														else if(combo.getValue('levels')==AdminConsole.Constants.TWO)
														{
															
															form.findField('label1Text').allowBlank=false,
															form.findField('label1Text').setFieldLabel(fetch.label.label1Text+fetch.label.mandatory);
															form.findField('Label1Pattern').allowBlank=false,
															form.findField('Label1Pattern').setFieldLabel(fetch.label.label1Pattern+fetch.label.mandatory);
															form.findField('label2Text').allowBlank=false,
															form.findField('label2Text').setFieldLabel(fetch.label.label2Text+fetch.label.mandatory);
															form.findField('Label2Pattern').allowBlank=false,
															form.findField('Label2Pattern').setFieldLabel(fetch.label.label2Pattern+fetch.label.mandatory);
															form.findField('label3Text').allowBlank=true,
															form.findField('label3Text').setFieldLabel(fetch.label.label3Text);
															form.findField('Label3Pattern').allowBlank=true,
															form.findField('Label3Pattern').setFieldLabel(fetch.label.label3Pattern);
															form.findField('label4Text').allowBlank=true,
															form.findField('label4Text').setFieldLabel(fetch.label.label4Text);
															form.findField('Label4Pattern').allowBlank=true
															form.findField('Label4Pattern').setFieldLabel(fetch.label.label4Pattern);
														}
														else if(combo.getValue('levels')==AdminConsole.Constants.THREE)
														{
														    form.findField('label1Text').allowBlank=false,
															form.findField('label1Text').setFieldLabel(fetch.label.label1Text+fetch.label.mandatory);
															form.findField('Label1Pattern').allowBlank=false,
															form.findField('Label1Pattern').setFieldLabel(fetch.label.label1Pattern+fetch.label.mandatory);
															form.findField('label2Text').allowBlank=false,
															form.findField('label2Text').setFieldLabel(fetch.label.label2Text+fetch.label.mandatory);
															form.findField('Label2Pattern').allowBlank=false,
															form.findField('Label2Pattern').setFieldLabel(fetch.label.label2Pattern+fetch.label.mandatory);
															form.findField('label3Text').allowBlank=false,
															form.findField('label3Text').setFieldLabel(fetch.label.label3Text+fetch.label.mandatory);
															form.findField('Label3Pattern').allowBlank=false,
															form.findField('Label3Pattern').setFieldLabel(fetch.label.label3Pattern+fetch.label.mandatory);
															form.findField('label4Text').allowBlank=true,
															form.findField('label4Text').setFieldLabel(fetch.label.label4Text);
															form.findField('Label4Pattern').allowBlank=true
															form.findField('Label4Pattern').setFieldLabel(fetch.label.label4Pattern);
														}
														else if(combo.getValue('levels')==AdminConsole.Constants.FOUR)
														{
														    form.findField('label1Text').allowBlank=false,
															form.findField('label1Text').setFieldLabel(fetch.label.label1Text+fetch.label.mandatory);
															form.findField('Label1Pattern').allowBlank=false,
															form.findField('Label1Pattern').setFieldLabel(fetch.label.label1Pattern+fetch.label.mandatory);
															form.findField('label2Text').allowBlank=false,
															form.findField('label2Text').setFieldLabel(fetch.label.label2Text+fetch.label.mandatory);
															form.findField('Label2Pattern').allowBlank=false,
															form.findField('Label2Pattern').setFieldLabel(fetch.label.label2Pattern+fetch.label.mandatory);
															form.findField('label3Text').allowBlank=false,
															form.findField('label3Text').setFieldLabel(fetch.label.label3Text+fetch.label.mandatory);
															form.findField('Label3Pattern').allowBlank=false,
															form.findField('Label3Pattern').setFieldLabel(fetch.label.label3Pattern+fetch.label.mandatory);
															form.findField('label4Text').allowBlank=false,
															form.findField('label4Text').setFieldLabel(fetch.label.label4Text+fetch.label.mandatory);
															form.findField('Label4Pattern').allowBlank=false,
															form.findField('Label4Pattern').setFieldLabel(fetch.label.label4Pattern+fetch.label.mandatory);
														}
							
									                }
													
												},	
									  },
										
										{
											 xtype:'tbspacer',
											 width:20
										},	
										{
											 xtype:'tbspacer',
											 width:20
										},	
										 
									   {
										xtype:'textfield',
										fieldLabel:fetch.label.label1Text,
										name:'label1Text',
										labelWidth:90,
										
										},
										{
											 xtype:'tbspacer',
											 width:20
										},
{
										xtype:'textfield',
										fieldLabel:fetch.label.label1Pattern,
										name:'Label1Pattern',
										labelWidth:90,
										width:330
									  },										
									 
									    {
											xtype:'textfield',
											fieldLabel:fetch.label.label2Text,
											name:'label2Text',
											labelWidth:90,
									     },
									   
									    {
											 xtype:'tbspacer',
											 width:20
										 },
										  {
										xtype:'textfield',
										fieldLabel:fetch.label.label2Pattern,
										name:'Label2Pattern',
										labelWidth:90,
										width:330
									  },
									   {
										xtype:'textfield',
										fieldLabel:fetch.label.label3Text,
										name:'label3Text',
										labelWidth:90,
									  },
									   {
											 xtype:'tbspacer',
											 width:20
										 },
									  {
										xtype:'textfield',
										fieldLabel:fetch.label.label3Pattern,
										name:'Label3Pattern',
										labelWidth:90,
										width:330
									  },
									  
									  {
										xtype:'textfield',
										fieldLabel:fetch.label.label4Text,
										name:'label4Text',
										labelWidth:90,
									  },
									  {
											 xtype:'tbspacer',
											 width:20
									  },
									  
									  {
										xtype:'textfield',
										fieldLabel:fetch.label.label4Pattern,
										name:'Label4Pattern',
										labelWidth:90,
										width:330
										
									  },
									  
									 
									],
																	
							},
							
							{
								  xtype:'container',
								  bodyPadding: '10 10 10 10',
								   layout: {
												type: 'hbox',
												align: 'center',
												pack: 'center'
										   },
								  
								  items:[
											{
											 xtype:'button',
											 name:'save',
											 text:fetch.label.save,
											 action:'saveClsConfAction',
											 },
											{
											 xtype:'tbspacer',
											 width:20
											},
											{
											 xtype:'button',
											 name:'cancel',
											 text:fetch.label.cancel,
											 action:'cancelButton'
											}
										]
					
							}, 
			
					],	

						}]
						
					}]
						


});
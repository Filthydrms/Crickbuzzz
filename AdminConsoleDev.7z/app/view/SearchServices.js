Ext.define('AdminConsole.view.SearchServices', {
    extend: 'Ext.panel.Panel',
	xtype:'searchServices',
	itemId : 'searchServices',
	bodyPadding : 10,
	width:500,
	items : [
				{
					xtype:'panel',
					layout : {
							type : 'hbox',
							align : 'center'
					},
					items:[
						
									
							{
										xtype : 'serviceGrid',
										title:fetch.label.availableService,
										titleAlign:'center',
										width:440,
										itemId:'availableService',
										store:'AvailbleServiceStore',
					
							},
							{
										xtype: 'container',
										bodyPadding: '10 10 10 10',
										width:30,
										height:300,
										itemId:'selectBasicFilterContainer',
										layout: {
											type: 'vbox',
											align: 'center',
											pack: 'center'
										},
										items: [
											{
												xtype : 'button',
												text : '>',
												itemId : 'selectAvaibleServiceBtn',
												action : 'selectAvaibleService'
											},
											{
												xtype: 'tbspacer',
												height: 10
											},
											{
												xtype : 'button',
												text : '<',
												itemId : 'selectAssignedServiceBtn',
												action : 'selectAssignedService'
											}
										]
							},
							{
							
									
									
										xtype : 'serviceGrid',
										store:'AssignedServiceStore',
										itemId:'assignedService',
										title:fetch.label.assignedService,
										titleAlign:'center',
										width:440										
							}	
						
						
					]
				},
				
				{
					xtype: 'container',
					bodyPadding: '10 10 10 10',
					margin:'10 0 0 0',
					layout: {
						type: 'hbox',
						align: 'center',
						pack: 'center'
					},
					items: [
						
						{
							xtype: 'button',
							text: fetch.label.cancel,
							action:'cancelButton'
						}
						
					]
				}
			] 
});
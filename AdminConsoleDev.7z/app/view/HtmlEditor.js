 Ext.define('AdminConsole.view.HtmlEditor', {
	extend : 'Ext.form.Panel',
	xtype : 'htmlEditor',
	itemId : 'htmlEditorPanel',
	requires : [ 'Ext.form.FieldSet'],
	bodyStyle:{
		background: '#F6F6F6'
	},
	
	//autoScroll:true,

	layout : {
		type : 'vbox',
		align:'center'
		
	},
	
	items : [	
				{
						xtype : 'form',
						itemId: 'html-editor-form',
						layout : {
							type : 'vbox',
							align:'center',
							pack:'center'
						},
						
						items : [					
						
								{
									xtype : 'fieldset',
									border : false,
									layout : {
										type : 'vbox',
										align : 'center'
									
									},
									items : [
								
								
										{
											xtype: 'htmleditor',
											name : 'htmlEditorField',
											itemId : 'htmlEditorField'
														
										},
									]
								},
								{	
									xtype:'panel',
									
									bodyStyle:{
										background:'#f6f6f6'
									},
									layout:{
										type:'hbox',
										align:'center',
										pack:'center'
									},
									items:[
											{
												xtype: 'button', 
												text: 'Ok',
												itemId:'htmlEditorBtn',
												action : 'htmlEditorSubmit',
												//ui:'supcon-submit',
												width:80,
												height:30,
												style:{
													'box-shadow': '1px 1px 3px #000'
												},
											}			
									]
								}
								
							]

				}				
				 
			]
});

Ext.define('AdminConsole.view.QueryPurchaseCategory', {
    extend: 'Ext.panel.Panel',
	xtype:'query-purchase-category',
	itemId:'query-purchase-category',
	id:'query-purchase-category',

    requires: [
        'Ext.toolbar.Toolbar',
        'Ext.button.Button',
        'Ext.menu.Menu',
        'Ext.menu.Item',
        'Ext.form.Panel',
        'Ext.form.FieldSet',
        'Ext.form.field.Text',
        'Ext.toolbar.Spacer',
        'Ext.grid.Panel',
        'Ext.grid.column.Column',
        'Ext.grid.View',
		'Ext.toolbar.Paging',
        'Ext.ux.ProgressBarPager',
    ],
	layout: {
		type : 'fit',
		
	},
	title: '',
	items:[{
                    xtype: 'panel',
                    title: '',
                    layout: {
                        type: 'vbox',
                        align: 'center'
                    },
					bodyStyle:{
					'background-color':'#f6f6f6',
				    },
					 bodyPadding: '10 10 10 10',
					 autoScroll:true,
					// overflowX: 'scroll',
            items: [
                {
                    xtype: 'form',
					width : 600,
				    //height: 320,
					border:true,
                   // margin: '10 200 10 200',
                    bodyPadding: '10 10 10 10',
					id:'queryPCForm',
                    title: fetch.label.qryPurCat,
                    titleAlign: 'center',
                    layout: {
                        type: 'vbox',
                        align: 'center',
                        pack: 'center'
                    },
                    items: [
                        {
                            xtype: 'fieldset',
                            border: 0,
                           /* layout: {
                               
									type: 'hbox',
									align: 'center',
									pack: 'center'
                              
                            },*/
							layout : {
									type : 'table',
									columns : 3,
									},
                            items: [
                               
                                {
                                    xtype: 'textfield',
									labelWidth:100,
                                    fieldLabel: fetch.label.code,
									name:'code'
                                },
								{
									xtype: 'tbspacer',
									width: 10
								},	
								{
                                    xtype: 'textfield',
									labelWidth:80,
                                    fieldLabel:fetch.label.name,
									name:'name'
                                },
								
								{
                                    xtype: 'textfield',
									labelWidth:100,
                                    fieldLabel: fetch.label.unspscField,
									name:'unspsc',
									
                                },
								{
									xtype: 'tbspacer',
									width: 10
								},
								
								{
										xtype : 'checkbox',
										// xtype: 'textfield',
										labelWidth:80,
										fieldLabel: fetch.label.published,
										name:'status',
										
										//margin:'0 25 0 25'
										//disabled:true,
								},
                            ]
                        },
						
                        {
                            xtype: 'container',
                            layout: {
                                type: 'hbox',
                                align: 'stretch',
                                pack: 'center'
                            },
                            items: [
                                {
                                    xtype: 'button',
                                    text: fetch.label.search,
									action:'searchButtonQueryScreen'
                                },
                                {
                                    xtype: 'tbspacer',
                                    width: 10
                                },
                                {
                                    xtype: 'button',
                                    text: fetch.label.cancel,
									action:'cancelButton'
                                }
                            ]
                        }
                    ]
                },
				{
                                    xtype: 'tbspacer',
                                    height: 10
                },
                {
                    xtype: 'gridpanel',
					width : 600,
				    //height: 320,
					//bodyPadding: '10 10 10 10',
                    //margin: '10 200 10 200',
                    title: fetch.label.purCatList,
                    titleAlign: 'center',
					id:'querySearchResultForm',
                    columns: [
                        {
                            xtype: 'gridcolumn',
                            dataIndex: 'code',
							//width : 100,
                            text: fetch.label.purchaseCatCode,
                            flex: 2
                        },
                        {
                            xtype: 'gridcolumn',
                            dataIndex: 'name',
							//width : 100,
                            text: fetch.label.purchaseCatName,
                            flex: 2
                        },
                        {
                            xtype: 'gridcolumn',
                            dataIndex: 'approver',
							//width : 100,
                            text: fetch.label.approver,
                            flex: 1
                        },
                        {
                            xtype: 'gridcolumn',
                            dataIndex: 'status',
							//width : 100,
                            text:fetch.label.status,
                            flex: 1
                        },
						{
                            xtype: 'gridcolumn',
                            dataIndex: 'purCatId',
							//width : 100,
                            text: 'purCatId',
							hidden:true,
                            flex: 1
                            
                        }
                    ],
					
					dockedItems : [ {
						xtype : 'pagingtoolbar',
						//id : 'supplier-grid-paging',
						store : 'QueryPurchaseCategoryStore',/* store same as the grid */
						dock : 'bottom',
						displayInfo : true
					} ],
					store:'QueryPurchaseCategoryStore',
					hidden:true
                }
            ]
			}
			]
       

});
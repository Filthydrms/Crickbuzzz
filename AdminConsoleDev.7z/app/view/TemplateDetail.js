 Ext.define('AdminConsole.view.TemplateDetail', {
	extend : 'Ext.form.Panel',
	xtype : 'templateDetail',
	itemId : 'templateDetail',
	requires : [ 'Ext.form.FieldSet'],
	layout : {
		type : 'vbox',
		align:'center'
		
	},
	
	items : [	
						
			{
				xtype : 'fieldset',
				border : false,
				layout : {
					type : 'vbox',
					align : 'center'
				
				},
				
				items : [
					{
						xtype: 'tbspacer',
						height: 10
					},
					{
									
						xtype: 'textfield',
						fieldLabel: 'Id',
						name:'templateId',						
						hidden:true
							
					},
					{
									
						xtype: 'textfield',
						fieldLabel: 'Id',
						name:'tempLangId',						
						hidden:true
							
					},
					{
						xtype: 'combobox',
						fieldLabel: fetch.label.language,//+fetch.label.required,
						name: 'lang',
						itemId: 'lang',
						queryCaching:false,
						store:{
							fields: ['code','name'],   
							proxy:{
								type:'ajax',
								url:'/supcon-supplier-mgmt/getAllLanguageExceptDefault.htm',
								headers: {'Accept':'application/json' },
								reader:{
										type:'json',
								},
							}												
						},
						valueField: 'code',
						displayField: 'name',
						queryMode: 'remote',
						emptyText: fetch.label.selectLang,
						//allowBlank:false,
						editable:false,
						msgTarget:'side',
						labelWidth:90,
						width:400,
						listeners:{
							'change':function( me, newValue, oldValue, eOpts ){
									var form = me.up('form').getForm();
									var temId= form.findField('templateId').getValue();
									if(newValue){
										form.findField('translatedSubject').setVisible(true);
										form.findField('translatedTemplateField').setVisible(true);
									}else{
										form.findField('translatedSubject').setVisible(false);
										form.findField('translatedTemplateField').setVisible(false);
									}
									var data = {
										'langCode':newValue,
										'templateId' : temId
									};
									
									AdminConsole.MyUtil.showMask(me.up('#templateDetail'),fetch.label.removing);
									Ext.Ajax.request({
										//headers : {'Content-Type':'application/json'},
										url : AdminConsole.Constants.baseURL + '/oem/getTemplateLangDetail.htm',
										params:data,
										async : true,
										timeout : 3600*1000,//1 hr
										success: function(response) {
													console.log(response.responseText);
													AdminConsole.MyUtil.hideMask();		
													if(response.responseText){
														var decodedData=Ext.JSON.decode(response.responseText);
																									
														form.findField('translatedSubject').setValue(decodedData.tempLangSubject);
														form.findField('translatedTemplateField').setValue(decodedData.tempLangBody);
														form.findField('tempLangId').setValue(decodedData.tempLangId);
													}else{
														form.findField('translatedSubject').setValue(null);
														form.findField('translatedTemplateField').setValue(null);
														form.findField('tempLangId').setValue(null);
													}
													
												
								
										},
										failure: function(form, action) {
											alert ('communcation failed.');
											AdminConsole.MyUtil.hideMask();
										}
									});
							}
						}
					},
					{
						xtype: 'textfield',
						name:'actualSubject',
						fieldLabel: fetch.label.subject + ' '+ fetch.label.required,
						labelWidth:90,
						width:400,
						allowBlank : false,
						msgTarget:'side'
						//readOnly:true,
					},
					{
						xtype: 'textfield',
						name:'translatedSubject',
						fieldLabel: fetch.label.translated+' '+fetch.label.subject +' '+ fetch.label.required,
						labelWidth:90,
						width:400,
						emptyText:fetch.label.emptySubject,
						hidden:true,
						itemId:'translatedSubject',
						allowBlank : false,
						msgTarget:'side'
					},
					{
						xtype: 'htmleditor',
						name : 'actualTemplateField',
						itemId :'actualTemplateField',
						fieldLabel: fetch.label.body +' '+ fetch.label.required,
						allowBlank : false,
						msgTarget:'side'
						//readOnly:true,
						
						
									
					},
					{
						xtype: 'htmleditor',
						name : 'translatedTemplateField',
						itemId :'translatedTemplateField',
						fieldLabel: fetch.label.translated+' '+fetch.label.body +' '+ fetch.label.required,	
						hidden:true,
						allowBlank : false,
						msgTarget:'side'
											
						
									
					},
				]
			},
			{	
				xtype:'panel',
				layout:{
					type:'hbox',
					align:'center',
					pack:'center'
				},
				items:[
						{
							xtype: 'button', 
							text: fetch.label.save,	
							action:'saveTemplateTransalation'					
							
						}			
				]
			}			 
		]
});

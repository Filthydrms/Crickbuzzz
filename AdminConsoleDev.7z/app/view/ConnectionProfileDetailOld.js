Ext.define('AdminConsole.view.ConnectionProfileDetailOld',{
	extend : 'Ext.panel.Panel',
	requires : ['Ext.form.*','Ext.ux.form.*','Ext.dom.Element','Ext.Function'],

	xtype: 'connectionProfileDetailOld',
	itemId: 'connectionProfileDetailOld',
	bodyPadding : 20,	
	
	items:[	{
				//itemId : 'classificationform',
				//itemId : 'connectionProfileForm',
				xtype : 'form',
                id:'connectionProfileFormOld',
				bodyStyle:{
					'background-color':'#f6f6f6',
				},				
				
				width : 500,
				height: 320,
				bodyPadding : '10 10 0 10',
				defaultType : 'textfield',			
	
				items:[
				{
					allowBlank : true,
					fieldLabel : fetch.label.systemId,
					name : 'systemId',
					itemId:'systemId',
					emptyText : fetch.label.systemId,										
					regexText:fetch.label.enaterNum,					
					hidden:true
				},{
					allowBlank : false,
					fieldLabel : fetch.label.systemCode+fetch.label.required,
					name : 'code',					
					itemId:'code',
					emptyText : fetch.label.systemCode,										
					regexText:fetch.label.enaterNum,
					msgTarget:'side',
					disabled:true					
				},{
					allowBlank : false,
					fieldLabel : fetch.label.systemName+fetch.label.required,
					name : 'name',
					emptyText : fetch.label.systemName,										
					regexText:fetch.label.enaterNum,
					msgTarget:'side'
				},{
					allowBlank : false,
					fieldLabel : fetch.label.systemUrl+fetch.label.required,
					name : 'sysUrl',
					emptyText : fetch.label.systemUrl,										
					msgTarget:'side'
				},{
					allowBlank : false,
					fieldLabel : fetch.label.systemIp+fetch.label.required,
					name : 'ipAddress',
					emptyText : fetch.label.systemIp,										
					regexText:fetch.label.enaterNum,
					msgTarget:'side',
					hidden :true					
				},{
					allowBlank : false,
					fieldLabel : fetch.label.port+fetch.label.required,
					name : 'port',
					emptyText : fetch.label.port,							
					regexText:fetch.label.enaterNum,
					msgTarget:'side',
					hidden :true					
				},{
					allowBlank : true,
					fieldLabel : fetch.label.protocol,
					name : 'protocol',
					emptyText : fetch.label.protocol,							
					regexText:fetch.label.enaterNum	
				},		
				{
					allowBlank : true,
					fieldLabel : fetch.label.proxy,
					name : 'proxy',
					emptyText : fetch.label.proxy,									
					regexText:fetch.label.enaterNum	
				},{
					allowBlank : true,
					fieldLabel : fetch.label.proxyPort,
					name : 'proxyPort',
					emptyText : fetch.label.proxyPort,									
					regexText:fetch.label.enaterNum	
				},
				{
					allowBlank : true,
					fieldLabel : fetch.label.proxyUser,
					name : 'proxyUser',
					emptyText : fetch.label.proxyUser,									
					regexText:fetch.label.enaterNum	
				},{
					allowBlank : true,
					fieldLabel : fetch.label.proxyPassword,
					name : 'proxyPassword',
					emptyText : fetch.label.proxyPassword,									
					regexText:fetch.label.enaterNum	
				},				
				{
					allowBlank : true,
					fieldLabel : fetch.label.commodityCodeAttribute,
					name : 'commCodeAttr',
					emptyText : fetch.label.commodityCodeAttribute,
					hidden : true
				},{
					allowBlank : true,
					fieldLabel : fetch.label.classificationStatusAttribute,
					name : 'classStatAttr',
					emptyText : fetch.label.classificationStatusAttribute,
					hidden : true
				},
				{
					allowBlank : true,
					fieldLabel : fetch.label.contactRoleAttribute,
					name : 'contRoleAttr',
					emptyText : fetch.label.contactRoleAttribute,
					hidden : true
				}
				
				],
				dockedItems: [{
					xtype: 'toolbar',
					dock: 'bottom',
					ui: 'footer',
					height:55,
					style:{
							'background-color':'#f6f6f6',
						},
						
					layout:{
						type:'hbox',
						align:'center',
						pack:'center'
					},
					bodyPadding:5,
					items: [
							//{ xtype: 'component', flex: 1,,height:5 },
							{
								xtype: 'button',
								text: fetch.label.testConnection,					
								action : 'testConnectionProfile',
                               	itemId:	'testConnectionProfileBtn',							
								//ui:'supcon-submit',					
								width:80,
								height:30,
								style:{																
									'box-shadow': '1px 1px 3px #000'
								},					
								margin:'5 0 5 0'
							},{ xtype: 'tbspacer', width: 10 },
							{
								xtype: 'button',
								text: fetch.label.testTCAttribute,					
								action : 'testTCAttribute',
                               	itemId:	'testTCAttributeBtn',							
								//ui:'supcon-submit',					
								width:80,
								height:30,
								style:{																
									'box-shadow': '1px 1px 3px #000'
								},					
								margin:'5 0 5 0'
							},{ xtype: 'tbspacer', width: 10 },
							{
								xtype: 'button',
								text: fetch.label.SaveButton,					
								action : 'saveConnectionProfile',
                               	itemId:	'saveConnectionProfileBtn',							
								//ui:'supcon-submit',					
								width:80,
								height:30,
								style:{																
									'box-shadow': '1px 1px 3px #000'
								},					
								margin:'5 0 5 0'
							},{ xtype: 'tbspacer', width: 10 },
							{
								xtype: 'button',
								text: fetch.label.CancelButton,					
								action : 'cancelConnectionProfile',																
								//ui:'supcon-submit',					
								width:80,
								height:30,
								style:{																
									'box-shadow': '1px 1px 3px #000'
								},					
								margin:'5 0 5 0'
							},{ xtype: 'tbspacer', width: 10 },
							 
							{
								xtype: 'button',
								text: fetch.label.DeleteButton,					
								action : 'deleteConnectionProfile',
                                itemId:	'deleteConnectionProfileBtn',							
								//ui:'supcon-submit',					
								width:80,
								height:30,
								style:{																
									'box-shadow': '1px 1px 3px #000'
								},					
								margin:'5 0 5 0'
							}
							
							]
					 
				
							
					}]
		}]

});
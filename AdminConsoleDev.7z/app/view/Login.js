var loginLabel= fetch.label.signIn;
Ext.define('AdminConsole.view.Login', {
	extend : 'Ext.panel.Panel',
	xtype : 'loginpage',
	id : 'login',
	itemId:'loginpanel',
	layout : {
		type : 'vbox',
		align : 'center'
		//pack:'center'
	},
	//width:'100%',
	style:{
		margin:'10% 0 0 0'	
	},
	items : [ 
	{
		bodyCls:'logintitle',
		style:{},
		width:500,
		html:fetch.label.signIn
			+'<div class="logindotSeparator"></div>'
			+'<br />'
	},
	{
		xype:'panel',
		layout:{
			type:'hbox'
		},
		items:[
			{
				xtype:'image',
				//style : 'float:left',
				src : 'resources/images/login.jpg',
				width : 184,
				height:200
			},
			{
				id : 'loginform',
				xtype : 'form',
				itemid : 'logindata',
				width : 400,
				//height:250,
				bodyPadding : '10 10 0 10',
				defaultType : 'textfield',
				defaults : {
					height:30,
					labelCls : 'supconLabelCls',
					labelWidth:120,
					inputWidth:200,
					labelAlign: 'center',
					labelSeparator:'',
					afterLabelTpl :'<span style="float:right;">:&nbsp;</span>',
					allowBlank:false,
					msgTarget: 'side'
					//fieldCls:'supconFieldCls',
//					border: '1px solid #D0E1EB'
				},
				items : [
					 {	
						//fieldLabel : fetch.label.username,
						fieldLabel :fetch.label.username,
						name : 'j_username',
						emptyText : fetch.label.username

					}, {
						fieldLabel : fetch.label.Password,
						name : 'j_password',
						emptyText :fetch.label.Password,
						inputType : 'password'
					}

				],
				dockedItems: [{
					xtype: 'toolbar',
					dock: 'bottom',
					ui: 'footer',//with default the appearance of buttons changes
					height:55,
					layout:{
						type:'hbox'
						//align:'center',
						//pack:'center'
					},
					style:{
						background: '#FFF'
					},
					
					padding:'0 0 10 0',
					margin:'40 0 10 140',
					//defaults: {minWidth: 100},
					items: [
						//{ xtype: 'component', flex: 1,,height:5 },
						{
							xtype: 'button',
							//ui:'supcon-submit',
							//baseCls:'querybutton',
							text: fetch.label.Login,
							itemId:'loginbutton',
							width:80,
							height:30,
							margin:'5 0 5 0',
							style:{
								//'border-radius':'10px',										
								'box-shadow': '1px 1px 3px #000'
							}
						},{xtype:'tbspacer', width:10},
						{
							//xtype: 'simplelink',
							xtype : 'panel',
							html : fetch.label.forgotPassword,
							
							style : {									
									'cursor':'pointer',									
								},
							bodyStyle: {
									//background: '#0066A1',
									color:'#0066A1',
									font : true,
									'font-family': 'sans-serif'
								},

							//text: 'Forgot Password',
							//text: fetch.label.forgotPassword,
							listeners:{
							
								'render': function(panel){
									panel.body.on('click',function(){
								//console.debug('simple link handler scope', this);
								var windo = Ext.create("Ext.Window",{
									title : fetch.label.forgotPassword,
									hideHeaders:true,
									closable : true,     
									modal : true,
									scrollable:true,
									layout:{					
										type : 'vbox',
										align : 'center',
										pack:'center'

									},
									items:[

										{	
											xtype:'form',
											height:170,
											width:400,
											bodyPadding : '10 10 20 25',
											defaultType : 'textfield',
											defaults : {
												height:30,
												labelCls : 'supconLabelCls',
												labelWidth:120,
												inputWidth:200,
												labelAlign: 'center',
												labelSeparator:'',
												afterLabelTpl :'<span style="float:right;">:&nbsp;</span>',
												allowBlank:false
												//fieldCls:'supconFieldCls',
							//					border: '1px solid #D0E1EB'

											},
											items:[

												{	
													fieldLabel :fetch.label.enterUsername,
													name : 'userName',
													emptyText : fetch.label.username,
													msgTarget:'side'


												}, {
													fieldLabel : fetch.label.enterEmail,
													name : 'email',
													emptyText : fetch.label.email,
													vtype:'email',
													msgTarget:'side'


												}
											],
											dockedItems: [{

													
													xtype: 'toolbar',
													dock: 'bottom',
													ui: 'footer',
													height:55,
													layout:{
														type:'hbox'
														//align:'center',
														//pack:'center'

													},
													style:{
														background:'white'

													},
													padding:'0 0 10 0',
													margin:'0 0 10 150',
													//defaults: {minWidth: 100},
													items: [

														{
															xtype: 'button', 
															//baseCls:'querybutton',
															//ui:'supcon-submit',
															text: fetch.label.submit,
															itemId:'forgotButton',
															width:80,
															height:30,
															margin:'0 0 5 0',
															handler:function(btn){
																var self=this;
																form = self.up('form').getForm();
																if (!form.isValid()) {
																	console.log("chnge pwd form invalid");


																	return;
																}
																
																var userType=AdminConsole.app.getController('LoginController').userType;

																var url;
																var header;
																var data;
																					
																//	if(userType=="OEM"){
																		url = AdminConsole.Constants.baseURL+'/oem/handleForgotPassword.htm';
																		data = form.getValues();
																		header = {};
																	/*}else{
																		url = AdminConsole.Constants.baseURL+'/forgotPasswordSupplier.htm';
																		data =  Ext.JSON.encode(form.getValues());
																		header = {'Content-Type':'application/json'};
																	}*/
																Ext.Ajax.request({
																	url : url,
																		method : 'POST',
																	//headers : {'Content-Type':'application/json','Accept':'application/json'},	
																	headers : header,
																	params : data,
																	async : false,
																	timeout : 3600*1000,//1 hr
																	success : function(response) {
																		console.log(response.responseText);
																		var status = response.responseText;
																		//var status = AdminConsole.MyUtil.decodeAction(response.responseText);
																		if (status == "success") {
																			console.log('password email successful');
																			self.up('form').getForm().reset();

																			btn.up('window').close();
																			//Ext.Router.redirect('supplierhome');
																			Ext.Msg.alert(fetch.label.success,fetch.label.passwordResetMsg);

																		} else if (status == "invalid") {
																			Ext.Msg.alert(fetch.label.error, fetch.label.usernamePasswordMsg);
																		} else if (status == "locked"){
																			Ext.Msg.alert(fetch.label.error, fetch.label.accountLockMsg);

																		}


																	},
																	failure : function(response) {
																		alert("Communication failed");


																	}
																});
															}
														}


													]
												}
											]
											},{
												height:50,
												bodyPadding:10,
												xtype:'panel',
												html:'<b>'+fetch.label.passwordNotificationMsg+'</b>'
											}
										]
									});
									windo.show();
									});
											
											
								}
								}
							}

					]
				}
				]
			}
		]
	}
	],
	listeners : {
		afterrender : function() {
			console.log("afterrender: login");
			
		},
		activate : function(me) {
			console.log("activate:" + me.id);
			
//			Ext.History.add(me.id);
		},
		beforeactivate : function(me){
			me.down('#loginform').getForm().reset();
			me.up('#index').down('#languageLink').setVisible(true);
			  Ext.Ajax.request({
						  url:AdminConsole.Constants.baseURL+'/getAllLanguage.htm',
						  method:'GET',
						  success:function(response){
							console.log('response.responseText :'+response.responseText);
							var decodedData=Ext.JSON.decode(response.responseText);
							//console.log(me.down('#languageLink').itemId);
							var languages= "";
							for(var i=0;i<decodedData.length;i++){
							  
							  languages+='<a href="javascript:myFunction(\''+decodedData[i].code+'\')">'+decodedData[i].name+'</a>&nbsp;&nbsp;';
							}
							me.up('#index').down('#languageLink').update(languages);
							
						  }
						}); 
		},
		beforedeactivate: function(me){
			me.up('#index').down('#languageLink').setVisible(false);   
		}
  }
});

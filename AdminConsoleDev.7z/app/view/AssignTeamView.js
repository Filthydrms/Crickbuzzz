Ext.define('AdminConsole.view.AssignTeamView', {
    extend: 'Ext.panel.Panel',
	xtype:'assign-team',
	id:'assign-team',

    requires: [
        'Ext.form.Panel',
        'Ext.form.field.Text',
        'Ext.grid.Panel',
        'Ext.grid.column.Column',
        'Ext.grid.View',
        'Ext.button.Button',
        'Ext.toolbar.Spacer',
		
    ],

    layout: 'fit',
    title: '',
	bodyPadding: '10 10 10 10',
	//autoScroll:true,

   
            items: [
                {
                    xtype: 'form',
                    bodyPadding: '10 10 10 10',
					border: true,
					//width : 320,
				    //height: 320,
					id:'queryAssignTeam',
                    title: fetch.label.assTeamToPC,
					titleAlign: 'center',
                    items: [
                       /* {
                            xtype: 'textfield',
                           // anchor: '100%',
                             margin: '10 10 10 10',
                            fieldLabel: fetch.label.purCat,
							name:'teamPurchaseCat',
                            labelWidth: 150,
							width:400
                        },*/
						{
                            xtype: 'fieldset',
                            border: false,
                           
							layout : {
									type : 'table',
									columns : 3,
									},
                            items: [
                               
                                {
                                    xtype: 'textfield',
									labelWidth:100,
                                    fieldLabel: fetch.label.firstName,
									name:'firstName'
                                },
								{
									xtype: 'tbspacer',
									width: 10
								},	
								{
                                    xtype: 'textfield',
									labelWidth:100,
                                    fieldLabel:fetch.label.lastName,
									name:'lastName'
                                },
								
								{
                                    xtype: 'textfield',
									labelWidth:100,
                                    fieldLabel: fetch.label.userName,
									name:'userName',
									
                                },
								{
									xtype: 'tbspacer',
									width: 10
								},
								{
                                    xtype: 'textfield',
									labelWidth:100,
                                    fieldLabel: fetch.label.role,
									name:'role',
									
                                },
								
								
								/*{
										xtype : 'checkbox',
										// xtype: 'textfield',
										labelWidth:100,
										fieldLabel: fetch.label.enable,
										name:'enable',
										
										//margin:'0 25 0 25'
										//disabled:true,
								},*/
                            ]
                        },
						{
                            xtype: 'container',
                            margin: '20 50 20 50',
                            layout: {
                                type: 'hbox',
                                align: 'stretch',
                                pack: 'center'
                            },
                            items: [
                                {
                                    xtype: 'button',
                                    text: fetch.label.search,
									action:'onSearchTeam'
                                },
                                {
                                    xtype: 'tbspacer',
                                    width: 10
                                },
                                {
                                    xtype: 'button',
                                    text: fetch.label.cancel,
									action:'Cancel'
                                }
                            ]
                        },
						{
                            xtype: 'gridpanel',
							 //margin: '10 10 10 10',
							 title: fetch.label.teamList,
							titleAlign: 'center',
                            
							store:'AvailableUserStore',
                           /* store: {						
								fields:['userId','userName','role','approver','assigned'],	
													
							},*/
							
                            columns: [
									{
										xtype: 'gridcolumn',
										dataIndex: 'userId',
										text: fetch.label.userId,
										flex: 1
									},
									{
										xtype: 'gridcolumn',
										dataIndex: 'userName',
										text: fetch.label.user,
										flex: 1
									},
									{
										xtype: 'gridcolumn',
										dataIndex: 'role',
										text: fetch.label.role,
										flex: 1
									},
									
									{
										xtype : 'checkcolumn',
										dataIndex: 'approver',
										text: fetch.label.approver,
										flex:1,
										//disabled:true
										listeners:{
												beforecheckchange:function( me, rowIndex, checked, eOpts ){
												
													var rec=Ext.getStore('AvailableUserStore').getAt(rowIndex);
													if(rec.data.role != AdminConsole.Constants.CATEGORY_MANAGER){
														Ext.Msg.alert(fetch.label.error,fetch.label.approverErrorMsg);
														return false;
													}
												}
										}
									}
									],
									dockedItems : 
									[ {
										xtype : 'pagingtoolbar',
										//id : 'supplier-grid-paging',
										store : 'AvailableUserStore',/* store same as the grid */
										dock : 'bottom',
										displayInfo : true
									} ],
									store:'AvailableUserStore',
									selType:'checkboxmodel',
									selModel:{
											checkOnly:true,
											/*listeners:{
											renderer:function(value, metaData, record, rowIndex, colIndex, store, view){
												console.log(record.data.assigned);
												 view.getSelectionModel().select(record, true);
												//if(record.data.assigned)
												
											}
											}*/
											
									},
								
							
							listeners:{
								
								afterrender:function(me){
								
										var store= me.getStore();
										console.log('lenght',store);
										store.each(function(rec,index){
										console.log('gggggggggggggg');
										if(rec.get('assigned')){
										console.log('already selected',rec.get('userId'));
										me.getSelectionModel().select(rec,true,true);
										}
										});
										
									    
								},
								beforeselect:function(me,record,index){
									var r = me;
									console.log('before select',r);
								}

								
							},
                        },
                        {
                            xtype: 'container',
                            margin: '20 50 20 50',
                            layout: {
                                type: 'hbox',
                                align: 'stretch',
                                pack: 'center'
                            },
                            items: [
                                {
                                    xtype: 'button',
                                    text: fetch.label.save,
									action:'onAssignTeamSave'
                                },
                                {
                                    xtype: 'tbspacer',
                                    width: 10
                                },
                                {
                                    xtype: 'button',
                                    text: fetch.label.cancel,
									action:'Cancel'
                                }
                            ]
                        }
                    ]
                }
            ]
        

});
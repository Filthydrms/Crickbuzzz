Ext.define('AdminConsole.view.AssignUnspscGrid', {
	 extend: 'Ext.grid.Panel',
	 xtype: 'assign-unspsc-grid',
	 itemId:'unspscGrid',
	 title: fetch.label.unspscCode,
	store: 'AssignUnspscStore',
	viewConfig:{
		listeners:{
			refresh:function(view){
			console.log('aaa',teamSaved,status);
			
			if(Ext.getStore('AssignTeamStore').getCount()>0 && Ext.getStore('AssignUnspscStore').getCount()>0 && status===AdminConsole.Constants.STATUS_IN_PROCESS_CODE && teamSaved=='true')
			view.up('create-product-category').down('button[action="releaseButton"]').setDisabled(false);
			else
			view.up('create-product-category').down('button[action="releaseButton"]').setDisabled(true);
				
			}
		}
	},
	columns: [
		{
			xtype: 'gridcolumn',
			dataIndex: 'code',
			text:  fetch.label.productCategory,
			flex: 5
		},
		{
			xtype: 'gridcolumn',
			dataIndex: 'description',
			text:  fetch.label.description,
			flex: 5
		},
		/*{
			 xtype:'actioncolumn',
			 itemId:'removeUnspsc',
			 items: [{
                html:'<span><u> Remove</u> </span>',
                tooltip: 'Remove',
                handler: function(grid, rowIndex, colIndex) {
                    var rec = grid.getStore().getAt(rowIndex);
					Ext.Msg.confirm('','Are you sure you want to delete this?',function(btn){
						if(btn=='yes'||'Yes')
						console.log('delete record');
					});
                }
            }]
		},*/
		{
			xtype: 'gridcolumn',
			itemId:'removeUnspsc',
			//dataIndex: 'removeUnspsc',
			//text:  fetch.label.removeUNSPSC,
			renderer:function()
			//{return '<span><u> Remove</u> </span>';},
			{return '<img src="resources/images/remove.jpg" alt="Remove" align="middle" />';        
			},
			hidden : true,
			flex: 1
		},
		
	],
	listeners: {
        cellclick: function (view, cell, cellIndex, record, row, rowIndex, e) {

		if(cellIndex==2)
		{
			Ext.Msg.confirm('Warning',fetch.label.removeUnspscMsg,function(btn){
				if(btn=='yes'||btn=='Yes'){
				var unspscRemoveList=[];
				record.data.code=(record.data.code).trim();
				console.log('record',record);
				unspscRemoveList.push(record.data);
				
				var removeData = {
					purchaseCatId : parseInt(pcId),
					code:null,
					name:null,
					description:null,
					teamList:null,
					unspscList: unspscRemoveList,	
					status:null
				};
			
				/*var data={
						purCategoryId:pcId,
						code:record.data.code,
						description:record.data.description,
						};*/
						AdminConsole.MyUtil.showMask(view,'Removing...');
						Ext.Ajax.request({
							headers : {
							'Content-Type':'application/json',
							'Accept':'application/json'
							},
							//url:'jsonResponse.json',
							url : AdminConsole.Constants.baseURL + '/oem/removeUnspsc.htm',
							params: Ext.JSON.encode(removeData),
							//params: Ext.JSON.encode(data),
							async : true,
							timeout : 3600*1000,//1 hr
							success: function(resp) {
									if(resp.responseText=='SUCCESS'){
									Ext.Msg.alert(fetch.label.success,fetch.label.removeUNSPSCSuccessMsg);
									view.getStore().remove(record);
									view.getStore().sync();
									view.refresh();
									
									}
									else if(resp.responseText=='FAIL'){
									Ext.Msg.alert(fetch.label.error,fetch.label.removeUnspscFailMsg);
									}
									else if(resp.responseText==AdminConsole.Constants.STATUS_IN_PROCESS_CODE){
									Ext.Msg.alert(fetch.label.success,fetch.label.removeUNSPSCSuccessMsg);
									//view.getStore().remove(record);
									//view.getStore().sync();
									//view.refresh();
									
									view.up('create-product-category').down('form').getForm().findField('status').setValue(AdminConsole.Constants.STATUS_IN_PROCESS_CODE);
									status=AdminConsole.Constants.STATUS_IN_PROCESS_CODE;
									view.up('create-product-category').down('form').getForm().findField('publish').setValue(false);
									//view.up('create-product-category').down('button[action="releaseButton"]').setDisabled(false);
									view.getStore().remove(record);
									view.getStore().sync();
									view.refresh();
									
											
									}
									AdminConsole.MyUtil.hideMask();	

							},
							failure: function(form, action) {
								alert ('communcation failed.');
							}
						});
				}
			});
		}
        }
    }

	
                        
});
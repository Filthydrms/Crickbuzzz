Ext.define('AdminConsole.view.QueryTemplate', {
    extend: 'Ext.panel.Panel',
	xtype:'query-template',
	itemId:'query-template',
	
    requires: [
        'Ext.toolbar.Toolbar',
        'Ext.button.Button',
        'Ext.menu.Menu',
        'Ext.menu.Item',
        'Ext.form.Panel',
        'Ext.form.FieldSet',
        'Ext.form.field.Text',
        'Ext.toolbar.Spacer',
        'Ext.grid.Panel',
        'Ext.grid.column.Column',
        'Ext.grid.View',
		'Ext.toolbar.Paging',
        'Ext.ux.ProgressBarPager',
    ],
	layout: {
		type : 'fit',
		
	},
	title: '',
	items:[{
                    xtype: 'panel',
                    title: '',
                    layout: {
                        type: 'vbox',
                        align: 'center'
                    },
					bodyStyle:{
					'background-color':'#f6f6f6',
				    },
					 bodyPadding: '10 10 10 10',
					 autoScroll:true,
					// overflowX: 'scroll',
            items: [
                {
                    xtype: 'form',
					width : 600,
				    //height: 320,
					border:true,
                   // margin: '10 200 10 200',
                    bodyPadding: '10 10 10 10',
					
					id:'queryTemplateForm',
                    title: fetch.label.template,
                    titleAlign: 'center',
                    layout: {
                        type: 'vbox',
                        align: 'center',
                        pack: 'center'
                    },
                    items: [
                        {
                            xtype: 'fieldset',
                            border: 0,
                            layout: {
                                type: 'vbox',
                                align: 'stretch',
                                pack: 'center'
                            },
                            items: [
								 {
                                    xtype: 'textfield',
                                    fieldLabel: fetch.label.code,
									name:'code',
									//hidden:true
                                },
                          ]
                        },
						
                        {
                            xtype: 'container',
                            layout: {
                                type: 'hbox',
                                align: 'stretch',
                                pack: 'center'
                            },
                            items: [
                                {
                                    xtype: 'button',
									text:fetch.label.search,
									action:'searchTemplate'
                                },
                                {
                                    xtype: 'tbspacer',
                                    width: 10
                                },
                                {
                                    xtype: 'button',
                                    text: fetch.label.cancel,
									//text:'Cancel',
									action:'cancelButton'
                                }
                            ]
                        }
                    ]
                },
				{
                                    xtype: 'tbspacer',
                                    height: 10
                },
                {
                    xtype: 'gridpanel',
					width : 600,
				    border:true,
                    title: fetch.label.dataList,
                    titleAlign: 'center',
					itemId:'searchTemplateResultForm',
                    columns: [
                        {
                            xtype: 'gridcolumn',
                            dataIndex: 'templateId',
							//width : 100,
                            text: 'Id',
							//text:'Code',
							hidden:true,
                            flex: 1
                        },
						
						{
                            xtype: 'gridcolumn',
                            dataIndex: 'templateCode',
							//width : 100,
                            text: fetch.label.code,
							//text:'Code',
                            flex: 1
                        },
                        {
                            xtype: 'gridcolumn',
                            dataIndex: 'templateSubject',
							//width : 100,
                            text: fetch.label.subject,
							//text:'Name',
                            flex: 1
                        },
						
						
                    ],
					
					dockedItems : [ {
						xtype : 'pagingtoolbar',
						//id : 'supplier-grid-paging',
						store : 'QueryTemplateStore',/* store same as the grid */
						dock : 'bottom',
						displayInfo : true
					} ],
					store:'QueryTemplateStore',
					
					//hidden:true
                }
            ]
			}
			]
       

});
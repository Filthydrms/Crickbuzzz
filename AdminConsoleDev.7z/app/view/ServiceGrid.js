Ext.define('AdminConsole.view.ServiceGrid',{
	extend : 'Ext.grid.Panel',
	xtype : 'serviceGrid',
	itemId : 'serviceGrid',
	
	border : true,
	//margin : '10 0 10 0',
	columnLines : true,
	viewConfig : {
		stripeRows : true
	},
	style : {
		'font-size' : 13,
		'font-family' : 'Verdana, Geneva, sans-serif',
		'color' : '#000000'
	},
	height:300,
	columns : [{
		text : fetch.label.name,
		//width : 120,
		flex : 3,
		sortable : true,
		dataIndex : 'servicename'
		//hidden : true
	}],
	store :'AvailbleServiceStore',

   
	
	selType:'checkboxmodel',
   /* selModel: Ext.create('Ext.selection.CheckboxModel', {
	
	
	}),*/
});
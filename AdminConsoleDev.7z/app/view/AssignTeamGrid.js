Ext.define('AdminConsole.view.AssignTeamGrid', {
	 extend: 'Ext.grid.Panel',
	 xtype: 'assign-team-grid',
	 requires:'Ext.grid.plugin.DragDrop',
	 itemId:'teamGrid',
	 title: fetch.label.team1,
	store: 'AssignTeamStore',
	 viewConfig: {
        listeners:{
			refresh:function(view){
			console.log('aaa',teamSaved,status);
			if(Ext.getStore('AssignTeamStore').getCount()>0 && Ext.getStore('AssignUnspscStore').getCount()>0 && status===AdminConsole.Constants.STATUS_IN_PROCESS_CODE && teamSaved=='true')
			view.up('create-product-category').down('button[action="releaseButton"]').setDisabled(false);
			else
			view.up('create-product-category').down('button[action="releaseButton"]').setDisabled(true);
				
			}
		}
    },
	
	columns: [
		{
			xtype: 'gridcolumn',
			dataIndex: 'userId',
			text:  fetch.label.userId,
			flex: 1
		},
		{
			xtype: 'gridcolumn',
			dataIndex: 'userName',
			text:  fetch.label.user,
			flex: 1
		},
		{
			xtype: 'gridcolumn',
			dataIndex: 'role',
			text:  fetch.label.role,
			flex: 1
		},
		{
			xtype: 'checkcolumn',
			itemId:'approver',
			dataIndex: 'approver',
			text:  fetch.label.approver,
			flex: 0.8,
			//hidden : true,
			listeners:{
				renderer: function(value, cell, record, row, col, store, gridView)
						{
							console.log('approver',value);
						   if(value)
						   return true;
						   else
						   return false;
							
						},
				
				beforecheckchange:function( me, rowIndex, checked, eOpts ){
													
					var rec=Ext.getStore('AssignTeamStore').getAt(rowIndex);
					if(rec.data.role != AdminConsole.Constants.CATEGORY_MANAGER){
						Ext.Msg.alert(fetch.label.error,fetch.label.approverErrorMsg);
						return false;
					}
				}
			},
		},
		{
			xtype: 'gridcolumn',
			itemId:'removeTeam',
			//dataIndex: 'assign',
			text: '',
			renderer:function()
			{return '<img src="resources/images/remove.jpg" alt="Remove" align="middle" />'; },
			hidden : true,
			flex: 0.4
		},
		
		
	],
	//selModel: Ext.create('Ext.selection.CheckboxModel', {}),
	
	listeners: {
        cellclick: function (view, cell, cellIndex, record, row, rowIndex, e) {

		if(cellIndex==4)
		{
			console.log(row,rowIndex,record);
			if(record.data.approver){
				Ext.Msg.alert('Error','Please select another approver before deleting');
				return false;
			}
			Ext.Msg.confirm('Warning',fetch.label.removeMsg,function(btn){
			console.log('choice',btn);
				if(btn=='yes'||btn=='Yes'){
				console.log('delete record');
								
						record.data.assigned=false;
						var userList=[];
						userList.push(record.data);
						var removeData = {
							purchaseCatId : parseInt(pcId),
							code:null,
							name:null,
							description:null,
							teamList:userList,
							unspscList: null,	
							status:null
						};
						console.log('remove',removeData);
						AdminConsole.MyUtil.showMask(view,'Removing...');
						Ext.Ajax.request({
							headers : {'Content-Type':'application/json'},
							//url:'jsonResponse.json',
							url : AdminConsole.Constants.baseURL + '/oem/removeTeam.htm',
							params: Ext.JSON.encode(removeData),
							async : true,
							timeout : 3600*1000,//1 hr
							success: function(resp) {
								
									Ext.Msg.alert(fetch.label.success, fetch.label.removeTeamSuccessMsg);
									//view.getStore().remove(record);
									//view.getStore().sync();
									console.log(Ext.getStore('AssignTeamStore').getCount());
									Ext.getStore('AssignTeamStore').remove(record);
									console.log(Ext.getStore('AssignTeamStore').getCount());
									view.refresh();
									AdminConsole.MyUtil.hideMask();

							},
							failure: function(form, action) {
								alert ('communcation failed.');
							}
						});
				
				}
			});
		}
      }
    }
	
                        
});
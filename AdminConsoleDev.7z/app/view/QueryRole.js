Ext.define('AdminConsole.view.QueryRole', {
    extend: 'Ext.panel.Panel',
	xtype:'query-role',
	itemId:'query-role',
	
    requires: [
        'Ext.toolbar.Toolbar',
        'Ext.button.Button',
        'Ext.menu.Menu',
        'Ext.menu.Item',
        'Ext.form.Panel',
        'Ext.form.FieldSet',
        'Ext.form.field.Text',
        'Ext.toolbar.Spacer',
        'Ext.grid.Panel',
        'Ext.grid.column.Column',
        'Ext.grid.View',
		'Ext.toolbar.Paging',
        'Ext.ux.ProgressBarPager',
    ],
	layout: {
		type : 'fit',
		
	},
	title: '',
	items:[{
                    xtype: 'panel',
                    title: '',
                    layout: {
                        type: 'vbox',
                        align: 'center'
                    },
					bodyStyle:{
					'background-color':'#f6f6f6',
				    },
					 bodyPadding: '10 10 10 10',
					 autoScroll:true,
					// overflowX: 'scroll',
            items: [
                {
                    xtype: 'form',
					width : 600,
				    //height: 320,
					border:true,
                   // margin: '10 200 10 200',
                    bodyPadding: '10 10 10 10',
					//itemId:'queryRoleForm',
					id:'queryRoleForm',
                    title: fetch.label.qryRole,
                    titleAlign: 'center',
                    layout: {
                        type: 'vbox',
                        align: 'center',
                        pack: 'center'
                    },
                    items: [
                        {
                            xtype: 'fieldset',
                            border: 0,
                            layout: {
                                type: 'hbox',
                                align: 'stretch',
                                pack: 'center'
                            },
                            items: [
								 {
                                    xtype: 'textfield',
									labelWidth:80,
                                    fieldLabel: fetch.label.name,
									name:'name',
									//hidden:true
                                },
                                
								{
                                    xtype: 'tbspacer',
                                    width: 10
                                },
								{
                                    xtype: 'textfield',
									labelWidth:80,
                                   // margin: '0 10 0 0',
                                    fieldLabel:fetch.label.description,
									name:'description'
                                },
								
								
                            ]
                        },
						
                        {
                            xtype: 'container',
                            layout: {
                                type: 'hbox',
                                align: 'stretch',
                                pack: 'center'
                            },
                            items: [
                                {
                                    xtype: 'button',
									text:fetch.label.search,
									action:'searchRole'
                                },
                                {
                                    xtype: 'tbspacer',
                                    width: 10
                                },
                                {
                                    xtype: 'button',
                                    text: fetch.label.cancel,
									//text:'Cancel',
									action:'cancelButton'
                                }
                            ]
                        }
                    ]
                },
				{
                                    xtype: 'tbspacer',
                                    height: 10
                },
                {
                    xtype: 'gridpanel',
					width : 600,
				    //height: 320,
					//bodyPadding: '10 10 10 10',
                    //margin: '10 200 10 200',
                    title: fetch.label.roleList,
                    titleAlign: 'center',
					itemId:'querySearchRoleResultForm',
                    columns: [
                        
						{
                            xtype: 'gridcolumn',
                            dataIndex: 'roleId',						
                            text: 'Role Id',
							hidden:true,
                            flex: 1
                        },
						{
                            xtype: 'gridcolumn',
                            dataIndex: 'name',
							//width : 100,
                            text: fetch.label.name,
							//text:'Code',
                            flex: 1
                        },
                        {
                            xtype: 'gridcolumn',
                            dataIndex: 'description',
							//width : 100,
                            text: fetch.label.description,
							//text:'Name',
                            flex: 1
                        },
						
						
                    ],
					
					dockedItems : [ {
						xtype : 'pagingtoolbar',
						//id : 'supplier-grid-paging',
						store : 'QueryRoleStore',/* store same as the grid */
						dock : 'bottom',
						displayInfo : true
					} ],
					store:'QueryRoleStore',
					
					//hidden:true
                }
            ]
			}
			]
       

});
Ext.define('AdminConsole.view.QueryData', {
    extend: 'Ext.panel.Panel',
	xtype:'query-data',
	itemId:'query-data',
	
    requires: [
        'Ext.toolbar.Toolbar',
        'Ext.button.Button',
        'Ext.menu.Menu',
        'Ext.menu.Item',
        'Ext.form.Panel',
        'Ext.form.FieldSet',
        'Ext.form.field.Text',
        'Ext.toolbar.Spacer',
        'Ext.grid.Panel',
        'Ext.grid.column.Column',
        'Ext.grid.View',
		'Ext.toolbar.Paging',
        'Ext.ux.ProgressBarPager',
    ],
	layout: {
		type : 'fit',
		
	},
	title: '',
	items:[{
                    xtype: 'panel',
                    title: '',
                    layout: {
                        type: 'vbox',
                        align: 'center'
                    },
					bodyStyle:{
					'background-color':'#f6f6f6',
				    },
					 bodyPadding: '10 10 10 10',
					 autoScroll:true,
					// overflowX: 'scroll',
            items: [
                {
                    xtype: 'form',
					width : 600,
				    //height: 320,
					border:true,
                   // margin: '10 200 10 200',
                    bodyPadding: '10 10 10 10',
					//itemId:'queryDataForm',
					id:'queryDataForm',
                    title: fetch.label.qryData,
                    titleAlign: 'center',
                    layout: {
                        type: 'vbox',
                        align: 'center',
                        pack: 'center'
                    },
                    items: [
                        {
                            xtype: 'fieldset',
                            border: 0,
                            layout: {
                                type: 'vbox',
                                align: 'stretch',
                                pack: 'center'
                            },
                            items: [
								 {
                                    xtype: 'textfield',
                                    fieldLabel: fetch.label.code,
									name:'code',
									//hidden:true
                                },
                                
								/*{
                                    xtype: 'tbspacer',
                                    width: 10
                                },
								{
                                    xtype: 'textfield',
                                   // margin: '0 10 0 0',
                                    fieldLabel:fetch.label.text,
									name:'text'
                                },*/
								
								
								
                            ]
                        },
						
                        {
                            xtype: 'container',
                            layout: {
                                type: 'hbox',
                                align: 'stretch',
                                pack: 'center'
                            },
                            items: [
                                {
                                    xtype: 'button',
									text:fetch.label.search,
									action:'searchData'
                                },
                                {
                                    xtype: 'tbspacer',
                                    width: 10
                                },
                                {
                                    xtype: 'button',
                                    text: fetch.label.cancel,
									//text:'Cancel',
									action:'cancelButton'
                                }
                            ]
                        }
                    ]
                },
				{
                                    xtype: 'tbspacer',
                                    height: 10
                },
                {
                    xtype: 'gridpanel',
					width : 600,
				    
                    title: fetch.label.dataList,
                    titleAlign: 'center',
					itemId:'querySearchDataResultForm',
                    columns: [
                        {
                            xtype: 'gridcolumn',
                            dataIndex: 'dataPrivacyId',
							//width : 100,
                            text: 'Id',
							//text:'Code',
							hidden:true,
                            flex: 1
                        },
						
						{
                            xtype: 'gridcolumn',
                            dataIndex: 'privacyCode',
							//width : 100,
                            text: fetch.label.code,
							//text:'Code',
                            flex: 1
                        },
                        {
                            xtype: 'gridcolumn',
                            dataIndex: 'privacyText',
							//width : 100,
                            text: fetch.label.text,
							//text:'Name',
                            flex: 1
                        },
						
						
                    ],
					
					dockedItems : [ {
						xtype : 'pagingtoolbar',
						//id : 'supplier-grid-paging',
						store : 'QueryDataStore',/* store same as the grid */
						dock : 'bottom',
						displayInfo : true
					} ],
					store:'QueryDataStore',
					
					//hidden:true
                }
            ]
			}
			]
       

});
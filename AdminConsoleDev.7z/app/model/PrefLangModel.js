Ext.define("AdminConsole.model.PrefLangModel", {
extend : "Ext.data.Model",	
	fields : [    
		{
			name : 'ID',
			type : 'string'
		}, 
		{
			name : 'Name',
			type : 'string'
		}, 
		
	]
});

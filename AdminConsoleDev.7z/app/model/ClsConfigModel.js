Ext.define("AdminConsole.model.ClsConfigModel",{
		extend:"Ext.data.Model",	
			
			fields:[
					{
						name:'Id',
						type:'Integer'
					},
					{
						name:'Value',
						type:'Integer'
						
					}
					
			]
});
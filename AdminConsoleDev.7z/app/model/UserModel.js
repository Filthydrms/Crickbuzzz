Ext.define("AdminConsole.model.UserModel", {
	extend : "Ext.data.Model",	
	fields : [    
		{
			name : 'oemUser',
			type : 'string'
		}, 
		{
			name : 'firstName',
			type : 'string'
		}, 
		{
			name : 'lastName',
			type : 'string'
		},
		{
			name : 'email',
			type : 'string'
		},
		{
			name : 'contactNum',
			type : 'string'
		},
		{
			name : 'address',
			type : 'string'
		},
		{
			name : 'city',
			type : 'string'
		},
		{
			name : 'country',
			type : 'string'
		},
		{
			name : 'enabled',
			type : 'boolean'
		},
		{
			name : 'language',
			
		},
		{
		  name:'role'
		},
		{
		name:'services'
		},
		{
		name:'roleId',
		type:'Integer'
		},
	]	
});
Ext.define("AdminConsole.model.RoleModel", {
extend : "Ext.data.Model",	
	fields : [    
		{
			name : 'ID',
			type : 'string'
		}, 
		{
			name : 'Name',
			type : 'string'
		}, 
		
	]
});

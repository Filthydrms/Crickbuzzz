Ext.define("AdminConsole.model.ConnectionProfileModel", {
	extend : "Ext.data.Model",	
	fields : [
    {
		name : 'systemId',
		type : 'int'
	}, 
	{
		name : 'code',
		type : 'string'
	}, 
	{
		name : 'name',
		type : 'string'
	}, 
	{
		name : 'ipAddress',
		type : 'string'
	}, 
	{	name : 'port',
		type : 'string'
	}, 
	{
		name : 'proxy',
		type : 'string'
	}, 
	{
		name : 'proxyUser',
		type : 'string'
	},
	{
		name : 'proxyPassword',
		type : 'string'
	},
	{
		name : 'protocol',
		type : 'string'
	},{
		name : 'proxyPort',
		type : 'string'
	},{
		name : 'userName',
		type : 'string'
	},{
		name : 'password',
		type : 'string'
	},{
		name : 'sysUrl',
		type : 'string'
	},{
		name : 'commCodeAttr',
		type : 'string'
	},{
		name : 'classStatAttr',
		type : 'string'
	},{
		name : 'contRoleAttr',
		type : 'string'
	},{
		name : 'proxyEnabled',
		type : 'boolean'
	},
	{
		name : 'classStatusRootClassId',
		type : 'string'
	},
	{
		name : 'contRoleRootClassId',
		type : 'string'
	},
	{
		name : 'vendContLicense',
		type : 'string'
	},
	{
		name : 'vendContLicenseConsume',
		type : 'string'
	},
	{
		name : 'classificationClassName',
		type : 'string'
	},
	{
		name : 'maxNoOfRoles',
		type : 'int'
	},
	{
		name : 'withoutClassification',
		type : 'boolean'
	}
	]
	
});
Ext.define("AdminConsole.model.CommodityLogModel", {
	extend : "Ext.data.Model",	
	fields : [    
		{
			name : 'code',
			type : 'string'
		}, 
		{
			name : 'description',
			type : 'string'
		}, 
		{
			name : 'action',
			type : 'string'
		}	
	]	
});
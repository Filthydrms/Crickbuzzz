Ext.define('AdminConsole.Application', {
    name: 'AdminConsole',

    extend: 'Ext.app.Application',
	requires: [
        'Ext.ux.Router','AdminConsole.Constants','AdminConsole.util.PaintMonitor','AdminConsole.util.SizeMonitor'
	],//','Ext.locale.ext-lang-en','Ext.locale.ext-lang-fr'
    views: [
        'Login','ResetPasswordView','PurchaseCategory','QueryPurchaseCategory','AssignTeamGrid','AssignUnspscGrid','UploadUNSPSC','CreateAction','QueryAction','CreateRole','QueryRole','ActionRole','CreateData','QueryData','HtmlEditor','SearchServices','ServiceGrid','AddUser','UserGrid','QueryUser','ClsConfig','ContactUsPage'
    ],
	stores:['QueryPurchaseCategoryStore','AssignTeamStore','AssignUnspscStore','AvailableUserStore','QueryActionStore','QueryRoleStore','Role','Screens','QueryDataStore','DataPrivacy','backendSystem.CommodityLogStore','QueryTranslatedStore','QueryTemplateStore','AssignedServiceStore','AvailbleServiceStore','UserStore','PrefLangStore','RoleStore','ClsConfigStore'],

    controllers: [
       'ConnectionProfileController','LoginController','Home','PurchaseCategoryController','BackendSystemController','TranslateController','UserController','ClassificationConfigurationController'
    ],
	

	routes: {
	 'login/:tenantKey':'LoginController#showLoginPage',
	 'loggedInError': 'Home#showLoogedInErrorPage',
	 'home':'Home#showHome',
	 'connectionProfile':'ConnectionProfileController#connectionProfile',
	 'uploadUNSPSC':'PurchaseCategoryController#createUploadUNSPSC',
	 'createPurchaseCategory':'PurchaseCategoryController#onCreatePurchaseCategory',
	 'queryPurchaseCategory':'PurchaseCategoryController#onQueryPurchaseCategory',
	 'createAction':'PurchaseCategoryController#onCreateAction',
	 'createRole':'PurchaseCategoryController#onCreateRole',
	 'queryAction':'PurchaseCategoryController#onQueryAction',
	 'queryRole':'PurchaseCategoryController#onQueryRole',
	 'actionRole':'PurchaseCategoryController#onActionRole',
	 'queryData':'PurchaseCategoryController#onQueryData',
	 'createData':'PurchaseCategoryController#onCreateData',
	 'fetchDataFromTeamcenter':'BackendSystemController#fetchDataFromTeamcenterPanel',
	 'resetPassword':'home#resetPwd',
	 'translateEntity':'TranslateController#onTranslateEntity',
	 'createTemplate':'TranslateController#onCreateTemplate',
	 'queryTemplate':'TranslateController#onQueryTemplate',
	 'addUser':'UserController#OnAddUser',
	 'queryUser':'UserController#onQueryUser',
	 'clsConfig':'ClassificationConfigurationController#onClassificationConfiguration',
	 'showContactUs':'Home#showContactUs',

	},
	launch:function(){
		console.log("application:inside launch");
		Ext.fly('appLoadingIndicator').destroy();
        
        	       /* 
		            * Ext.ux.Router provides some events for better controlling
		            * dispatch flow
		            */
		           Ext.ux.Router.on({
		               
		               routemissed: function(token) {
		                   /*Ext.Msg.show({
		                       title:'Error 404',
		                       msg: 'Route not found: ' + token,
		                       buttons: Ext.Msg.OK,
		                       icon: Ext.Msg.ERROR
		                   });*/
		               },
		               
		               beforedispatch: function(token, match, params) {
		                   console.log('beforedispatch ' + token);
						   
							var userType=Ext.util.Cookies.get('userType');
							console.log(userType);
							
							var param = 'BUC-00';
							if(Ext.String.startsWith( token, "querySupplier" )){
								param = 'BUC-12';
							}
							 /*else if(Ext.String.startsWith( token, "uploadUNSPSC" )){
								 param = 'BUC-51';
							 }							
							  else if(Ext.String.startsWith( token, "createPurchaseCategory" )){
								 param = 'BUC-50';
							 }
							  else if(Ext.String.startsWith( token, "queryPurchaseCategory" )){
								 param = 'BUC-54';
							 }*/
							else if(Ext.String.startsWith( token, "connectionProfile" )){
								 param = AdminConsole.Constants.CREATE_CONNECTION_PROFILE_USE_CASE;
							}else if(Ext.String.startsWith( token, "fetchDataFromTeamcenter" )){
								 param = AdminConsole.Constants.FETCH_COMMODITY_CODE_USE_CASE;
							}
							
							var patt = /login/;
							if(token=='' || patt.test(token)){
								console.log("Login page");
								var url;
								//if(userType=="OEM"){
									url = AdminConsole.Constants.baseURL+'/oem/authenticateUser.htm';
								//}
								//else
								//	url = AdminConsole.Constants.baseURL+'/authenticateSupplierUser.htm';
								Ext.Ajax.request({
									url:url,
									method:'GET',
									async:false,//load synchronously
									params:{screenCode:param,
											userType:'OEM'},
									success:function(response){
										console.log('response.responseText :'+response.responseText);
											if(response.responseText==="success"){
												console.log('User is logged in');												
												//Ext.Msg.alert('','Redirecting',function(){Ext.Router.redirect('supplierhome');});												
												Ext.Router.redirect('home');
											}else if(response.responseText=='8'){
												console.log('>>>>>>>>>>>>>redirecting to home');
												Ext.Router.redirect('loggedInError');
												AdminConsole.MyUtil.myFlag=false;
											}else{
												console.log('User is not logged in');												
											}
									}
								});
							} else if(token=='resetPassword'){
								console.log('signing out user');
								var url;
								if(userType=="OEM"){
									url = AdminConsole.Constants.baseURL+'/oem/logout.htm';
								}else
									url = AdminConsole.Constants.baseURL+'/j_spring_security_logout';
								Ext.Ajax.request({
								  url:url,
								  method:'GET',
									async:false,//synchronous call
								  success: function(response){
										console.log("logout successful");
								  },
									failure:function(response){
									  console.log("logout error");            	
									}
								});
								
							} else if(!(Ext.String.startsWith( token, "loggedInError" ))){
								//var flag=true;
								var url;
								console.log(userType);
								//if(userType=="OEM"){
									url = AdminConsole.Constants.baseURL+'/oem/authenticateUser.htm';
								//}else
								//	url = AdminConsole.Constants.baseURL+'/authenticateSupplierUser.htm';
								Ext.Ajax.request({
									url:url,
									method:'GET',
									async:false,
									params:{screenCode:param,
											userType:'OEM'},
									success:function(response){
										console.log('response.responseText :'+response.responseText);
											if(response.responseText=="success"){
												console.log('User is logged in');
												AdminConsole.MyUtil.myFlag=true;
											}else if(response.responseText=="ACCESS DENIED EXCEPTION"){
												//Ext.Msg.alert('Error!','ACCESS DENIED');
												AdminConsole.MyUtil.myFlag=false;
												Ext.Msg.alert(fetch.label.error ,fetch.label.accessDeniedMsg);
												
												//return false;
											}else if(response.responseText=='8'){
												console.log('>>>>>>>>>>>>>redirecting to home');
												Ext.Router.redirect('loggedInError');
												AdminConsole.MyUtil.myFlag=false;
											}else{
												console.log('User is not logged in');
												//Ext.Msg.alert('','You are not logged in or your session has expired. Please login to continue',
												Ext.Msg.alert(fetch.label.error,fetch.label.sessionValidationMessage,
													function(){
														Ext.Router.redirect('login/'+Ext.util.Cookies.get('tenant'));
													});
												AdminConsole.MyUtil.myFlag=false;
											}
									}
								});	
								//alert(AdminConsole.MyUtil.myFlag);
								return AdminConsole.MyUtil.myFlag;
							}
							//return false;
		               },
		               
		               /**
		                * even called after dispatching
		                * 
		                * 
		                */
		               dispatch: function(token, match, params, controller) {
		                }
		           });
	}
	
});

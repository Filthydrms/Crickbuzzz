var connectionProfileGrid=null;
Ext.define('AdminConsole.controller.ConnectionProfileController', {
    extend: 'Ext.app.Controller',
	views : ['ConnectionProfile','ConnectionProfileGrid','ConnectionProfileDetail'],
	stores : ['ConnectionProfileStore'],
	models:['ConnectionProfileModel'],
	refs : [
		{
			ref : 'connectionProfileGrid',
			selector : 'connectionProfileGrid#connectionProfile_grid'
		},
		{
			ref :'connectionProfileForm',
			selector:'#connectionProfileForm'
		},
		{
			ref : 'conProf',
			selector : 'connectionProfile#connectionProfile'
		}
	],
	init : function() {
	console.log('inside ConnectionProfileController controller');
			
		this.control({
			 // '#connectionProfileGridPanel' : {
				 // itemclick : this.connectionProfileGridClick
			 // },
			'button[action="cancelConnectionProfile"]' : {
				click : this.cancelConnectionProfileClick
			},
			// 'button[action="deleteConnectionProfile"]' : {
				// click : this.deleteConnectionProfileClick
			// },
			'button[action="createConnectionProfile"]' : {
				click : this.createConnectionProfileClick
			},
			'button[action="testConnectionProfile"]' : {
				click : this.testConnectionProfileClick
			},
			'button[action="testTCAttribute"]' : {
				click : this.testTCAttributeClick
			},
			'button[action="saveConnectionProfile"]' : {
				click : this.saveOrUpdateConnectionProfile
			},
			'button[action="updateConnectionProfile"]' : {
				click : this.saveOrUpdateConnectionProfile
			},			
		});
		
		
		
	},
	/*
	*This function is used load Connection Profile Page
	*/
	connectionProfile:function(){
		console.log('ConnectionProfileController : inside connectionProfile Start');	
		Ext.getCmp('index').getLayout().setActiveItem('homePage');		
		Ext.getCmp('adminhome').getLayout().setActiveItem('connectionProfile');
		this.getConnectionProfiles();
		console.log('ConnectionProfileController : inside connectionProfile End');
	},
	/*
	*This function is used load Connection Profiles List into Grid
	*/
	getConnectionProfiles : function() {
	  console.log("inside Connection Profile Search : Start");
		Ext.getBody().mask(fetch.label.loading);
	  
		var view = Ext.getCmp('connectionProfileMain');
			//console.log(view);
			//store file not yet created.
			var conProStore = Ext.getStore('ConnectionProfileStore');
			//console.log(conProStore);
			/*clear the store before making a new query*/
			conProStore.removeAll();
			if (connectionProfileGrid == null) {				
						connectionProfileGrid = view.add(
						{
							xtype:'panel',
							id:'connectionProfile-grid-panel',
							layout:{
								type:'vbox',
								align:'center'
							},
							margin:'10 0 10 0',
							items:[
							{
							
							},
								{
									xtype : 'connectionProfileGrid',
									id : 'connectionProfile_grid',
									margin:'10 0 10 0'
								}]
						});
					conProStore.load({
						start:0,
						limit: 10,
						scope: this,
						callback: function(synSystemRecords, operation, success) {
							Ext.getBody().unmask();	
							/* if(success) {
								console.log(synSystemRecords.length);
								if(synSystemRecords.length === 1){
									view.up('#connectionProfile').down('#createConnectionProfileBtn').disabled=true;
								}else{
									view.up('#connectionProfile').down('#createConnectionProfileBtn').disabled=false;
								}
							} */
						}
					   
				});

				//Try to focus
				Ext.getCmp('connectionProfile-grid-panel').focus();
				}
				else{
				console.log("resultGrid exists");
					conProStore.currentPage = 1;
					conProStore.load({
						start:0,
						limit: 10,
						scope: this,
						callback: function(synSystemRecords, operation, success) {
							Ext.getBody().unmask();	
							/* if(success) {
								if(synSystemRecords.length === 1){
									view.up('#connectionProfile').down('#createConnectionProfileBtn').disabled=true;
								}else{
									view.up('#connectionProfile').down('#createConnectionProfileBtn').disabled=false;
								}					
							} */
						}
					});
		
				}
				
			
		console.log("inside Connection Profile Search : End");	
	},
	/*
	* This function used load Connection Profile Edit Page 
	*/
	/* connectionProfileGridClick : function(me, record, item, index, e, eOpts){	
		console.log('inside Connection Profile View');
		console.log(record);		
		console.log(record.get('code')); 
		this.viewConnectionProfile(record);
		
	}, */
	
	viewConnectionProfile : function(me,connectionProfileRecord){
		console.log('viewConnectionProfile of ConnectionProfileController : START');
		console.log('inside Connection Profile View');
		
		this.viewConnectionProfileImpl(connectionProfileRecord);
		console.log('viewConnectionProfile of ConnectionProfileController : END');
	},
	
	viewConnectionProfileImpl:function(connectionProfileRecord){
	console.log('viewConnectionProfileImpl of ConnectionProfileController : START');
	console.log(connectionProfileRecord);
	   var detailPanel = Ext.create('AdminConsole.view.ConnectionProfileDetail',{
							width:980
						});
						
		/*if(AdminConsole.Constants.SYN_TEAMCENTER.toUpperCase() == connectionProfileRecord.data.code.toUpperCase()){
			console.log('Connection profile of Teamcenter.');
			detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').down('#createConnProfileTeamCenterConfigFieldset').hidden=false;
		}else if(AdminConsole.Constants.SYN_SUGARCRM.toUpperCase() == connectionProfileRecord.data.code.toUpperCase()){
			console.log('Connection profile of SUGARCRM.');
			detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').down('#createConnProfileTeamCenterConfigFieldset').hidden=true;
		}else if(AdminConsole.Constants.SYN_SAP.toUpperCase() == connectionProfileRecord.data.code.toUpperCase()){
			console.log('Connection profile of SAP.');
			detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').down('#createConnProfileTeamCenterConfigFieldset').hidden=true;
		}*/
		if(AdminConsole.Constants.SYN_TEAMCENTER.toUpperCase() == connectionProfileRecord.data.code.toUpperCase()){
			console.log('Connection profile of Teamcenter.');
			//detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').down('#createConnProfileTeamCenterConfigFieldset').fieldDefaults.allowBlank=false;
			detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').down('#createConnProfileTeamCenterConfigFieldset').hidden=false;
			detailPanel.down('#connectionProfileBtnContainer').down('#testTCAttributeBtn').hidden=false;
			
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyEnabledFlag').setVisible(AdminConsole.Constants.STATUS_TRUE);
			detailPanel.down('#createConnectionProfileFieldset').down('#proxy').setVisible(AdminConsole.Constants.STATUS_TRUE);												
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyPort').setVisible(AdminConsole.Constants.STATUS_TRUE);												
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyUser').setVisible(AdminConsole.Constants.STATUS_TRUE);												
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyPassword').setVisible(AdminConsole.Constants.STATUS_TRUE);
														
			detailPanel.down('#createConnectionProfileFieldset').down('#databasePartition').setVisible(AdminConsole.Constants.STATUS_FALSE);
			
		}else if(AdminConsole.Constants.SYN_SUGARCRM.toUpperCase() == connectionProfileRecord.data.code.toUpperCase()){
			console.log('Connection profile of SUGARCRM.');
			//detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').down('#createConnProfileTeamCenterConfigFieldset').fieldDefaults.allowBlank=true;
			detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').down('#createConnProfileTeamCenterConfigFieldset').hidden=true;
			detailPanel.down('#connectionProfileBtnContainer').down('#testTCAttributeBtn').hidden=true;
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyEnabledFlag').setVisible(AdminConsole.Constants.STATUS_TRUE);
			detailPanel.down('#createConnectionProfileFieldset').down('#proxy').setVisible(AdminConsole.Constants.STATUS_TRUE);												
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyPort').setVisible(AdminConsole.Constants.STATUS_TRUE);												
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyUser').setVisible(AdminConsole.Constants.STATUS_TRUE);												
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyPassword').setVisible(AdminConsole.Constants.STATUS_TRUE);
														
			detailPanel.down('#createConnectionProfileFieldset').down('#databasePartition').setVisible(AdminConsole.Constants.STATUS_FALSE);
		}else if(AdminConsole.Constants.SYN_SAP.toUpperCase() == connectionProfileRecord.data.code.toUpperCase()){
			console.log('Connection profile of SAP.');
			//detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').down('#createConnProfileTeamCenterConfigFieldset').fieldDefaults.allowBlank=true;
			detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').down('#createConnProfileTeamCenterConfigFieldset').hidden=true;
			detailPanel.down('#connectionProfileBtnContainer').down('#testTCAttributeBtn').hidden=true;
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyEnabledFlag').setVisible(AdminConsole.Constants.STATUS_TRUE);
			detailPanel.down('#createConnectionProfileFieldset').down('#proxy').setVisible(AdminConsole.Constants.STATUS_TRUE);												
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyPort').setVisible(AdminConsole.Constants.STATUS_TRUE);												
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyUser').setVisible(AdminConsole.Constants.STATUS_TRUE);												
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyPassword').setVisible(AdminConsole.Constants.STATUS_TRUE);
														
			detailPanel.down('#createConnectionProfileFieldset').down('#databasePartition').setVisible(AdminConsole.Constants.STATUS_FALSE);
		} 
		else if(AdminConsole.Constants.SYN_SCF.toUpperCase() == connectionProfileRecord.data.code.toUpperCase()){
			console.log('Connection profile of SCF.');
			//detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').down('#createConnProfileTeamCenterConfigFieldset').fieldDefaults.allowBlank=true;
			detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').down('#createConnProfileTeamCenterConfigFieldset').hidden=true;
			detailPanel.down('#connectionProfileBtnContainer').down('#testTCAttributeBtn').hidden=true;
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyEnabledFlag').setVisible(AdminConsole.Constants.STATUS_FALSE);
			detailPanel.down('#createConnectionProfileFieldset').down('#proxy').setVisible(AdminConsole.Constants.STATUS_FALSE);												
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyPort').setVisible(AdminConsole.Constants.STATUS_FALSE);												
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyUser').setVisible(AdminConsole.Constants.STATUS_FALSE);												
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyPassword').setVisible(AdminConsole.Constants.STATUS_FALSE);
														
			detailPanel.down('#createConnectionProfileFieldset').down('#databasePartition').setVisible(AdminConsole.Constants.STATUS_TRUE);
		} 
		
						
						
		detailPanel.down('form').loadRecord(connectionProfileRecord);
		
		detailPanel.down('#connectionProfileBtnContainer').down('#saveConnectionProfileBtn').hidden=true;
		detailPanel.down('#connectionProfileBtnContainer').down('#updateConnectionProfileBtn').hidden=true;
		detailPanel.down('#connectionProfileBtnContainer').down('#testConnectionProfileBtn').hidden=true;
		detailPanel.down('#connectionProfileBtnContainer').down('#testTCAttributeBtn').hidden=true;
		detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').down('#createConnectionProfileFieldset').down('#proxyEnabledFlag').setValue(connectionProfileRecord.data.proxyEnabled);
		detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').fieldDefaults.readOnly=true;		
		detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').setTitle(fetch.label.viewConnectionProfile);
		
		//detailPanel.down('form').down('#saveConnectionProfileBtn').setText(fetch.label.UpdateButton);	
		AdminConsole.MyUtil.showPopUp(detailPanel,'');
			console.log('viewConnectionProfileImpl of ConnectionProfileController : END');	
	},
	
	editConnectionProfile : function(me,connectionProfileRecord){
		console.log('editConnectionProfile of ConnectionProfileController : START');
		console.log('inside Connection Profile View');
		//console.log(connectionProfileRecord);
		this.editConnectionProfileImpl(connectionProfileRecord);
		console.log('editConnectionProfile of ConnectionProfileController : END');
	},
	
	
	/*
	* This function used to open new PopUp for Edit Connection Profile Page  
	* with prepopulated Data
	*/
	editConnectionProfileImpl:function(connectionProfileRecord){
	   var detailPanel = Ext.create('AdminConsole.view.ConnectionProfileDetail',{
							width:980
						});
		console.log(connectionProfileRecord);
		var connectionProfileForm = detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm');
		var systemName = connectionProfileForm.down('#createConnectionProfileFieldset').down('#systemNameCombo');
		systemName.readOnly= true;
						
		if(AdminConsole.Constants.SYN_TEAMCENTER.toUpperCase() == connectionProfileRecord.data.code.toUpperCase()){
			console.log('Connection profile of Teamcenter.');
			//detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').down('#createConnProfileTeamCenterConfigFieldset').fieldDefaults.allowBlank=false;
			detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').down('#createConnProfileTeamCenterConfigFieldset').hidden=false;
			detailPanel.down('#connectionProfileBtnContainer').down('#testTCAttributeBtn').hidden=false;
			
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyEnabledFlag').setVisible(AdminConsole.Constants.STATUS_TRUE);
			detailPanel.down('#createConnectionProfileFieldset').down('#proxy').setVisible(AdminConsole.Constants.STATUS_TRUE);												
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyPort').setVisible(AdminConsole.Constants.STATUS_TRUE);												
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyUser').setVisible(AdminConsole.Constants.STATUS_TRUE);												
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyPassword').setVisible(AdminConsole.Constants.STATUS_TRUE);
														
			detailPanel.down('#createConnectionProfileFieldset').down('#databasePartition').setVisible(AdminConsole.Constants.STATUS_FALSE);
			detailPanel.down('#connectionProfileBtnContainer').down('#tbspacerUpdate').hidden=true;	
		}else if(AdminConsole.Constants.SYN_SUGARCRM.toUpperCase() == connectionProfileRecord.data.code.toUpperCase()){
			console.log('Connection profile of SUGARCRM.');
			//detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').down('#createConnProfileTeamCenterConfigFieldset').fieldDefaults.allowBlank=true;
			detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').down('#createConnProfileTeamCenterConfigFieldset').hidden=true;
			detailPanel.down('#connectionProfileBtnContainer').down('#testTCAttributeBtn').hidden=true;
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyEnabledFlag').setVisible(AdminConsole.Constants.STATUS_TRUE);
			detailPanel.down('#createConnectionProfileFieldset').down('#proxy').setVisible(AdminConsole.Constants.STATUS_TRUE);												
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyPort').setVisible(AdminConsole.Constants.STATUS_TRUE);												
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyUser').setVisible(AdminConsole.Constants.STATUS_TRUE);												
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyPassword').setVisible(AdminConsole.Constants.STATUS_TRUE);
														
			detailPanel.down('#createConnectionProfileFieldset').down('#databasePartition').setVisible(AdminConsole.Constants.STATUS_FALSE);
		}else if(AdminConsole.Constants.SYN_SAP.toUpperCase() == connectionProfileRecord.data.code.toUpperCase()){
			console.log('Connection profile of SAP.');
			//detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').down('#createConnProfileTeamCenterConfigFieldset').fieldDefaults.allowBlank=true;
			detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').down('#createConnProfileTeamCenterConfigFieldset').hidden=true;
			detailPanel.down('#connectionProfileBtnContainer').down('#testTCAttributeBtn').hidden=true;
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyEnabledFlag').setVisible(AdminConsole.Constants.STATUS_TRUE);
			detailPanel.down('#createConnectionProfileFieldset').down('#proxy').setVisible(AdminConsole.Constants.STATUS_TRUE);												
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyPort').setVisible(AdminConsole.Constants.STATUS_TRUE);												
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyUser').setVisible(AdminConsole.Constants.STATUS_TRUE);												
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyPassword').setVisible(AdminConsole.Constants.STATUS_TRUE);
														
			detailPanel.down('#createConnectionProfileFieldset').down('#databasePartition').setVisible(AdminConsole.Constants.STATUS_FALSE);
		} 
		else if(AdminConsole.Constants.SYN_SCF.toUpperCase() == connectionProfileRecord.data.code.toUpperCase()){
			console.log('Connection profile of SCF.');
			//detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').down('#createConnProfileTeamCenterConfigFieldset').fieldDefaults.allowBlank=true;
			detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').down('#createConnProfileTeamCenterConfigFieldset').hidden=true;
			detailPanel.down('#connectionProfileBtnContainer').down('#testTCAttributeBtn').hidden=true;
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyEnabledFlag').setVisible(AdminConsole.Constants.STATUS_FALSE);
			detailPanel.down('#createConnectionProfileFieldset').down('#proxy').setVisible(AdminConsole.Constants.STATUS_FALSE);												
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyPort').setVisible(AdminConsole.Constants.STATUS_FALSE);												
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyUser').setVisible(AdminConsole.Constants.STATUS_FALSE);												
			detailPanel.down('#createConnectionProfileFieldset').down('#proxyPassword').setVisible(AdminConsole.Constants.STATUS_FALSE);
														
			detailPanel.down('#createConnectionProfileFieldset').down('#databasePartition').setVisible(AdminConsole.Constants.STATUS_TRUE);
		detailPanel.down('#createConnectionProfileFieldset').down('#databasePartition').allowBlank=AdminConsole.Constants.STATUS_FALSE;
			detailPanel.down('#connectionProfileBtnContainer').down('#tbspacerUpdate').hidden=true;		
			detailPanel.down('#connectionProfileBtnContainer').down('#tbspacerSave').hidden=true;		
		} 
				
		detailPanel.down('form').loadRecord(connectionProfileRecord);
		detailPanel.down('#connectionProfileBtnContainer').down('#saveConnectionProfileBtn').hidden=true;
		detailPanel.down('#connectionProfileBtnContainer').down('#updateConnectionProfileBtn').hidden=false;
		detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').fieldDefaults.readOnly=false;
		detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').down('#createConnectionProfileFieldset').down('#proxyEnabledFlag').setValue(connectionProfileRecord.data.proxyEnabled);
		detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').setTitle(fetch.label.editConnectionProfile);
		
		console.log(detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').down('#createConnProfileTeamCenterConfigFieldset').defaults);
		//console.log(detailPanel);
		//detailPanel.down('form').down('#saveConnectionProfileBtn').setText(fetch.label.UpdateButton);	
		AdminConsole.MyUtil.showPopUp(detailPanel,'');	
	},
	
	/*
	* This function used to save or update connection Profile	
	*/
	saveOrUpdateConnectionProfile :function(connectionProfileBtn){
	 console.log('Inside Connection Profile Save');	
	  /* Loding Form and form validation */
	  var connectionProfileForm = this.getConnectionProfileForm();

	  var connectionProfileFormValues = connectionProfileForm.getForm().getValues();
	  console.log(connectionProfileBtn.action);
	  console.log(connectionProfileFormValues);
	  
	  
		if (!connectionProfileForm.getForm().isValid()) {
			console.log("Form is invalid");
			return;
		}
		if (connectionProfileFormValues.vendContLicense < 0) {
			console.log("Form is invalid");
			Ext.Msg.alert(fetch.label.error,fetch.label.invalidVendorContactLicenses);
			return;
		}
				
		if(AdminConsole.Constants.SYN_TEAMCENTER.toUpperCase() == connectionProfileFormValues.code.toUpperCase()){
			
			if((connectionProfileFormValues.commCodeAttr == "" || connectionProfileFormValues.commCodeAttr == null )&& !connectionProfileFormValues.withoutClassification){
				//Ext.Msg.alert(fetch.label.error,fetch.label.commodityCodeAttribute +' ' +fetch.label.nullValidationMsg);
				connectionProfileForm.down('#commCodeAttr').markInvalid(fetch.label.fieldRequired);
				return;
			}else if((connectionProfileFormValues.classStatusRootClassId == "" || connectionProfileFormValues.classStatusRootClassId == null)&&!connectionProfileFormValues.withoutClassification ){
				//Ext.Msg.alert(fetch.label.error,fetch.label.classStatusRootClassId +' ' +fetch.label.nullValidationMsg);
				connectionProfileForm.down('#classStatusRootClassId').markInvalid(fetch.label.fieldRequired);
				return;
			}else if((connectionProfileFormValues.contRoleRootClassId == "" || connectionProfileFormValues.contRoleRootClassId == null)&& !connectionProfileFormValues.withoutClassification ){
				//Ext.Msg.alert(fetch.label.error,fetch.label.contRoleRootClassId +' ' +fetch.label.nullValidationMsg);
				connectionProfileForm.down('#contRoleRootClassId').markInvalid(fetch.label.fieldRequired);
				return;
			}else if((connectionProfileFormValues.classStatAttr == "" || connectionProfileFormValues.classStatAttr == null) && !connectionProfileFormValues.withoutClassification ){
				//Ext.Msg.alert(fetch.label.error,fetch.label.classificationStatusAttribute +' ' +fetch.label.nullValidationMsg);
				connectionProfileForm.down('#classStatAttr').markInvalid(fetch.label.fieldRequired);
				return;
			}
			else if((connectionProfileFormValues.classificationClassName == "" || connectionProfileFormValues.classificationClassName == null) && !connectionProfileFormValues.withoutClassification ){
				//Ext.Msg.alert(fetch.label.error,fetch.label.classificationStatusAttribute +' ' +fetch.label.nullValidationMsg);
				connectionProfileForm.down('#classificationClassName').markInvalid(fetch.label.fieldRequired);
				return;
			}
			else if((connectionProfileFormValues.maxNoOfRoles == "" || connectionProfileFormValues.maxNoOfRoles == null) && !connectionProfileFormValues.withoutClassification ){
				//Ext.Msg.alert(fetch.label.error,fetch.label.classificationStatusAttribute +' ' +fetch.label.nullValidationMsg);
				connectionProfileForm.down('#maxNoOfRoles').markInvalid(fetch.label.fieldRequired);
				return;
			}
			else if((connectionProfileFormValues.contRoleAttr == "" || connectionProfileFormValues.contRoleAttr == null) && !connectionProfileFormValues.withoutClassification ){
				//Ext.Msg.alert(fetch.label.error,fetch.label.contactRoleAttribute +' ' +fetch.label.nullValidationMsg);
				connectionProfileForm.down('#contRoleAttr').markInvalid(fetch.label.fieldRequired);
				return;
			}else if(connectionProfileFormValues.vendContLicense == "" || connectionProfileFormValues.vendContLicense == null ){
				//Ext.Msg.alert(fetch.label.error,fetch.label.vendorContactLicenses +' ' +fetch.label.nullValidationMsg);
				connectionProfileForm.down('#vendContLicense').markInvalid(fetch.label.fieldRequired);
				return;
			}
		}
		

		/* Enabling Masking      */
		if(connectionProfileBtn.action.toUpperCase() == 'saveConnectionProfile'.toUpperCase()){
			Ext.getBody().mask(fetch.label.saving);
		}else{
			Ext.getBody().mask(fetch.label.updating);
	    }		 
		//var connectionProfileFormValues =connectionProfileForm.getValues();
		
		//Converted "" to null so that the field can be parsed in the backend.
		if(connectionProfileFormValues.systemId == ""){
			connectionProfileFormValues.systemId = null;
		}
				
		//When checkbox is chekcked it's value is 'on', it is converted to boolean value, so that it will be treated as a boolean value.
		if(connectionProfileFormValues.proxyEnabledFlag != undefined && connectionProfileFormValues.proxyEnabledFlag == 'on'){
			console.log('Is prxy enable form field checked');
			connectionProfileFormValues.proxyEnabledFlag = AdminConsole.Constants.CHECKED;  
		}else{
			console.log('Is prxy enable form field unchecked');
			connectionProfileFormValues.proxyEnabledFlag = AdminConsole.Constants.UNCHECKED;  
		}	
		
		if(connectionProfileFormValues.withoutClassification != undefined && connectionProfileFormValues.withoutClassification == 'on'){
			console.log('Is prxy enable form field checked');
			connectionProfileFormValues.withoutClassification = true;  
		}else{
			console.log('Is prxy enable form field unchecked');
			connectionProfileFormValues.withoutClassification = false;  
		}	
				
		console.log(connectionProfileFormValues);
		console.log("----Saving Connection Profile-------");
 			Ext.Ajax.request({
				url : AdminConsole.Constants.baseURL + '/oem/saveOrUpdateConnectionProfiles.htm',
				method : 'POST',
				isSynchronous:true,
				params : Ext.JSON.encode(connectionProfileFormValues),
				headers : {'Content-Type':'application/json','Accept':'application/json'},
				timeout:1136000,
				success : function(response) {
					Ext.getBody().unmask();
					console.log(response.responseText);
					
					var res = Ext.JSON.decode(response.responseText);			
					
					if(res.errors != null && res.errors.length > 0){
						console.log('inside error');
							if(res.errors[0].errorType.toUpperCase() == AdminConsole.Constants.SYSTEM_CODE_ALREADY_ASSIGNED_MESSAGE.toUpperCase()){
								Ext.Msg.alert(fetch.label.error,fetch.label.sysCodeAlreadyAssignedMsg);
								return false;						
							}else{
								Ext.Msg.alert(fetch.label.error,fetch.label.sysError);
								return false;
							}
					}
					
					connectionProfileForm.down('#systemId').setValue(res.systemId);		
					
                    if(connectionProfileBtn.action.toUpperCase() == 'saveConnectionProfile'.toUpperCase()){
						console.log('Save connection Profile success.');
						Ext.Msg.alert( fetch.label.success, fetch.label.ConProfileSaveSuccess,function(){						
							Ext.getStore('ConnectionProfileStore').reload();
														
							connectionProfileBtn.up('window').close();
							
						});					
					}else{
						console.log('Update connection Profile success.');
						 Ext.Msg.alert( fetch.label.success, fetch.label.ConProfileUpdateSuccess,function(){						
							Ext.getStore('ConnectionProfileStore').reload();							
						});
						connectionProfileBtn.up('window').close();
					}
				},
				failure : function(response) {
					Ext.getBody().unmask();					
					Ext.Msg.alert(fetch.label.fail,fetch.label.fail.communicationFail);
				}
			}); 	 
	},
	/*
	* This function used to cancel save or update process Connection profile 
	*/
	cancelConnectionProfileClick:function(){
	console.log('Inside Connection Profile Cancel');
	    AdminConsole.MyUtil.hidePopUp();
	},
	/*
	* This function used to delete connection Profile
	*/
	deleteConnectionProfile:function(me,connectionProfileRec){
	 console.log('Inside Connection Profile Delete');
     //var form = this.getConnectionProfileForm();	 
     Ext.Msg.confirm(fetch.label.confirm, fetch.label.deleteMsgConfirm, function(btn){	  
	   if(btn=='yes'){        
	    Ext.getBody().mask(fetch.label.deleting);	   
		 //console.log(form);
		 //var data=form.getValues();
		 console.log("----Deleting Connection Profile-------");
			Ext.Ajax.request({
				url : AdminConsole.Constants.baseURL + '/oem/deleteConnectionProfiles.htm',
				method : 'POST',
				async:true,
				params : Ext.JSON.encode(connectionProfileRec.data),
				headers : {'Content-Type':'application/json','Accept':'application/json'},
				timeout:36000,
				success : function(response) {
					console.log(response.responseText);
					AdminConsole.MyUtil.decodeAction(response.responseText);	
					Ext.getBody().unmask();						
					if(response.responseText.toUpperCase() == AdminConsole.Constants.STATUS_SUCCESS.toUpperCase()){
						Ext.Msg.alert( fetch.label.success, fetch.label.ConProfileDeleteSuccess,function(){
							Ext.getStore('ConnectionProfileStore').reload();						
						});
					}else if(AdminConsole.Constants.STATUS_FAIL.toUpperCase() == response.responseText.toUpperCase()){
						Ext.Msg.alert( fetch.label.error, fetch.label.ConProfileDeleteFail);
					}
					else{					 
					  Ext.Msg.alert( fetch.label.error, fetch.label.ConProfileDeleteFail);
					}
				},
				failure : function(response) {
					Ext.getBody().unmask();	
					Ext.Msg.alert(fetch.label.fail,fetch.label.fail.communicationFail);
				}
			});
	   
       }
	 });	
	
	
	
	},
	/*
	* This function used to load Create Connection Profile Page
	*/
	createConnectionProfileClick:function(){
		console.log('CreateConnectionProfileClick of ConnectionProfileController: start');
		var detailPanel = Ext.create('AdminConsole.view.ConnectionProfileDetail',{
							width:980
						});						
		//remove readonly default seting.
		detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').fieldDefaults.readOnly=false;
		
		//detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').down('#createConnProfileTeamCenterFieldsFieldset').down('#vendContLicenseConsume').setValue(0);		
		
		//detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').down('#createConnProfileTeamCenterConfigFieldset').hidden = true;
		detailPanel.down('#connectionProfileFormPanel').down('#connectionProfileForm').down('#createConnProfileTeamCenterConfigFieldset').setVisible(false);
		
		
		detailPanel.down('#connectionProfileBtnContainer').down('#saveConnectionProfileBtn').hidden=false;
		detailPanel.down('#connectionProfileBtnContainer').down('#updateConnectionProfileBtn').hidden=true;
		detailPanel.down('#connectionProfileBtnContainer').down('#testTCAttributeBtn').hidden=true;
		
		AdminConsole.MyUtil.showPopUp(detailPanel,'');
		console.log('CreateConnectionProfileClick of ConnectionProfileController: End');
	},
	
	/**
	*This method tests the team center connection, before creating a connection profile
	*/
	testConnectionProfileClick:function(connectionProfileFormBtn){
		console.log('testConnectionProfileClick method of ConnectionProfileController : Start');
		
		var connectionProfileForm = connectionProfileFormBtn.up('#connectionProfileFormPanel').down('#connectionProfileForm');
		
		if (!connectionProfileForm.getForm().isValid()) {
			console.log("Connection Profile Form is invalid");
			return;
		} 
		
		connectionProfileFormData = connectionProfileForm.getForm().getValues();
		
		console.log(connectionProfileFormData);
		
						
		if(AdminConsole.Constants.SYN_SUGARCRM.toUpperCase() == connectionProfileFormData.code.toUpperCase()){
			Ext.Msg.alert(fetch.label.error,fetch.label.testConnUnimplementedError);
			return;
		}
		else if(AdminConsole.Constants.SYN_SAP.toUpperCase() == connectionProfileFormData.code.toUpperCase()){
			Ext.Msg.alert(fetch.label.error,fetch.label.testConnUnimplementedError);
			return;
		}	
		else if(AdminConsole.Constants.SYN_SCF.toUpperCase() == connectionProfileFormData.code.toUpperCase()){
		
			Ext.getBody().mask(fetch.label.testingConnectionProfile);
		
			Ext.Ajax.request({
				url : AdminConsole.Constants.baseURL + '/oem/testSCFConnectionProfile.htm',
				method : 'POST',
				isSynchronous:true,
				params : Ext.JSON.encode(connectionProfileFormData),
				headers : {'Content-Type':'application/json','Accept':'application/json'},
				timeout:1136000,
				success : function(response) {
					Ext.getBody().unmask();
					console.log('Response for testSCFConnectionProfile rest call is'+response.responseText);
					var responseStatus = response.responseText;//AdminConsole.MyUtil.backendSystemResponseDecodeAction(response.responseText);
					
					if('undefined' != responseStatus && null != responseStatus){
						if(AdminConsole.Constants.STATUS_SUCCESS.toUpperCase() == responseStatus.toUpperCase()){
							Ext.Msg.alert( fetch.label.success, fetch.label.testConnectionSuccess);
						}						
						//else if(AdminConsole.Constants.STATUS_FAIL.toUpperCase() == responseStatus.toUpperCase()){
						else{	
							Ext.Msg.alert(fetch.label.error,fetch.label.sysError);
						} 
					}
					
				},
				failure : function(response) {
					Ext.getBody().unmask();	
					Ext.Msg.alert(fetch.label.fail,fetch.label.fail.communicationFail);
				}
			});
		}
		else if(AdminConsole.Constants.SYN_TEAMCENTER.toUpperCase() == connectionProfileFormData.code.toUpperCase()){
		
			//When checkbox is chekcked it's value is 'on', it is converted to boolean value, so that it will be treated as a boolean value.
			if(connectionProfileFormData.proxyEnabledFlag != undefined && connectionProfileFormData.proxyEnabledFlag == 'on'){
				console.log('Is prxy enable form field checked');
				connectionProfileFormData.proxyEnabledFlag = AdminConsole.Constants.CHECKED;  
			}else{
				console.log('Is prxy enable form field unchecked');
				connectionProfileFormData.proxyEnabledFlag = AdminConsole.Constants.UNCHECKED;  
			}
			
			if(connectionProfileFormData.withoutClassification != undefined && connectionProfileFormData.withoutClassification == 'on'){
				console.log('Is withoutClassification  form field checked');
				connectionProfileFormData.withoutClassification =true;
			}else{
				console.log('Is withoutClassification  form field unchecked');
				connectionProfileFormData.withoutClassification = false; 
			}
		
		
		
			Ext.getBody().mask(fetch.label.testingConnectionProfile);
		
			Ext.Ajax.request({
				url : AdminConsole.Constants.baseURL + '/oem/testTeamCenterConnectionProfile.htm',
				method : 'POST',
				isSynchronous:true,
				params : Ext.JSON.encode(connectionProfileFormData),
				headers : {'Content-Type':'application/json','Accept':'application/json'},
				timeout:1136000,
				success : function(response) {
					Ext.getBody().unmask();
					console.log('Response for testTeamCenterConnectionProfile rest call is'+response.responseText);
					var responseStatus = AdminConsole.MyUtil.backendSystemResponseDecodeAction(response.responseText);
					
					if('undefined' != responseStatus && null != responseStatus){
						if(AdminConsole.Constants.STATUS_SUCCESS.toUpperCase() == responseStatus.toUpperCase()){
							Ext.Msg.alert( fetch.label.success, fetch.label.testConnectionSuccess);
						}						
						//else if(AdminConsole.Constants.STATUS_FAIL.toUpperCase() == responseStatus.toUpperCase()){
						else{	
							Ext.Msg.alert(fetch.label.error,fetch.label.sysError);
						} 
					}
					
				},
				failure : function(response) {
					Ext.getBody().unmask();	
					Ext.Msg.alert(fetch.label.fail,fetch.label.fail.communicationFail);
				}
			});
		}
		
		
		console.log('testConnectionProfileClick method of ConnectionProfileController : End');		
	},
	
	/**
	*This method tests the team center attributes, before creating a connection profile
	*/
	testTCAttributeClick :function(connectionProfileFormBtn){
		console.log('testTCAttributeClick method of ConnectionProfileController : Start');
		var connectionProfileForm =	connectionProfileFormBtn.up('#connectionProfileFormPanel').down('#connectionProfileForm');
		connectionProfileFormData = connectionProfileForm.getForm().getValues();
		
		if (!connectionProfileForm.getForm().isValid()) {
			console.log("Connection Profile Form is invalid");
			return;
		
		}

		if(AdminConsole.Constants.SYN_TEAMCENTER.toUpperCase() == connectionProfileFormData.code.toUpperCase()){
			
			if((connectionProfileFormData.commCodeAttr == "" || connectionProfileFormData.commCodeAttr == null )&& !connectionProfileFormData.withoutClassification ){
				//Ext.Msg.alert(fetch.label.error,fetch.label.commodityCodeAttribute +' ' +fetch.label.nullValidationMsg);
				connectionProfileForm.down('#commCodeAttr').markInvalid(fetch.label.fieldRequired);
				return;
			}else if((connectionProfileFormData.classStatusRootClassId == "" || connectionProfileFormData.classStatusRootClassId == null )&& !connectionProfileFormData.withoutClassification){
				//Ext.Msg.alert(fetch.label.error,fetch.label.classStatusRootClassId +' ' +fetch.label.nullValidationMsg);
				connectionProfileForm.down('#classStatusRootClassId').markInvalid(fetch.label.fieldRequired);
				return;
			}else if((connectionProfileFormData.contRoleRootClassId == "" || connectionProfileFormData.contRoleRootClassId == null)&& !connectionProfileFormData.withoutClassification ){
				//Ext.Msg.alert(fetch.label.error,fetch.label.contRoleRootClassId +' ' +fetch.label.nullValidationMsg);
				connectionProfileForm.down('#contRoleRootClassId').markInvalid(fetch.label.fieldRequired);
				return;
			}
			else if((connectionProfileFormData.classificationClassName == "" || connectionProfileFormData.classificationClassName == null )&& !connectionProfileFormData.withoutClassification){
				//Ext.Msg.alert(fetch.label.error,fetch.label.contRoleRootClassId +' ' +fetch.label.nullValidationMsg);
				connectionProfileForm.down('#classificationClassName').markInvalid(fetch.label.fieldRequired);
				return;
			}
			else if((connectionProfileFormData.maxNoOfRoles == "" || connectionProfileFormData.maxNoOfRoles == null )&& !connectionProfileFormData.withoutClassification){
				//Ext.Msg.alert(fetch.label.error,fetch.label.contRoleRootClassId +' ' +fetch.label.nullValidationMsg);
				connectionProfileForm.down('#maxNoOfRoles').markInvalid(fetch.label.fieldRequired);
				return;
			}
		}
		
		//When checkbox is chekcked it's value is 'on', it is converted to boolean value, so that it will be treated as a boolean value.
		if(connectionProfileFormData.proxyEnabledFlag != undefined && connectionProfileFormData.proxyEnabledFlag == 'on'){
			console.log('Is prxy enable form field checked');
			connectionProfileFormData.proxyEnabledFlag = AdminConsole.Constants.CHECKED;  
		}else{
			console.log('Is prxy enable form field unchecked');
			connectionProfileFormData.proxyEnabledFlag = AdminConsole.Constants.UNCHECKED;  
		}
		
		if(connectionProfileFormData.withoutClassification != undefined && connectionProfileFormData.withoutClassification == 'on'){
			console.log('Is withoutClassification form field checked');
			connectionProfileFormData.withoutClassification = true;  
		}else{
			console.log('Is withoutClassification  form field unchecked');
			connectionProfileFormData.withoutClassification = false;  
		}
		
		Ext.getBody().mask(fetch.label.testingAttributes);
		
		Ext.Ajax.request({
				url : AdminConsole.Constants.baseURL + '/oem/testTeamCenterAttribute.htm',
				method : 'POST',
				isSynchronous:true,
				params : Ext.JSON.encode(connectionProfileFormData),
				headers : {'Content-Type':'application/json','Accept':'application/json'},
				timeout:1136000,
				success : function(response) {
					console.log('Response for testTeamCenterAttribute rest call is'+response.responseText);	
					Ext.getBody().unmask();
					var responseStatus = AdminConsole.MyUtil.backendSystemResponseDecodeAction(response.responseText);
					
						if('undefined' != responseStatus && null != responseStatus){
						if(AdminConsole.Constants.STATUS_SUCCESS.toUpperCase() == responseStatus.toUpperCase()){
							Ext.Msg.alert( fetch.label.success, fetch.label.testAttributeSuccess);
						}
						else if ((AdminConsole.Constants.MAX_ROLE_REGEX).test(response.responseText)){
							Ext.Msg.alert(fetch.label.warning,fetch.label.maxRoleMsg+(response.responseText).split('-')[0]);
							return false;
						}
						
						else{
							Ext.Msg.alert(fetch.label.error,fetch.label.sysError);
						} 
					}
					
					
				},
				failure : function(response) {
					Ext.getBody().unmask();	
					Ext.Msg.alert(fetch.label.fail,fetch.label.fail.communicationFail);
				}
			});
		
		
		console.log('testTCAttributeClick method of ConnectionProfileController : End');		
	}
	
}


);

Ext.define('AdminConsole.controller.Home', {
    extend: 'Ext.app.Controller',
    
	refs:{
		indexP:'index'
	},

    /*init: function() {
        this.control({
            '#main-nav-toolbar button': {
                click: this.onMainNavClick
            }
        });
    },*/
    
    index: function(controller) {
		console.log("inside index");
		//var indexPage = controller.getIndex();
		//this.getLayout().setActiveItem('loginpanel');
		Ext.getCmp('index').getLayout().setActiveItem('loginpanel');
    },
    resetPwd:function(){
    	console.log("inside resetPwd");
    	Ext.getCmp('index').getLayout().setActiveItem('resetpassword');
    },
	showLoogedInErrorPage : function(){
		console.log('Main : inside showErrorPage');
		Ext.getCmp('index').getLayout().setActiveItem('userLoogedInErrorPage');		
	},
	showHome : function(){
		console.log("inside showHome");
		Ext.getCmp('index').getLayout().setActiveItem('homePage');
		Ext.getCmp('adminhome').getLayout().setActiveItem(0);
	},
	showContactUs : function(){
		console.log("inside showContactUs");
		Ext.getCmp('index').getLayout().setActiveItem('homePage');
		Ext.getCmp('adminhome').getLayout().setActiveItem('contact-page');
		
		
		
	}
    
    /*
    onMainNavClick: function(btn) {
        Ext.Router.redirect(btn.itemId === 'home' ? '' : btn.itemId);
    }*/
});
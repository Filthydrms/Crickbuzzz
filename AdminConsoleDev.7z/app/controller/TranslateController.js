Ext.define('AdminConsole.controller.TranslateController', {
    extend: 'Ext.app.Controller',
	
	views : ['Translate','TranslateData','Template','QueryTemplate','TemplateDetail'],
	models : [],
	stores : [],
	refs : [],
	
	init : function() {
		this.control({
			
			'button[action=searchTranslatedColumn]' :{
				click : this.onSearchTranslatedColumn
			},
			'#searchTranslatedColumnResult' : {
				itemclick : this.onSearchTranslatedColumnListItemClick
			},
			'button[action=saveTranslatedData]' :{
				click : this.onSaveTranslatedData
			},
			'button[action=openTemplateEditor]' :{
				click : this.openTemplateEditor
			},
			'button[action=templateEditorSubmit]' :{
				click : this.onTemplateEditorSubmit
			},
			'button[action=saveTemplate]' :{
				click : this.onSaveTemplate
			},
			'button[action=deleteTemplate]' :{
				click : this.onDeleteTemplate
			},
			'button[action=searchTemplate]' :{
				click : this.onSearchTemplate
			},
			'#searchTemplateResultForm' : {
				itemclick : this.onSearchTemplateColumnListItemClick
			},
			'button[action=saveTemplateTransalation]' :{
				click : this.onSaveTemplateTransalation
			},
		});
	},
	
	onTranslateEntity:function(btn){
		console.log('Inside onTranslateEntity');
		Ext.getCmp('index').getLayout().setActiveItem('homePage');	
		Ext.getCmp('adminhome').getLayout().setActiveItem('translate');		
		var trans=Ext.getCmp('adminhome').down('#translate');
		trans.down('#searchTranslatedColumnResult').setVisible(false);
		trans.down('form').getForm().reset();
	},
	onSearchTranslatedColumn:function(btn){
		console.log('Inside onSearchTranslatedColumn');
		var form = btn.up('form');
		
		var formValues = form.getForm().getValues();
		if (!form.getForm().isValid()) {
			console.log("Form is invalid");
			return;
		}
		console.log(formValues);
		AdminConsole.MyUtil.showMask(btn,fetch.label.fetching);
		
		btn.up('#translate').down('#searchTranslatedColumnResult').setVisible(true);
		btn.up('#translate').down('#searchTranslatedColumnResult').setTitle(form.down('#entity').rawValue+' '+fetch.label.list);
		var store=Ext.getStore('QueryTranslatedStore');
		store.removeAll();
		var data={
					//code:formValues.code?formValues.code:null,
					//name:formValues.name?formValues.name:null,
					search:formValues.search?formValues.search:null,
					entityId:formValues.entity,//form.down('#entity').rawValue,
					langCode:formValues.lang,
					columnId:formValues.column
				};
		store.currentPage =1;
		store.load({
			    params:{
				data:Ext.JSON.encodeValue(data)
				}
		});
	},
	onSearchTranslatedColumnListItemClick:function(me, record, item, index, e, eOpts){
		console.log('Inside onSearchTranslatedColumnListItemClick');
		var searchForm = me.up('translate').down('form');
		var formValues = searchForm.getForm().getValues();
		var transData={
			entityTableId:parseInt(formValues.entity),
			entityId:record.get('entityId'),
			langCode:formValues.lang,
			langEntityId:0,
			transColumnId:"",
			translatedValue:""
		};
		console.log(transData);
		Ext.Ajax.request({
			url : AdminConsole.Constants.baseURL + '/getEntityTranslationDetail.htm',
			method : 'POST',
			timeout:180000,
			params : Ext.JSON.encode(transData),
			headers :
			{
				'Content-Type' : 'application/json',
			},
			success : function(response) {
						//console.log(response.responseText);
						var decodedData = Ext.JSON.decode(response.responseText);
						var entTransId =0;
						if(decodedData.result.length>0){
							entTransId = decodedData.result[0].entityId;
						}							
						var detailPanel = Ext.create('AdminConsole.view.TranslateData',{
							width:600,
							height:300
							
						});
						
						detailPanel.down('form').getForm().findField('actual').setValue(record.get('actual'));
						detailPanel.down('form').getForm().findField('translated').setFieldLabel(searchForm.down('#lang').rawValue);
						detailPanel.down('form').getForm().findField('translated').setValue(record.get('translated'));
						
						detailPanel.down('form').getForm().findField('entityId').setValue(record.get('entityId'));
						detailPanel.down('form').getForm().findField('entityTableId').setValue(searchForm.down('#entity').value);
						detailPanel.down('form').getForm().findField('langCode').setValue(searchForm.down('#lang').value);
						detailPanel.down('form').getForm().findField('colName').setValue(searchForm.down('#column').value);
						detailPanel.down('form').getForm().findField('langEntityId').setValue(entTransId);
						var win = AdminConsole.app.getController('PurchaseCategoryController').createPopUp(true);
						win.on('beforeremove',function(){
								Ext.getStore('QueryTranslatedStore').reload();
							},this);
						if(win){
							win.add(detailPanel);
							win.show();
						}
					
					
			},
			failure : function(response) {
				alert(fetch.label.communicationMsg);
				AdminConsole.MyUtil.hideMask();	
			}
		});
		
	},
	onSaveTranslatedData:function(btn){
		console.log('Inside onSaveTranslatedData');
		var formValues = btn.up('form').getForm().getValues();
		var transData={
			entityTableId:formValues.entityTableId,
			entityId:formValues.entityId,
			langCode:formValues.langCode,
			langEntityId:formValues.langEntityId,
			transColumnId:formValues.colName,
			translatedValue:formValues.translated
		};
		Ext.Ajax.request({
			url : AdminConsole.Constants.baseURL + '/saveEntityTranslation.htm',
			method : 'POST',
			timeout:180000,
			params : Ext.JSON.encode(transData),
			headers :
			{
				'Content-Type' : 'application/json',
			},
			success : function(response) {
						console.log(response.responseText);
						if(response.responseText==AdminConsole.Constants.STATUS_SUCCESS){
						
							Ext.Msg.alert(fetch.label.success,fetch.label.translatedDataSucessMsg,function(mBtn){
							var win=btn.up('window');
								if(win)
								{
									win.close();
								}
							});
						}
						else{
							Ext.Msg.alert(fetch.label.success,fetch.label.translatedDataFailureMsg);
						}
					
					
			},
			failure : function(response) {
				alert(fetch.label.communicationMsg);
				AdminConsole.MyUtil.hideMask();	
			}
		});		
	},
	onCreateTemplate:function(btn){
		console.log('Inside onCreateTemplate');
		Ext.getCmp('index').getLayout().setActiveItem('homePage');	
		Ext.getCmp('adminhome').getLayout().setActiveItem('template');		
		var trans=Ext.getCmp('adminhome').down('#template');
		trans.down('form').getForm().reset();
		trans.down('form').getForm().findField('code').setReadOnly(false);
	},
	onQueryTemplate:function(btn){
		console.log('Inside onQueryTemplate');
		Ext.getCmp('index').getLayout().setActiveItem('homePage');	
		Ext.getCmp('adminhome').getLayout().setActiveItem('query-template');		
		var trans=Ext.getCmp('adminhome').down('#query-template');
		trans.down('#searchTemplateResultForm').setVisible(false);
		trans.down('form').getForm().reset();
	},
	openTemplateEditor : function(btn){
		console.log('Inside openTemplateEditor');
			var form = btn.up('form');
			var emailText = form.getForm().findField('htmlEditorHiddenField').getValue();
			console.log(emailText);
			var htmlEditorWin = Ext.create('Ext.Window',{
				title : fetch.label.emailText,
				itemId:'htmlEditorWin',
				width : 750,
				height : 300,
				modal : true,
				resizable : true,
				//layout : 'fit',
				autoScroll:false,
				listeners:{
						beforeclose: function( htmlEditorWin, eOpts ){
							htmlEditorWin.removeAll(true);
							htmlEditorWin.hide();
							return false;
						}
					}			
			});
			var htmlEditorPan = Ext.create('Ext.form.Panel',{
				itemId : 'htmlEditorPan',	
				callingParent:btn,
				autoScroll : true,				
				items : [
						{
							xtype : 'htmlEditor',							
						}					
					]				
			});	
			htmlEditorPan.down('#htmlEditorBtn').action='templateEditorSubmit';
			htmlEditorWin.add(htmlEditorPan);			
			htmlEditorPan.down('#htmlEditorField').setValue(emailText);
			htmlEditorWin.show();				
	},
	onTemplateEditorSubmit: function(btn){
		var htmlEditorHiddenField = btn.up('#htmlEditorPan').callingParent.up('form').down('#htmlEditorHiddenField');
		var htmlEditorFieldValue = btn.up('#htmlEditorPan').getForm().getValues().htmlEditorField;
		htmlEditorHiddenField.setValue(htmlEditorFieldValue);		
		btn.up('#htmlEditorWin').close();
	},
	onSaveTemplate:function(btn){
		console.log("inside save data");
		var form=btn.up('form');
		var formValues = form.getForm().getValues();
		 if(templateCodeUnique==false){
			Ext.Msg.alert(fetch.label.error, fetch.label.mandatoryFields);
			return;
		 }
		 if (!form.getForm().isValid()) {
			console.log("Form is invalid");
			Ext.Msg.alert(fetch.label.error, fetch.label.mandatoryFields);
			return;
		}
		var data = {
			templateCode : formValues.code,
			templateBody: formValues.htmlEditorHiddenField,
			templateSubject : formValues.subject,
			templateId : formValues.id?formValues.id:0
			
		};
		AdminConsole.MyUtil.showMask(form,fetch.label.saving);
		var url;		
		
		url = AdminConsole.Constants.baseURL + '/oem/saveOrUpdateTemplate.htm';
		Ext.Ajax.request({
			url : url,
			method : 'POST',
			timeout:180000,
			params : Ext.JSON.encode(data),
			headers :
			{
				'Content-Type' : 'application/json',
			},
			success : function(response) {
					console.log(response.responseText);
					AdminConsole.MyUtil.hideMask();
					var decodedData=Ext.JSON.decode(response.responseText);
					
						Ext.Msg.alert(fetch.label.success, fetch.label.savedDataMsg,function(btn1){
						if(btn1=='ok'){
						
							form.getForm().findField('code').setReadOnly(true);	
							form.getForm().findField('id').setValue(decodedData.templateId);	
							AdminConsole.MyUtil.hideMask();
							var window=btn.up('window');
							if(window)
								window.close();
					  
						}
						});
					
					
			},
			failure : function(response) {
				alert(fetch.label.communicationMsg);
				AdminConsole.MyUtil.hideMask();	
			}
		});			
	},
	onDeleteTemplate:function(btn){
	console.log(' inside onDeleteTemplate');
	var form=btn.up('form');
	var formValues = form.getForm().getValues();
	Ext.Msg.confirm(fetch.label.warning,fetch.label.removeDataMsg,function(button){
	console.log('choice',button);
		if(button=='yes'||button=='Yes'){
		
		console.log('delete record');
				var removeData = {
					templateCode : formValues.code,
					templateBody: null,
					templateSubject : null,
					templateId : formValues.id?formValues.id:0
				};
				console.log('remove',removeData);
				AdminConsole.MyUtil.showMask(form,fetch.label.removing);
				Ext.Ajax.request({
					headers : {'Content-Type':'application/json'},
					url : AdminConsole.Constants.baseURL + '/oem/deleteTemplate.htm',
					params: Ext.JSON.encode(removeData),
					async : true,
					timeout : 3600*1000,//1 hr
					success: function(resp) {
							if(resp.responseText=='SUCCESS'){
								Ext.Msg.alert(fetch.label.success, fetch.label.removeDataSuccessMsg);
								AdminConsole.MyUtil.hideMask();
								form.getForm().reset();
								if(btn.up('window'))
								btn.up('window').close();
								Ext.getStore('QueryTemplateStore').reload();
						}
						else{
							Ext.Msg.alert(fetch.label.error,fetch.label.removeDataFailMsg); 
							AdminConsole.MyUtil.hideMask();
						}
							

					},
					failure: function(form, action) {
						alert ('communcation failed.');
						AdminConsole.MyUtil.hideMask();
					}
				});
		
		}
	});
	},
	onSearchTemplate: function(btn){
		console.log("inside search data");
		var me = this;
		var form = btn.up('form');				
		var formValues = form.getForm().getValues();
		console.log('formValues',formValues);		
		AdminConsole.MyUtil.showMask(form,fetch.label.fetching);
		Ext.getStore('QueryTemplateStore').removeAll();
		btn.up('#query-template').down('#searchTemplateResultForm').setVisible(true);
		dataQuery={
			templateCode : formValues.code,
			templateBody: null,
			templateSubject : null,
			templateId : 0		
		};
		var url;		
		var store=Ext.getStore('QueryTemplateStore');
		store.currentPage =1;
		store.load({
			    params:{
				data:Ext.JSON.encodeValue(dataQuery)
				}
		});
	},
	onSearchTemplateColumnListItemClick:function(me, record, item, index, e, eOpts){
		console.log('Inside onSearchTemplateColumnListItemClick');
		AdminConsole.MyUtil.showMask(me.up('query-template'),fetch.label.fetching);
		var tempId=record.data.templateId;
		Ext.Ajax.request({
			method : 'POST',
			url : AdminConsole.Constants.baseURL + '/oem/getTemplateDetail.htm',
			params: {'templateId':tempId},
			async : true,
			timeout : 3600*1000,//1 hr
			success: function(response) {
						AdminConsole.MyUtil.hideMask();
						var decodedData=Ext.JSON.decode(response.responseText);
						var detailPanel = Ext.create('AdminConsole.view.TemplateDetail',{
							width:850,
							height:530
							
						});
						detailPanel.getForm().findField('actualSubject').setValue(decodedData.templateSubject);
						detailPanel.getForm().findField('actualTemplateField').setValue(decodedData.templateBody);
						detailPanel.getForm().findField('templateId').setValue(tempId);
						
						var win = AdminConsole.app.getController('PurchaseCategoryController').createPopUp(true);
						if(win){
							win.add(detailPanel);
							win.title=fetch.label.template+' '+fetch.label.detail;
							win.titleAlign='center';
							win.show();
						}
					

			},
			failure: function(form, action) {
				alert ('communcation failed.');
				AdminConsole.MyUtil.hideMask();
			}
		});						
	
	},
	onSaveTemplateTransalation:function(btn){
		console.log("inside save data");
		var form=btn.up('form');
		var formValues = form.getForm().getValues();
		 if (!formValues.actualSubject || !formValues.actualTemplateField || (!form.down('#translatedTemplateField').hidden && !formValues.translatedTemplateField) || (!form.down('#translatedSubject').hidden && !formValues.translatedSubject)) {
			console.log("Form is invalid");
			Ext.Msg.alert(fetch.label.error, fetch.label.mandatoryFields);
			return;
		}
		
		
		var data = {
			langCode : formValues.lang,
			templateId : formValues.templateId,
			tempLangBody : formValues.translatedTemplateField,
			tempLangSubject : formValues.translatedSubject,
			tempLangId : formValues.tempLangId?formValues.tempLangId:0,
			body : formValues.actualTemplateField,
			subject : formValues.actualSubject,
			
		};
		AdminConsole.MyUtil.showMask(form,fetch.label.saving);
		var url;		
		
		url = AdminConsole.Constants.baseURL + '/oem/saveTemplateTranslation.htm';
		Ext.Ajax.request({
			url : url,
			method : 'POST',
			timeout:180000,
			params : Ext.JSON.encode(data),
			headers :
			{
				'Content-Type' : 'application/json',
			},
			success : function(response) {
					console.log(response.responseText);
					AdminConsole.MyUtil.hideMask();
					var decodedData=Ext.JSON.decode(response.responseText);
					
						Ext.Msg.alert(fetch.label.success, fetch.label.savedDataMsg,function(btn1){
						if(btn1=='ok'){	
							AdminConsole.MyUtil.hideMask();
							var window=btn.up('window');
							
							if(window){
								window.close();
								Ext.getStore('QueryTemplateStore').reload();
							}
					  
						}
						});
					
					
			},
			failure : function(response) {
				alert(fetch.label.communicationMsg);
				AdminConsole.MyUtil.hideMask();	
			}
		});			
	},
});

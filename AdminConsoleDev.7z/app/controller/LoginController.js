/* Processing of login details */
var tenant;
Ext.define('AdminConsole.controller.LoginController', {
	extend : 'Ext.app.Controller',
	views : [ 'Login','ResetPasswordView'],
	models : [],
	stores : [  ],
	requires : [ 'AdminConsole.MyUtil' ,'Ext.util.Cookies'],
	refs : [ {
		ref : 'logForm',
		selector : '#loginform'
	} ],
	init : function() {
		this.control({
			'#loginform button[itemId=loginbutton]' : {
				click : this.loginuser

			},
			'#loginform > textfield' : {
				specialkey : function(field, e) {
					if (e.getKey() == e.ENTER) {
						// field.up('form').getForm().submit();
						console.log("login enter");
						this.loginuser(this);
					}
				}
			}
		});
	},
    showLoginPage:function(p){
		console.log("LoginController : inside showLoginPage()");
		var me = this;
		console.log(p.tenantKey);
		if(p.tenantKey==undefined||p.tenantKey==null){
			Ext.getCmp('index').getLayout().setActiveItem('errorPage');			
		}else{			
			me.tenantKey = p.tenantKey;
			Ext.util.Cookies.set("tenant",p.tenantKey);
			//console.log(p.userType);
			
			this.userType = p.userType;
			//Ext.util.Cookies.set("userType","OEM");
			Ext.getCmp('index').getLayout().setActiveItem('loginpanel');
		}
	},
	loginuser : function() {
		var me = this;
		var form = this.getLogForm();
		if (!form.getForm().isValid()) {
			console.log("login form invalid");
			return;
		}

		var formValues = form.getForm().getValues();
		//console.log(">>>>>>>>>>" + formValues.tenant);
		var dataCP = {
			j_username : formValues.j_username,
			j_password : formValues.j_password,
			tenant : me.tenantKey,
			serviceCode : 'adminconsole',
			_spring_security_remember_me : 'on'
			
		};
		console.log("dataCP" + dataCP.j_username);
		
		var url;
		//Ext.util.Cookies.set("userType","OEM");
		url = AdminConsole.Constants.baseURL + '/oem/senchaLogin.htm';
		Ext.Ajax.request({
			url : url,
			method : 'POST',
			timeout:180000,
			params : dataCP,
			success : function(response) {
				//console.log(response);
				//console.log("response.getAllResponseHeaders()");
				
				//var value = Ext.util.Cookies.get('userName');
				//console.log("cookie username value :");
				//console.log(value);
				//var value = Ext.util.Cookies.get('SPRING_SECURITY_REMEMBER_ME_COOKIE');
				//console.log(value);
					console.log(response.responseText);
					
					//var status = AdminConsole.MyUtil.decodeAction(response.responseText);
					var status = AdminConsole.MyUtil.decodeAction(response.getResponseHeader("code"));
					console.log(status);
					if (status == "success") {
						console.log('login successful');
						//Ext.getCmp('loginform').getForm().reset();
						// var view=Ext.getCmp('index');
						// view.getLayout().setActiveItem(2);
						
						//Store the username in sessionStorage
						//var propStore = Ext.getStore('SessionPropStore');
						//propStore.load();
						//FISRT CLEAR THE STORE TO REMOVE ANY PREVIOUS USERNAME
						//propStore.removeAll();
						//propStore.sync();
						//propStore.add({userName: formValues.j_username});
						//propStore.sync();
						//if (formValues.userType=="OEM"){
							//AdminConsole.MyUtil.userType=formValues.userType;
						Ext.util.Cookies.set('userName',formValues.j_username);
						Ext.util.Cookies.set("userType","OEM");
						Ext.Router.redirect('home');

					} else if (status == "fail") {
						Ext.Msg.alert('', fetch.label.usernamePasswordIncorrectMsg);
					}

			},
			failure : function(response) {
				alert("Communication failed");
			}
		});
		/*
		 * Ext.Ajax.request({
		 * url:AdminConsole.Constants.baseURL+'/throwAnException.htm', method:'GET',
		 * params:formValues, success: function(response){
		 * console.log(response.responseText); } });
		 */
	},
	logoutUser : function() {
		Ext.Router.redirect('');
	}
});
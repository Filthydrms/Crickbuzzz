var pcId=0,status='',teamSaved=null,purCatData=null;
Ext.define('AdminConsole.controller.PurchaseCategoryController', {
	extend : 'Ext.app.Controller',
	views : ['AssignUNSPSCView','ProdCatSelector','AssignTeamView'],
	models : [],
	stores : [],
	
	refs : [ 
		{
			ref : 'createPurchaseCategoryForm',
			selector : '#createPurchaseCategoryForm'
		},
		{
			ref : 'createActionForm',
			selector : '#createActionForm'
		},
		{
			ref : 'createDataForm',
			selector : '#createDataForm'
		},
		{
			ref : 'editDataForm',
			selector : '#editDataForm'
		},
		{
			ref : 'queryActionForm',
			selector : '#queryActionForm'
		},
		{
			ref : 'queryDataForm',
			selector : '#queryDataForm'
		},
		{
			ref : 'createRoleForm',
			selector : '#createRoleForm'
		},
		{
			ref : 'queryRoleForm',
			selector : '#queryRoleForm'
		},
		{
			ref:'teamView',
			selector:'assign-team'
		},{
			ref:'createView',
			selector:'create-product-category'
		},
		{
			ref : 'purchaseCategoryQueryForm',
			selector : '#queryPCForm'
		},{
			ref:'querySearchResultGrid',
			selector:'#querySearchResultForm'
		},
		{
			ref : 'createPurchaseCategory',
			selector : '#create-product-category'
		},
		{
			ref:'querySearchActionResultGrid',
			selector:'gridpanel#querySearchActionResultForm'
		},
		{
			ref:'querySearchRoleResultGrid',
			selector:'gridpanel#querySearchRoleResultForm'
		},
		{
			ref:'querySearchDataResultGrid',
			selector:'gridpanel#querySearchDataResultForm'
		},
		
		
		
	],
	init : function() {
		this.control({
			'button[action=savePCButton]' :{
				click : this.onSavePurchaseCategory
			},
			'button[action=saveAction]' :{
				click : this.onSaveAction
			},
			'button[action=saveRole]' :{
				click : this.onSaveRole
			},
			'button[action=saveData]' :{
				click : this.onSavePrivacyData
			},
			'button[action=onAssignTeamSave]' :{
				click : this.onSaveAssignTeam
			},
			/*'menu > menuitem#createPurchaseCategory':{
				click : this.onCreatePurchaseCategory
			},*/
			'button[action=assignTeamButton]' :{
				click : this.onassignTeam
			},
			'button[action=searchButtonQueryScreen]' :{
				click : this.onSearchQueryPurchaseCategory
			},
			'button[action=searchAction]' :{
				click : this.onSearchQueryAction
			},
			'button[action=searchRole]' :{
				click : this.onSearchQueryRole
			},
			'button[action=searchData]' :{
				click : this.onSearchQueryData
			},
			/*'menu > menuitem#queryPurchaseCategory':{
				click : this.onQueryPurchaseCategory
			},*/
			'#querySearchResultForm' : {
				itemclick : this.onPurchaseCategorySearchListItemClick
			},
			'#querySearchActionResultForm' : {
				itemclick : this.onActionSearchListItemClick
			},
			'#querySearchRoleResultForm' : {
				itemclick : this.onRoleSearchListItemClick
			},
			'#querySearchDataResultForm' : {
				itemclick : this.onDataSearchListItemClick
			},
			'button[action=editPCButton]' :{
				click : this.onEditPurchaseCategory
			},
			'button[action=create]' :{
				click : this.onSubmitUnspsc
			},
			'button[action=cancelButton]' :{
				click : this.onCreateCancel
			},
			'button[action=Cancel]' :{
				click : this.onAssignTeamCancel
			},
			'button[action=assignUnspscButton]' :{
				click : this.onassignUnspsc
			},
			'button[action=releaseButton]' :{
				click : this.onReleasePurchaseCategory
			},
			'button[action=deleteRole]' :{
				click : this.onDeleteRole
			},
			'button[action=deleteData]' :{
				click : this.onDeleteData
			},
			'button[action=deleteAction]' :{
				click : this.onDeleteAction
			},
			'button[action=htmlEditorPanel]' :{
				click : this.openHtmlEditor
			},
			'button[action=htmlEditorSubmit]' :{
				click : this.htmlEditorSubmit
			},
			'button[action=onSearchTeam]' :{
				click : this.onSearchTeam
			},
			'button[action=assignService]' :{
				click : this.onAssignService
			},
			'button[action=selectAvaibleService]' :{
				click : this.onAssigningService
			},
			'button[action=selectAssignedService]' :{
				click : this.onDeassigningService
			},
			
			
		});
	},
	
	onActionRole:function(){
	console.log("inside action role");
	//AdminConsole.MyUtil.showMask(form,'Fetching..');
	var data=null;
	//var url='actionRole.json';
	var url = AdminConsole.Constants.baseURL + '/oem/getActionRoles.htm';
	Ext.Ajax.request({
			url : url,
			method : 'POST',
			timeout:180000,
			params : Ext.JSON.encode(data),
			headers :
			{
				'Content-Type' : 'application/json',
			},
			success : function(response) {
					console.log(response.responseText);
					var decodedData=Ext.JSON.decode(response.responseText);
					//AdminConsole.MyUtil.hideMask();
					if(decodedData.roles){
					Ext.getStore('Role').loadData(decodedData.roles);
					}
					if(decodedData.screens){
					Ext.getStore('Screens').loadData(decodedData.screens);
					}
					Ext.getCmp('action-role-panel').update(decodedData);
					Ext.getCmp('index').getLayout().setActiveItem('homePage');	
					Ext.getCmp('adminhome').getLayout().setActiveItem('action-role');
					
			},
			failure : function(response) {
				Ext.Msg.alert(fetch.label.serverCommunicationFailureMessage);
				//AdminConsole.MyUtil.hideMask();	
			}
		});
	
	
	},
	
	onCreatePurchaseCategory:function(){
		var me=this;
		console.log("inside create PC");
		status='';
		var form = me.getCreatePurchaseCategoryForm();
		form.getForm().findField('code').setReadOnly(false);
		form.getForm().reset();		
		var view=me.getCreateView();
		
		view.down('assign-unspsc-grid').setVisible(false);
		view.down('assign-team-grid').setVisible(false);
		form.down('button[action="assignTeamButton"]').setDisabled(true);
		form.down('button[action="assignUnspscButton"]').setDisabled(true);	
		form.down('button[action="releaseButton"]').setDisabled(true);
		view.down('assign-unspsc-grid').getStore().removeAll();
		view.down('assign-team-grid').getStore().removeAll();		
		Ext.getCmp('index').getLayout().setActiveItem('homePage');	
		Ext.getCmp('adminhome').getLayout().setActiveItem('create-product-category');
	},
	onCreateData:function(){
		var me=this;
		console.log("inside create action");
		var form = me.getCreateDataForm();
		form.getForm().findField('code').setReadOnly(false);
		form.down('button[action="deleteData"]').setDisabled(true);
		form.down('button[action="htmlEditorPanel"]').setDisabled(false);
		form.getForm().reset();		
		Ext.getCmp('index').getLayout().setActiveItem('homePage');	
		Ext.getCmp('adminhome').getLayout().setActiveItem('create-data');
	},
	onCreateAction:function(){
		var me=this;
		console.log("inside create action");
		var form = me.getCreateActionForm();
		form.getForm().findField('code').setReadOnly(false);
		form.down('button[action="deleteAction"]').setDisabled(true);
		form.getForm().findField('name').setReadOnly(false);
		form.getForm().reset();		
		Ext.getCmp('index').getLayout().setActiveItem('homePage');	
		Ext.getCmp('adminhome').getLayout().setActiveItem('create-action');
	},
	onCreateRole:function(){
		var me=this;
		console.log("inside create role");
		status='';
		var form = me.getCreateRoleForm();
		form.getForm().findField('name').setReadOnly(false);
		form.getForm().findField('description').setReadOnly(false);
		//form.down('button[action="deleteRole"]').setDisabled(true);
		form.getForm().reset();			
		Ext.getCmp('index').getLayout().setActiveItem('homePage');	
		Ext.getCmp('adminhome').getLayout().setActiveItem('create-role');
	},
	onSavePurchaseCategory:function(btn){
	var me = this;	
		AdminConsole.MyUtil.checkAuthorisationOnButton(AdminConsole.Constants.CREATING_PURCHASE_CATEGORY,function(authorised){
					if(authorised){
					me.onSavePurchaseCategoryImpl(btn);					
				}
			}
		)

	},
	onSavePurchaseCategoryImpl:function(btn){
		console.log("inside save PC");
		var form=btn.up('form');
		var formValues = form.getForm().getValues();
		 if (!form.getForm().isValid()) {
			console.log("Form is invalid");
			return;
		}
		
		
		//btn.up('form').up('panel').down('assign-unspsc-grid').setVisible(true);
		btn.up('form').up('panel').down('assign-team-grid').down('#removeTeam').setVisible(true);
		btn.up('form').up('panel').down('assign-unspsc-grid').down('#removeUnspsc').setVisible(true);
		var store = Ext.getStore('AssignTeamStore');
		var userList=[];
		var approverCount=0;
		if(store.getCount()>0){
			for(i=0;i<store.getCount();i++){
				var rec=store.getAt(i);
				if(rec.data.approver){
					approverCount++;
					
				}
			}
			if(approverCount<1)
			{
				Ext.Msg.alert(fetch.label.error,fetch.label.approverCountSmallerThn1);
				return false;
			}
			else if(approverCount>1)
			{
				Ext.Msg.alert(fetch.label.error,fetch.label.approverCountGreaterThn1);
				return false;
			}
		}
		for (i=0;i<store.getCount();i++)
		{
		userList.push(store.getAt(i).data);
		}
		var dataSavePC = {
			code : formValues.code,
			name : formValues.name,
			description:formValues.description,
			purchaseCatId :parseInt(formValues.purchaseCatId),
			teamList:userList,
			unspscList: null,	
			statusCode:formValues.publish?AdminConsole.Constants.STATUS_RELEASED_CODE:AdminConsole.Constants.STATUS_IN_PROCESS_CODE,
			
		};
		AdminConsole.MyUtil.showMask(form,fetch.label.saving);
		var url;		
		//url = 'jsonResponse.json';
		url = AdminConsole.Constants.baseURL + '/oem/saveOrUpdatePurchaseCategory.htm';
		Ext.Ajax.request({
			url : url,
			method : 'POST',
			timeout:180000,
			params : Ext.JSON.encode(dataSavePC),
			headers :
			{
				'Content-Type' : 'application/json',
			},
			success : function(response) {
					console.log(response.responseText);
					var decodedData=Ext.JSON.decode(response.responseText);
					if(decodedData.error){
					Ext.Msg.alert(fetch.label.error, fetch.label.alreadyExistString);
					AdminConsole.MyUtil.hideMask();
					return false;
					}
					else{
						Ext.Msg.alert(fetch.label.success, fetch.label.savedMsg,function(btn1){
						if(btn1=='ok'){
						
							form.getForm().findField('code').setReadOnly(true);
							form.down('button[action="assignTeamButton"]').setDisabled(false);
							form.down('button[action="assignUnspscButton"]').setDisabled(false);
							//form.down('button[action="releaseButton"]').setDisabled(false);
							form.getForm().findField('status').setValue(decodedData.status);
							//form.getForm().findField('teamSaved').setValue(true);
							teamSaved='true';
							form.down('#pcId').setValue(decodedData.purchaseCatId);
							pcId=decodedData.purchaseCatId;
							status=decodedData.statusCode;
							AdminConsole.MyUtil.hideMask();
							if(form.up('#create-product-category').down('assign-unspsc-grid'))
							form.up('#create-product-category').down('assign-unspsc-grid').getView().refresh();
							if(form.up('#create-product-category').down('assign-team-grid'))
							form.up('#create-product-category').down('assign-team-grid').getView().refresh();
							//if( btn.up('window'))
							//btn.up('window').close();
							//Ext.getCmp('adminhome').getLayout().setActiveItem('create-product-category');
					  
						}
						});
					}
					
			},
			failure : function(response) {
				alert(fetch.label.communicationMsg);
				AdminConsole.MyUtil.hideMask();	
			}
		});
		
		
	},
	
	onSaveAction:function(btn){
		console.log("inside save action");
		var form=btn.up('form');
		var formValues = form.getForm().getValues();
		 if (!form.getForm().isValid()) {
			console.log("Form is invalid");
			return;
		}
		if(!unique){
						Ext.Msg.alert(fetch.label.error,fetch.label.alreadyExistString);
						return;
					}
		
		//btn.up('form').up('panel').down('assign-unspsc-grid').setVisible(true);
		
		var dataSaveAction = {
			screenCode : formValues.code,
			screenName : formValues.name,
			actionRole : null
			//actionId :parseInt(formValues.actionId),
		};
		AdminConsole.MyUtil.showMask(form,fetch.label.saving);
		var url;		
		//url = 'jsonResponse.json';
		url = AdminConsole.Constants.baseURL + '/oem/saveOrUpdateAction.htm';
		Ext.Ajax.request({
			url : url,
			method : 'POST',
			timeout:180000,
			params : Ext.JSON.encode(dataSaveAction),
			headers :
			{
				'Content-Type' : 'application/json',
			},
			success : function(response) {
					console.log(response.responseText);
					var decodedData=Ext.JSON.decode(response.responseText);
					/*if(decodedData.error){
					Ext.Msg.alert(fetch.label.error, 'Already exist');
					AdminConsole.MyUtil.hideMask();
					return false;
					}
					else{*/
						Ext.Msg.alert(fetch.label.success, fetch.label.savedActionMsg,function(btn1){
						if(btn1=='ok'){
						
							form.getForm().findField('code').setReadOnly(true);	
							form.getForm().findField('name').setReadOnly(false);	
							form.down('button[action="deleteAction"]').setDisabled(false);
							AdminConsole.MyUtil.hideMask();
							var window=btn.up('window');
							if(window)
								window.close();
					  
						}
						});
					//}
					
			},
			failure : function(response) {
				alert(fetch.label.communicationMsg);
				AdminConsole.MyUtil.hideMask();	
			}
		});
		
		
	},
	
	onSaveRole:function(btn){
		console.log("inside save role");
		var form=btn.up('form');
		var formValues = form.getForm().getValues();
		 if (!form.getForm().isValid()) {
			console.log("Form is invalid");
			return;
		}
		if(!unique)
		{
			Ext.Msg.alert(fetch.label.error,fetch.label.alreadyExistString);
			return;
		}
					
		var dataSaveRole = {
			name : formValues.name,
			description:formValues.description,
			id :formValues.roleId,
			cpRoleId:formValues.cpRoleId,
			orgId:null,
			active:true
		};
		AdminConsole.MyUtil.showMask(form,fetch.label.saving);
		var url;		
		//url = 'jsonResponse.json';
		url = AdminConsole.Constants.baseURL + '/oem/saveOrUpdateRole.htm';
		Ext.Ajax.request({
			url : url,
			method : 'POST',
			timeout:180000,
			params : Ext.JSON.encode(dataSaveRole),
			headers :
			{
				'Content-Type' : 'application/json',
			},
			success : function(response) {
					console.log(response.responseText);
					var decodedData=Ext.JSON.decode(response.responseText);
					/*if(decodedData.error){
					Ext.Msg.alert(fetch.label.error, 'Already exist');
					AdminConsole.MyUtil.hideMask();
					return false;
					}*/
					//else{ 
					
						Ext.Msg.alert(fetch.label.success, fetch.label.savedRoleMsg,function(btn1){
						if(btn1=='ok'){
						
							form.getForm().findField('name').setReadOnly(false);
							form.getForm().findField('description').setReadOnly(true);
							form.getForm().findField('roleId').setValue(decodedData.id);
							form.getForm().findField('cpRoleId').setValue(decodedData.cpRoleId);
							//form.down('button[action="deleteRole"]').setDisabled(false);
							form.down('button[action="assignService"]').setDisabled(false);
							AdminConsole.MyUtil.hideMask();
							var window=btn.up('window');
							if(window)
								window.close();
						}
						});
					//}
					
			},
			failure : function(response) {
				alert(fetch.label.communicationMsg);
				AdminConsole.MyUtil.hideMask();	
			}
		});
		
		
	},
	
	onSavePrivacyData:function(btn){
		console.log("inside save data");
		var form=btn.up('form');
		var formValues = form.getForm().getValues();
		 if (!form.getForm().isValid()) {
			console.log("Form is invalid");
			Ext.Msg.alert(fetch.label.error, fetch.label.mandatoryFields);
			return;
		}
		
		
		//btn.up('form').up('panel').down('assign-unspsc-grid').setVisible(true);
		
		var dataSaveData = {
			privacyCode : formValues.code,
			privacyText : formValues.htmlEditorHiddenField,
			dataPrivacyId : formValues.id?formValues.id:0
			
		};
		AdminConsole.MyUtil.showMask(form,fetch.label.saving);
		var url;		
		//url = 'jsonResponse.json';
		url = AdminConsole.Constants.baseURL + '/oem/saveOrUpdateData.htm';
		Ext.Ajax.request({
			url : url,
			method : 'POST',
			timeout:180000,
			params : Ext.JSON.encode(dataSaveData),
			headers :
			{
				'Content-Type' : 'application/json',
			},
			success : function(response) {
					console.log(response.responseText);
					AdminConsole.MyUtil.hideMask();
					var decodedData=Ext.JSON.decode(response.responseText);
					/*if(decodedData.error){
					Ext.Msg.alert(fetch.label.error, 'Already exist');
					AdminConsole.MyUtil.hideMask();
					return false;
					}
					else{*/
						Ext.Msg.alert(fetch.label.success, fetch.label.savedDataMsg,function(btn1){
						if(btn1=='ok'){
						
							form.getForm().findField('code').setReadOnly(true);	
							form.down('button[action="deleteData"]').setDisabled(false);
							form.down('button[action="htmlEditorPanel"]').setDisabled(true);
							form.getForm().findField('id').setValue(decodedData.dataPrivacyId);	
							AdminConsole.MyUtil.hideMask();
							var window=btn.up('window');
							if(window)
								window.close();
					  
						}
						});
					//}
					
			},
			failure : function(response) {
				alert(fetch.label.communicationMsg);
				AdminConsole.MyUtil.hideMask();	
			}
		});
		
		
	},
	onassignTeam:function(btn){
	var newme = this;	
		AdminConsole.MyUtil.checkAuthorisationOnButton(AdminConsole.Constants.ASSIGNING_TEAM_TO_PURCHASING_CATEGORIES,function(authorised){
					if(authorised){
					newme.onassignTeamImpl(btn);					
				}
			}
		)
	},
	onassignTeamImpl:function(btn){
		console.log("inside Assign team");
		var me = this;
		var form=btn.up('form');
		var formValues = form.getForm().getValues();
		console.log(formValues);
		console.log('pc', formValues.purchaseCatId,form.down('#pcId').getValue());
		var view=btn.up('create-product-category');
		Ext.getStore('AvailableUserStore').removeAll();
		
		var dataTeamPC = {
			purchaseCatId :parseInt(formValues.purchaseCatId),
			name :formValues.name,
			status:formValues.status
		};
		purCatData=dataTeamPC;
		console.log("now create team view",dataTeamPC);
		//url = 'teamResponse.json';
		if(formValues.status==AdminConsole.Constants.STATUS_RELEASED_CODE)
			Ext.Msg.confirm(fetch.label.warning,fetch.label.chkMsgForPublishedPC,function(button){
				if (button=='Yes'||button=='yes'){
					me.showUserList();
					//AdminConsole.MyUtil.showMask(form,fetch.label.fetching);
				}
		});
		else{
		 me.showUserList();
		 //AdminConsole.MyUtil.showMask(form,fetch.label.fetching); 
		 }
	},
	
	
	showUserList:function(){
		var popup=this.createPopUp(true);
		var teamPanel = Ext.create('AdminConsole.view.AssignTeamView',{
					width:600,
					//height:500,					
		});	
		popup.add(teamPanel);
		popup.show();
		
		
	},
	onSearchTeam:function(btn){
	console.log('inside search team');
	var teamPanel=btn.up('assign-team');
	var formValues=btn.up('form').getForm().getValues();
	console.log('search query',formValues);
	var data={
				firstName:formValues.firstName?formValues.firstName:null,
				lastName:formValues.lastName?formValues.lastName:null,
				role:formValues.role?formValues.role:null,
				username:formValues.userName?formValues.userName:null,
				enabled:formValues.enable?formValues.enable:false 
	
		};
	dataTeamPC=purCatData;
	var store=Ext.getStore('AvailableUserStore');
		store.currentPage =1;
		store.load({
			    params:{
				data:Ext.JSON.encodeValue(data),
				purchaseCatId :purCatData.purchaseCatId
				}
				
		});
	
	
	
	},
	onSaveAssignTeam:function(btn){
		console.log('inside onSaveAssignTeam');
		
		var me = this;
		var form = me.getCreatePurchaseCategoryForm();
		var formValues=form.getForm().getValues();
		//var pcId=form.down('#pcId').getValue();
		var grid=me.getTeamView().down('gridpanel');
		var records=grid.getSelectionModel().getSelection();	
		if(records.length==0){
			Ext.Msg.alert(fetch.label.error,fetch.label.atleast1Member);
			return false;
		}
		var view=me.getCreateView();
		view.down('assign-team-grid').setVisible(true);
		//view.down('assign-team-grid').down('#removeTeam').setVisible(false);
		var store=Ext.getStore('AvailableUserStore');	
		var teamStore=Ext.getStore('AssignTeamStore');
		/*var approverCount=0;
		var assignCount=0;
		for(i=0;i<store.getCount();i++){
			var rec=store.getAt(i);
			if(rec.data.approver){
				approverCount++;
				if(!grid.getSelectionModel().isSelected(rec))
				{
					Ext.Msg.alert(fetch.label.error,fetch.label.only1Member);
					return false;
				}
			}
		}
		for(i=0;i<teamStore.getCount();i++){
			var rec=teamStore.getAt(i);
			if(rec.data.approver){
				assignCount++;
			}
		}
		
		if(approverCount<1 && assignCount<1)
		{
			Ext.Msg.alert(fetch.label.error,fetch.label.approverCountSmallerThn1);
			return false;
		}
		else if(approverCount>1 && assignCount>1)
		{
			Ext.Msg.alert(fetch.label.error,fetch.label.approverCountGreaterThn1);
			return false;
		}*/
		var userList=[];var index=-1;
		Ext.getStore('AvailableUserStore').each(function(rec,index){
			if(grid.getSelectionModel().isSelected(rec)){
				rec.data.assigned=true;
				 index=teamStore.findExact('userId',rec.data.userId);
				if(index==-1){
					teamStore.add(rec);
				}
				
			}
			else{		
			
			}
		});
		//form.getForm().findField('teamSaved').setValue(false);
		teamSaved='false';
		view.down('assign-team-grid').getView().refresh();
		btn.up('window').close();
		//userList=JSON.parse(JSON.stringify(userList));
		
		
		
	},
	onQueryPurchaseCategory:function(){
		var me=this;
		console.log("inside query PC");
		var form = me.getPurchaseCategoryQueryForm();
		form.getForm().reset();
		var grid = me.getQuerySearchResultGrid();
		grid.setVisible(false);
		Ext.getCmp('index').getLayout().setActiveItem('homePage');	
		Ext.getCmp('adminhome').getLayout().setActiveItem('query-purchase-category');
	},
	onQueryAction:function(){
		var me=this;
		console.log("inside query action");
		var form = me.getQueryActionForm();
		form.getForm().reset();
		var grid = me.getQuerySearchActionResultGrid();
		grid.setVisible(false);
		Ext.getCmp('index').getLayout().setActiveItem('homePage');	
		Ext.getCmp('adminhome').getLayout().setActiveItem('query-action');
		
	},
	onQueryData:function(){
		var me=this;
		console.log("inside query action");
		var form = me.getQueryDataForm();
		form.getForm().reset();
		var grid = me.getQuerySearchDataResultGrid();
		grid.setVisible(false);
		Ext.getCmp('index').getLayout().setActiveItem('homePage');	
		Ext.getCmp('adminhome').getLayout().setActiveItem('query-data');
		
	},
	onQueryRole:function(){
		var me=this;
		console.log("inside query role");
		var form = me.getQueryRoleForm();
		
		form.getForm().reset();
		var grid = me.getQuerySearchRoleResultGrid();
		grid.setVisible(false);
		Ext.getCmp('index').getLayout().setActiveItem('homePage');	
		Ext.getCmp('adminhome').getLayout().setActiveItem('query-role');
	},
	onSearchQueryPurchaseCategory: function(){
		console.log("inside search query PC");
		var me = this;
		var form = me.getPurchaseCategoryQueryForm();
		AdminConsole.MyUtil.showMask(form,fetch.label.fetching);
		//var createView = me.getCreatePurchaseCategory();
		var formValues = form.getForm().getValues();
		console.log('formValues',formValues);
		var grid = me.getQuerySearchResultGrid();
		grid.setVisible(true);
		Ext.getStore('QueryPurchaseCategoryStore').removeAll();
		dataQueryPC={
		code:formValues.code,
		name:formValues.name,
		unspsc:formValues.unspsc,
		status:(formValues.status)?(true):(false),
		};
		var url;		
		var store=Ext.getStore('QueryPurchaseCategoryStore');
		store.currentPage =1;
		store.load({
			    params:{
				data:Ext.JSON.encodeValue(dataQueryPC)
				}
		});
	},
	onSearchQueryAction: function(){
		console.log("inside search query action");
		var me = this;
		var form = me.getQueryActionForm();
		AdminConsole.MyUtil.showMask(form,fetch.label.fetching);
		var formValues = form.getForm().getValues();
		console.log('formValues',formValues);
		var grid = me.getQuerySearchActionResultGrid();
		grid.setVisible(true);
		Ext.getStore('QueryActionStore').removeAll();
		dataQueryAction={
		screenCode:formValues.code,
		screenName:formValues.name,
		actionRole:null
		};
		var url;		
		var store=Ext.getStore('QueryActionStore');
		store.currentPage =1;
		store.load({
			    params:{
				data:Ext.JSON.encodeValue(dataQueryAction)
				}
		});
	},
	onSearchQueryRole: function(){
		console.log("inside search query PC");
		var me = this;
		var form = me.getQueryRoleForm();
		AdminConsole.MyUtil.showMask(form,fetch.label.fetching);
		//var createView = me.getCreatePurchaseCategory();
		var formValues = form.getForm().getValues();
		console.log('formValues',formValues);
		var grid = me.getQuerySearchRoleResultGrid();
		grid.setVisible(true);
		Ext.getStore('QueryRoleStore').removeAll();
		dataQueryRole={
		name : formValues.name,
		description:formValues.description,
		id :null,
		orgId:null,
		active:true
		};
		var url;		
		var store=Ext.getStore('QueryRoleStore');
		store.currentPage =1;
		store.load({
			    params:{
				data:Ext.JSON.encodeValue(dataQueryRole)
				}
		});
	},
	onSearchQueryData: function(){
		console.log("inside search data");
		var me = this;
		var form = me.getQueryDataForm();
		AdminConsole.MyUtil.showMask(form,fetch.label.fetching);
		//var createView = me.getCreatePurchaseCategory();
		var formValues = form.getForm().getValues();
		console.log('formValues',formValues);
		var grid = me.getQuerySearchDataResultGrid();
		grid.setVisible(true);
		Ext.getStore('QueryDataStore').removeAll();
		dataQuery={
		privacyCode : formValues.code,
		privacyText:null,
		//dataPrivacyId :0
		
		};
		var url;		
		var store=Ext.getStore('QueryDataStore');
		store.currentPage =1;
		store.load({
			    params:{
				data:Ext.JSON.encodeValue(dataQuery)
				}
		});
	},
	onPurchaseCategorySearchListItemClick:function(me, record, item, index, e, eOpts)
	{
		console.log('Inside onPurchaseCategorySearchListItemClick');
		console.log(record);
		var controllerRef=this;	
		var dataQuerySearchPC = {
			purchaseCatId : record.get('purCatId'),
			code :record.get('code'),
			name :record.get('name'),
			description:record.get('description'),
			status:record.get('status'),
		};
		var url;	
		AdminConsole.MyUtil.showMask(me,fetch.label.fetching);
		//url = 'detailResponse.json';
		url = AdminConsole.Constants.baseURL + '/oem/loadPurchaseCategoryDetail.htm';
		Ext.Ajax.request({
			url : url,
			method : 'POST',
			timeout:180000,
			params : Ext.JSON.encode(dataQuerySearchPC),
			headers :
			{
				'Content-Type' : 'application/json',
			},
			success : function(response) {
				console.log(response.responseText);
				AdminConsole.MyUtil.hideMask();
				var decodedData=Ext.JSON.decode(response.responseText);
				var detailPanel = Ext.create('AdminConsole.view.PurchaseCategory',{
							width:700,
							height:580
							
				});
				pcId=decodedData.purchaseCatId;
				detailPanel.down('assign-unspsc-grid').setVisible(true);
				detailPanel.down('assign-team-grid').setVisible(true);				
				console.log(detailPanel.down('assign-unspsc-grid').down('#removeUnspsc'));//.setVisible(false);
				detailPanel.down('assign-team-grid').down('#removeTeam').setVisible(false);			
				detailPanel.down('assign-team-grid').down('#approver').setVisible(false);
				detailPanel.down('#editButtonContainer').setVisible(true);
				detailPanel.down('form').down('#createButtonContainer').setVisible(false);
				detailPanel.down('form').getForm().findField('code').setReadOnly(true);
				detailPanel.down('form').getForm().findField('name').setReadOnly(true);
				detailPanel.down('form').getForm().findField('description').setReadOnly(true);		
				if(decodedData.unspscList)
				detailPanel.down('assign-unspsc-grid').getStore().loadData(decodedData.unspscList);
				if(decodedData.teamList)
				detailPanel.down('assign-team-grid').getStore().loadData(decodedData.teamList);
				detailPanel.down('form').getForm().findField('purchaseCatId').setValue(decodedData.purchaseCatId);
				pcId=decodedData.purchaseCatId;
				detailPanel.down('form').getForm().findField('status').setValue(decodedData.statusCode);
				detailPanel.down('form').getForm().findField('code').setValue(decodedData.code);
				console.log(detailPanel.down('form').getForm().findField('code').getValue(),decodedData.code);
				detailPanel.down('form').getForm().findField('name').setValue(decodedData.name);
				detailPanel.down('form').getForm().findField('description').setValue(decodedData.description);
				teamSaved='true';
				status=decodedData.statusCode;
				var popup=controllerRef.createPopUp(true);
				popup.on('beforeremove',function(){
				console.log('inside close');
				Ext.getStore('QueryPurchaseCategoryStore').reload();
				},this);
				popup.add(detailPanel);
				popup.show();
				},
			failure : function(response) {
				alert(fetch.label.communicationMsg);
				AdminConsole.MyUtil.hideMask();
				
			}
		});
	},
	onActionSearchListItemClick:function(me, record, item, index, e, eOpts)
	{
		var controllerRef=this;	
		var detailPanel = Ext.create('AdminConsole.view.CreateAction',{
			//id:'queryActionView',
			width:600,
			height:180					
		});
		detailPanel.down('form').getForm().findField('code').setValue(record.data.screenCode);
		detailPanel.down('form').getForm().findField('name').setValue(record.data.screenName);
		detailPanel.down('form').getForm().findField('code').setReadOnly(true);
		detailPanel.down('button[action="deleteAction"]').setDisabled(false);
		var popup=controllerRef.createPopUp(true);
		popup.on('beforeremove',function(){
		Ext.getStore('QueryActionStore').reload();
		},this);
		popup.add(detailPanel);
		popup.show();
	},
	onRoleSearchListItemClick:function(me, record, item, index, e, eOpts)
	{
		var me=this;		
		var detailPanel = Ext.create('AdminConsole.view.CreateRole',{
			//id:'queryRoleView',
			width:600,
			height:180	
		});
		detailPanel.down('form').setTitle(fetch.label.updateRole);
		detailPanel.down('form').getForm().findField('description').setValue(record.data.description);
		detailPanel.down('form').getForm().findField('name').setValue(record.data.name);
		detailPanel.down('form').getForm().findField('roleId').setValue(record.data.id);
		detailPanel.down('form').getForm().findField('cpRoleId').setValue(record.data.cpRoleId);
		//detailPanel.down('button[action="deleteRole"]').setDisabled(false);
		if(record.data.cpRoleId!=-1){
		detailPanel.down('button[action="assignService"]').setDisabled(false);
		}
		var popup=me.createPopUp(true);
		popup.on('beforeremove',function(){
		Ext.getStore('QueryRoleStore').reload();
		},this);
		popup.add(detailPanel);
		popup.show();		
	},
	onDataSearchListItemClick:function(me, record, item, index, e, eOpts)
	{
		var controllerRef=this;		
		var detailPanel = Ext.create('AdminConsole.view.CreateData',{
			itemId:'editDataForm',
			width:600,
			height:200	
		});
		detailPanel.down('form').getForm().findField('code').setValue(record.data.privacyCode);
		detailPanel.down('form').getForm().findField('htmlEditorHiddenField').setValue(record.data.privacyText);
		detailPanel.down('form').getForm().findField('id').setValue(record.data.dataPrivacyId);
		detailPanel.down('button[action="deleteData"]').setDisabled(false);
		var popup=controllerRef.createPopUp(true);
		popup.on('beforeremove',function(){
		Ext.getStore('QueryDataStore').reload();
		},this);
		popup.add(detailPanel);
		popup.show();		
	},
	onEditPurchaseCategory:function(me){
	var newme = this;	
		AdminConsole.MyUtil.checkAuthorisationOnButton(AdminConsole.Constants.UPDATE_PURCHASING_CATEGORIES,function(authorised){
					if(authorised){
					newme.onEditPurchaseCategoryImpl(me);					
				}
			}
		)
	},
	onEditPurchaseCategoryImpl:function(me){
		console.log('Inside Edit purchase',me);
		me.up('#editButtonContainer').setVisible(false);
		me.up('panel').down('#createButtonContainer').setVisible(true);
		me.up('panel').down('#createButtonContainer').down('button[action="assignTeamButton"]').setDisabled(false);
		me.up('panel').down('#createButtonContainer').down('button[action="assignUnspscButton"]').setDisabled(false);
		//me.up('panel').down('#createButtonContainer').down('button[action="releaseButton"]').setDisabled(false);
		me.up('panel').down('form').getForm().findField('name').setReadOnly(false);
		me.up('panel').down('form').getForm().findField('description').setReadOnly(false);		
		me.up('panel').down('assign-team-grid').down('#removeTeam').setVisible(true);
		me.up('panel').down('assign-unspsc-grid').down('#removeUnspsc').setVisible(true);
		me.up('panel').down('assign-team-grid').down('#approver').setVisible(true);
		
	},
	onSubmitUnspsc:function(me){
			console.log('***********Inside submit **************');	
			
			var mainForm = me.up('form');
			var list = mainForm.down('#finalSelect').boundList;
			var form = this.getCreatePurchaseCategoryForm();
			var view = this.getCreatePurchaseCategory();
			view.down('assign-unspsc-grid').setVisible(true);
			//view.down('assign-unspsc-grid').down('#removeUnspsc').setVisible(false);
			var store=view.down('assign-unspsc-grid').getStore();
			var formValues = form.getForm().getValues();
			var records = list.getRecords(list.getNodes());
			console.log(records);
			if(records==null || records.length <= 0){
				Ext.Msg.alert(fetch.label.error,fetch.label.emptyUnspsc);
				return false;
			}					
			var prodCategories = [];
			
			for(i=0;i<records.length;i++){
			desc=(records[i].data.description).split('-');
				prodCategories.push({
					code:records[i].data.productNo	,
					description:records[i].data.description
					//code:(desc[0]).trim(),
					//description:(desc[1]).trim()
				});
			
				//store.add({code:desc[0],description:desc[1]});
			}
			//prodCategories=JSON.parse(JSON.stringify(prodCategories));
			var data={
			purchaseCatId:parseInt(pcId),
			code: formValues.code,
			name: formValues.name,
			description: formValues.description,
			unspscList:prodCategories,
			teamList:null,
			status:status
			};
			console.log(Ext.JSON.encode(data));
			AdminConsole.MyUtil.showMask(me.up('window'),fetch.label.saving);
			url = AdminConsole.Constants.baseURL + '/oem/assignUNSPSCToPurchaseCategory.htm';
			Ext.Ajax.request({
				headers : {'Content-Type':'application/json','Accept':'application/json'},
				//url:'jsonResponse.json',
				url:url,
				params: Ext.JSON.encode(data),
				async : true,
				timeout : 3600*1000,//1 hr
				success: function(resp) {
					if(resp.responseText=="success"){
						Ext.Msg.alert(fetch.label.success, fetch.label.savedUnspscMsg,function(btn){
						  if(btn=='ok'){
							// form.getForm().reset();
							for(i=0;i<records.length;i++){
								desc=(records[i].data.description).split('-');
								store.add({code:desc[0],description:desc[1]});
								}
							
							view.down('assign-unspsc-grid').getView().refresh();
							AdminConsole.MyUtil.hideMask();
							AdminConsole.MyUtil.hidePopUp();
						
					  
					  }
					});
							
						
					}	
					else{
						AdminConsole.MyUtil.hideMask();
						Ext.Msg.alert(fetch.label.error,fetch.label.errorMsgUnspsc1+' '+resp.responseText+' '+fetch.label.errorMsgUnspsc2);
					}
					
				},
				failure: function(form, action) {
					alert ('communcation failed.');
				}
			});
	},
	createPopUp:function(constrainFlag){
		var window=Ext.create("Ext.Window",{		  
				style:{					
					'font-size':13, 
					'font-family':'Verdana, Geneva, sans-serif', 
					'color':'#000000', 				
					'box-shadow': '0 0 20px rgba(0, 0, 0, 0.3)'
				},				
	
			    closable : true,
			    modal : true,
				autoScroll:true,
				constrain:constrainFlag,				
				layout:{					
					type : 'vbox',
					align : 'center'
				},
			    listeners:{
			    	beforeclose: function( win, eOpts ){
						
						console.log('inside before close');
						win.removeAll(true);
						win.hide();
						return false;
			    	}
				}
		});
		return window;
	},
	onCreateCancel:function(btn){
	//var form = this.getCreatePurchaseCategoryForm();
	//form.getForm().reset();
	var window=btn.up('window');
	if(window)
		window.close();
	else
		Ext.getCmp('adminhome').getLayout().setActiveItem(0);
	},
	onAssignTeamCancel:function(btn){
	btn.up('window').close();
	},
	onassignUnspsc:function(btn){
	var newme = this;	
		AdminConsole.MyUtil.checkAuthorisationOnButton(AdminConsole.Constants.ASSIGNING_UNSPSC_CODES_TO_PURCHASING_CATEGORIES,function(authorised){
					if(authorised){
					newme.onassignUnspscImpl(btn);					
				}
			}
		)
	},
	onassignUnspscImpl:function(btn){
		console.log("inside Assign Unspsc");
		var me = this;		
		var form=btn.up('form');
		var formValues = form.getForm().getValues();
		console.log(formValues);
		if(formValues.status==AdminConsole.Constants.STATUS_RELEASED_CODE)
			Ext.Msg.confirm(fetch.label.warning,fetch.label.chkMsgForPublishedPC,function(button){
				if (button=='Yes'||button=='yes'){
				 me.showUnspscList(formValues);	
				}
			});
		else
			 me.showUnspscList(formValues);
		
		
	},
	showUnspscList:function(formValues){
		
		Ext.Ajax.request({
		  //url : 'resources/data/User.json',
			url: AdminConsole.Constants.baseURL+'/oem/loadClassificationConfig.htm',
			method : 'POST',
			timeout:180000,
			//params : Ext.JSON.encode(dataSaveAddUser),
			headers :
			{
				'Content-Type' : 'application/json',
			},
			success : function(response) {
				
					console.log(response.responseText);
					var decodedData=Ext.JSON.decode(response.responseText);
					if(decodedData ){
					console.log(decodedData.levels);
					var detailPanel = Ext.create('AdminConsole.view.AssignUNSPSCView',{
							width:1000,
							height:500,	
							
							
					});
					console.log(detailPanel);
					 detailPanel.down('#prodCatSelector').prodLevel=decodedData.levels?decodedData.levels:1;
					/*detailPanel.down('#prodCatSelector').down('#segmentSelect').setFieldLabel('<p style="padding:0px;background:#0066a1;margin:0px;color:#ffffff">'+decodedData.label1Text+'</p>');
					detailPanel.down('#prodCatSelector').down('#familySelect').setFieldLabel('<p style="padding:0px;background:#0066a1;margin:0px;color:#ffffff">'+decodedData.label2Text+'</p>');
					detailPanel.down('#prodCatSelector').down('#classSelect').setFieldLabel('<p style="padding:5px;background:#0066a1;margin-bottom:0px;color:#ffffff">'+decodedData.label3Text+'</p>');
					detailPanel.down('#prodCatSelector').down('#commoditySelect').setFieldLabel('<p style="padding:5px;background:#0066a1;margin-bottom:0px;color:#ffffff">'+decodedData.label4Text+'</p>');
					console.log('title-->',detailPanel.down('#prodCatSelector').down('#segmentSelect')); */
					//detailPanel.doLayout(); 
					//detailPanel.refresh();
					detailPanel.down('#prodCatSelector').down('#title1').setTitle(decodedData.label1Text);
					detailPanel.down('#prodCatSelector').down('#title2').setTitle(decodedData.label2Text);
					detailPanel.down('#prodCatSelector').down('#title3').setTitle(decodedData.label3Text);
					detailPanel.down('#prodCatSelector').down('#title4').setTitle(decodedData.label4Text);
					detailPanel.on({
						added:function(me){
							console.log('***********Inside Assign UNSPSc*******');									
						
							console.log("activate : "+me.itemId);
							console.log(me.down('#segmentSelect'));
							
							me.down('#segmentSelect').getStore().load({params:{purchaseCatId:formValues.purchaseCatId}});
														
						}
					});			
					AdminConsole.MyUtil.showPopUp(detailPanel);
					
				}
					
			},
			failure : function(response) {
				Ext.Msg.alert(fetch.label.communicationMsg);
				AdminConsole.MyUtil.hideMask();	
			}
			
		});	
		
	},
	onReleasePurchaseCategory:function(me){
	var newme = this;	
		AdminConsole.MyUtil.checkAuthorisationOnButton(AdminConsole.Constants.PUBLISH_PURCHASE_CATEGORY,function(authorised){
					if(authorised){
					newme.onReleasePurchaseCategoryImpl(me);					
				}
			}
		)
	},
	onReleasePurchaseCategoryImpl: function(me){
	console.log('Inside Release PC');
	var form=me.up('form');
	var formValues = form.getForm().getValues();
	var data={
			purchaseCatId:parseInt(formValues.purchaseCatId),
			code: formValues.code,
			name: formValues.name,
			description: formValues.description,
			unspscList:null,
			teamList:null,
			//status:formValues.status,
			statusCode:formValues.publish?AdminConsole.Constants.STATUS_RELEASED_CODE:AdminConsole.Constants.STATUS_IN_PROCESS_CODE,
	};
	console.log(Ext.JSON.encode(data));
	url = AdminConsole.Constants.baseURL + '/oem/releasePurchaseCategory.htm';
	AdminConsole.MyUtil.showMask(form,fetch.label.saving);
	Ext.Ajax.request({
			headers : {'Content-Type':'application/json','Accept':'application/json'},
			//url:'jsonResponse.json',
			url:url,
			params: Ext.JSON.encode(data),
			async : true,
			timeout : 3600*1000,//1 hr
			success: function(response) {
				console.log('On Release Response',response.responseText);
				var decodedData=Ext.JSON.decode(response.responseText);
				form.getForm().findField('status').setValue(decodedData.statusCode);
				status=decodedData.statusCode;
				Ext.Msg.alert(fetch.label.success,fetch.label.releasePurchaseCategory);
				AdminConsole.MyUtil.hideMask();
			},
			failure: function(form, action) {
				alert ('communcation failed.');
				AdminConsole.MyUtil.hideMask();
			}
		});
	},
	createUploadUNSPSC:function(me){
	var newme = this;	
		AdminConsole.MyUtil.checkAuthorisationOnButton(AdminConsole.Constants.UPLOAD_UNSPSC_PRODUCT_CLASSIFICATION,function(authorised){
					if(authorised){
					newme.createUploadUNSPSCImpl(me);					
				}
			}
		)
	},
	createUploadUNSPSCImpl:function(){
		console.log(' inside uploadUNSPSC');
		Ext.Ajax.request({
				url: AdminConsole.Constants.baseURL+'/oem/loadClassificationConfig.htm',
				method : 'POST',
				timeout:180000,
				//params : {"classConfId":form.findField('classConfId').getValue()},
				headers :
				{
					'Content-Type' : 'application/json',
				},
			    success : function(response) {
				
					var decodedData=Ext.JSON.decode(response.responseText);
					if(decodedData.classConfId!=null){
						Ext.getCmp('index').getLayout().setActiveItem('homePage');		
						Ext.getCmp('adminhome').getLayout().setActiveItem('uploadUNSPSC');
					}
					else{
						Ext.getCmp('index').getLayout().setActiveItem('homePage');		
						Ext.getCmp('adminhome').getLayout().setActiveItem('clsConfig');
						Ext.Msg.alert(fetch.label.warning,fetch.label.uploadConfigMsg);
						
					}
					
					
					},
					failure : function(response) {
						Ext.Msg.alert(fetch.label.communicationMsg);
						AdminConsole.MyUtil.hideMask();	
					}
			
			   
			   });
		
		
	},
	onDeleteRole:function(btn){
	console.log(' inside onDeleteRole');
	var form=btn.up('form');
	var formValues = form.getForm().getValues();
	Ext.Msg.confirm(fetch.label.warning,fetch.label.removeRoleMsg,function(button){
	console.log('choice',button);
		if(button=='yes'||button=='Yes'){
		
		console.log('delete record');
		var removeData = {
							name : null,
							description:null,
							id :formValues.roleId,
							orgId:null,
							active:true
						};
				console.log('remove',removeData);
				AdminConsole.MyUtil.showMask(form,fetch.label.removing);
				Ext.Ajax.request({
					headers : {'Content-Type':'application/json'},
					//url:'jsonResponse.json',
					url : AdminConsole.Constants.baseURL + '/oem/removeRole.htm',
					params: Ext.JSON.encode(removeData),
					async : true,
					timeout : 3600*1000,//1 hr
					success: function(resp) {
							if(resp.responseText=='SUCCESS'){
								Ext.Msg.alert(fetch.label.success, fetch.label.removeRoleSuccessMsg);
								AdminConsole.MyUtil.hideMask();
								form.getForm().reset();
								if(btn.up('window'))
								btn.up('window').close();
								Ext.getStore('QueryActionStore').reload();
							}
							else{
								Ext.Msg.alert(fetch.label.error,fetch.label.removeRoleFailMsg);
								AdminConsole.MyUtil.hideMask();
								btn.up('window').close();
							}
							

					},
					failure: function(form, action) {
						alert ('communcation failed.');
						AdminConsole.MyUtil.hideMask();
					}
				});
		
		}
	});
	},
	
	onDeleteAction:function(btn){
	console.log(' inside onDeleteAction');
	var form=btn.up('form');
	var formValues = form.getForm().getValues();
	Ext.Msg.confirm(fetch.label.warning,fetch.label.removeActionMsg,function(button){
	console.log('choice',button);
		if(button=='yes'||button=='Yes'){
		
		console.log('delete record');
				var removeData = {
					screenCode : formValues.code,
					screenName : formValues.name,
					actionRole : null
				};
				console.log('remove',removeData);
				AdminConsole.MyUtil.showMask(form,fetch.label.removing);
				Ext.Ajax.request({
					headers : {'Content-Type':'application/json'},
					//url:'jsonResponse.json',
					url : AdminConsole.Constants.baseURL + '/oem/removeAction.htm',
					params: Ext.JSON.encode(removeData),
					async : true,
					timeout : 3600*1000,//1 hr
					success: function(resp) {
							if(resp.responseText=='SUCCESS'){
								Ext.Msg.alert(fetch.label.success, fetch.label.removeActionSuccessMsg);
								AdminConsole.MyUtil.hideMask();
								form.getForm().reset();
								if(btn.up('window'))
								btn.up('window').close();
								Ext.getStore('QueryActionStore').reload();
								
						}
						else{
							Ext.Msg.alert(fetch.label.error,fetch.label.removeActionFailMsg); 
							AdminConsole.MyUtil.hideMask();
						}
							

					},
					failure: function(form, action) {
						alert ('communcation failed.');
						AdminConsole.MyUtil.hideMask();
					}
				});
		
		}
	});
	},
	onDeleteData:function(btn){
	console.log(' inside onDeleteData');
	var form=btn.up('form');
	var formValues = form.getForm().getValues();
	Ext.Msg.confirm(fetch.label.warning,fetch.label.removeDataMsg,function(button){
	console.log('choice',button);
		if(button=='yes'||button=='Yes'){
		
		console.log('delete record');
				var removeData = {
					privacyText : formValues.htmlEditorHiddenField,
					privacyCode : formValues.code,
					dataPrivacyId : formValues.id
				};
				console.log('remove',removeData);
				AdminConsole.MyUtil.showMask(form,fetch.label.removing);
				Ext.Ajax.request({
					headers : {'Content-Type':'application/json'},
					//url:'jsonResponse.json',
					url : AdminConsole.Constants.baseURL + '/oem/removeData.htm',
					params: Ext.JSON.encode(removeData),
					async : true,
					timeout : 3600*1000,//1 hr
					success: function(resp) {
							if(resp.responseText=='SUCCESS'){
								Ext.Msg.alert(fetch.label.success, fetch.label.removeDataSuccessMsg);
								AdminConsole.MyUtil.hideMask();
								form.getForm().reset();
								if(btn.up('window'))
								btn.up('window').close();
								Ext.getStore('QueryDataStore').reload();
						}
						else{
							Ext.Msg.alert(fetch.label.error,fetch.label.removeDataFailMsg); 
							AdminConsole.MyUtil.hideMask();
						}
							

					},
					failure: function(form, action) {
						alert ('communcation failed.');
						AdminConsole.MyUtil.hideMask();
					}
				});
		
		}
	});
	},
	openHtmlEditor : function(btn){
			var htmlEditorWin = Ext.create('Ext.Window',{
				title : fetch.label.emailText,
				itemId:'htmlEditorWin',
				width : '60%',
				height : 280,
				modal : true,
				resizable : true,
				//layout : 'fit',
				autoScroll:false,
				listeners:{
						beforeclose: function( htmlEditorWin, eOpts ){
							htmlEditorWin.removeAll(true);
							htmlEditorWin.hide();
							return false;
						}
					}			
			});
			var htmlEditorPan = Ext.create('Ext.form.Panel',{
				itemId : 'htmlEditorPan',
				//bodyPadding : 10,
				autoScroll : true,
				
				items : [
						{
							xtype : 'htmlEditor',
							
						}					
					]
				
			});		
			htmlEditorWin.add(htmlEditorPan);
			var form = btn.up('form');
			var emailText = form.getForm().findField('htmlEditorHiddenField').getValue();
			var formvalues = form.getForm().getValues();
			console.log(form.getForm().getValues());
			console.log(emailText);
			htmlEditorPan.down('#htmlEditorField').setValue(emailText);
			
			//editorValue.setValue(form.getForm().findField('htmlEditorField').value);		
			htmlEditorWin.show();		
	
	
		},
		htmlEditorSubmit  : function(btn){
		var me = this;
		var htmlEditorFieldValue = btn.up('#htmlEditorPan').getForm().getValues().htmlEditorField;
		var htmlEditorHiddenField;
		var url=window.location.hash;
		if(url=="#createData")
		htmlEditorHiddenField =  me.getCreateDataForm().down('#htmlEditorHiddenField');
		else if(url=="#queryData")
		htmlEditorHiddenField =  me.getEditDataForm().down('#htmlEditorHiddenField');		
		htmlEditorHiddenField.setValue(htmlEditorFieldValue);		
		console.log(htmlEditorHiddenField.getValue());
		btn.up('#htmlEditorWin').close();
		
	},
		onAssignService:function(btn){
		console.log('Inside onAssignService');
		Ext.Ajax.request({
					headers : {'Content-Type':'application/json'},
					//url:'jsonResponse.json',
					url : AdminConsole.Constants.baseURL + '/oem/serviceForRole.htm?cpRoleId='+btn.up('#create-role').down('#createRoleForm').getForm().findField('cpRoleId').getValue(),
					//url:'resources/data/services.json',
					
					params: {
						cpRoleId:btn.up('#create-role').down('#createRoleForm').getForm().findField('cpRoleId').getValue(),
						//tenantKey:Ext.util.Cookies.get("tenant"),
					},
					async : true,
					timeout : 3600*1000,//1 hr
					success: function(resp) {
						var decodedData=Ext.JSON.decode(resp.responseText);
						Ext.getStore('AvailbleServiceStore').loadData(decodedData.availableServices);
						Ext.getStore('AssignedServiceStore').loadData(decodedData.assignServices);
						
						var win = Ext.create('Ext.Window',{
							title : fetch.label.services,
							width : 950,
							modal : true,
							layout : 'fit',
						
						});
		
						var searchServicesPanel = Ext.create('AdminConsole.view.SearchServices');
						searchServicesPanel.cpRoleId=btn.up('#create-role').down('#createRoleForm').getForm().findField('cpRoleId').getValue();
						win.add(searchServicesPanel);
						win.show();	
					},
					failure: function(form, action) {
						alert ('communcation failed.');
						//AdminConsole.MyUtil.hideMask();
					}
				});
		
				
	},
	onAssigningService:function(btn){
		console.log('Inside onSelectAvaibleService ');
		var selectedService = btn.up('#searchServices').down('#availableService').getSelectionModel().getSelection();
		var serviceId=[];
		//var data=null;		
		if(null == selectedService || "" == selectedService)										
			Ext.Msg.alert(fetch.label.warning,fetch.label.selOneRecMsg);
		
		selectedService.forEach(function(record,index){
			serviceId.push(record.data.id);
		});
		var data= {
						roleId:btn.up('#searchServices').cpRoleId,
						avServices:serviceId,
						action:'assign'
					};

		Ext.Ajax.request({
					headers : {'Content-Type':'application/json'},
					//url:'jsonResponse.json',
					url : AdminConsole.Constants.baseURL + '/oem/assignServicesToRole.htm',
					//url:'resources/data/services2.json',
					
					
					params:Ext.JSON.encode(data),
					async : true,
					timeout : 3600*1000,//1 hr
					success: function(resp) {
						var decodedData=Ext.JSON.decode(resp.responseText);
						Ext.getStore('AvailbleServiceStore').loadData(decodedData.availableServices);
						Ext.getStore('AssignedServiceStore').loadData(decodedData.assignServices);
						
					},
					failure: function(form, action) {
						alert ('communcation failed.');
						//AdminConsole.MyUtil.hideMask();
					}
				});
	
	},
	onDeassigningService:function(btn){
	console.log('Inside onSelectAssignedService ');
	
		var selectedService = btn.up('#searchServices').down('#assignedService').getSelectionModel().getSelection();
		var serviceId=[];	
		
		if(null == selectedService || "" == selectedService)										
			Ext.Msg.alert(fetch.label.warning,fetch.label.selOneRecMsg);
		
		selectedService.forEach(function(record,index){
			console.log(index,record);
			serviceId.push(record.data.id);
		});
		var data= {
						roleId:btn.up('#searchServices').cpRoleId,
						asServices:serviceId,
						action:'deassign'
					};

		Ext.Ajax.request({
					headers : {'Content-Type':'application/json'},
					//url:'jsonResponse.json',
					url : AdminConsole.Constants.baseURL + '/oem/assignServicesToRole.htm',
					//url:'resources/data/services.json',
					
					
					params:Ext.JSON.encode(data),
					async : true,
					timeout : 3600*1000,//1 hr
					success: function(resp) {
						var decodedData=Ext.JSON.decode(resp.responseText);
						Ext.getStore('AvailbleServiceStore').loadData(decodedData.availableServices);
						Ext.getStore('AssignedServiceStore').loadData(decodedData.assignServices);
							
					},
					failure: function(form, action) {
						alert ('communcation failed.');
						//AdminConsole.MyUtil.hideMask();
					}
				});
	
	},
	
	
	
});
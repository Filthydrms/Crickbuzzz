Ext.define('AdminConsole.controller.BackendSystemController', {
    extend: 'Ext.app.Controller',
	views : ['backendSystem.FetchBackendSystemData','backendSystem.CommodityLogGrid','backendSystem.FetchBackendSystemDataLog',
				'backendSystem.StatusLogGrid','backendSystem.RoleLogGrid'],
	stores : [],
	models:['CommodityLogModel','StatusLogModel','RoleLogModel'],
	
	init : function() {
		console.log('inside ConnectionProfileController controller');
			
		this.control({
			 'button[action="fetchBackendSystemData"]' : {
				click : this.fetchDataFromBackendSystem
			},
			'button[action="downloadBackendSysDataLog"]' : {
				click : this.downloadBackendSysDataLog
			}
			
		})
	},
	
	fetchDataFromTeamcenterPanel :function(){
		console.log('fetchDataFromTeamcenterPanel method of BackendSystemController : Start');
		Ext.Ajax.request({
			url : AdminConsole.Constants.baseURL + '/oem/getTCConnectionProfile.htm',
			method : 'GET',
			timeout:180000,
			//params : Ext.JSON.encode(data),
			headers :
			{
				'Content-Type' : 'application/json',
			},
			success : function(response) {
					console.log(response.responseText);
					var decodedData=Ext.JSON.decode(response.responseText);
					console.log(decodedData);
					if(decodedData.withoutClassification){
						Ext.getCmp('adminhome').down('fetchBackendSystemData').down('#fetchBackendSystemDataBtn').setDisabled(true);
					}
					else{
						Ext.getCmp('adminhome').down('fetchBackendSystemData').down('#fetchBackendSystemDataBtn').setDisabled(false);
					}
					Ext.getCmp('index').getLayout().setActiveItem('homePage');		
					Ext.getCmp('adminhome').getLayout().setActiveItem('fetchBackendSystemData');
					
					
			},
			failure : function(response) {
				Ext.Msg.alert(fetch.label.serverCommunicationFailureMessage);
				//AdminConsole.MyUtil.hideMask();	
			}
		});
		
		
		console.log('fetchDataFromTeamcenterPanel method of BackendSystemController : End');	
	},
	
	
	fetchDataFromBackendSystem :function(){
		console.log('fetchDataFromBackendSystem method of BackendSystemController : Start');
		
		var me = this;
		Ext.getBody().mask(fetch.label.fetchDataFromBackendSystemMsg);
		
		Ext.Ajax.request({
				url : AdminConsole.Constants.baseURL + '/oem/loadTcData.htm',
				//url:'resources/data/RoleContactTCStatus.json',
				method : 'POST',
				isSynchronous:true,
				//params : Ext.JSON.encode(connectionProfileFormData),
				headers : {'Content-Type':'application/json','Accept':'application/json'},
				timeout:1136000,
				success : function(response) {
					Ext.getBody().unmask();
					var fetchBackendSystemDataLog=Ext.JSON.decode(response.responseText);
					console.log('Response for testTeamCenterConnectionProfile rest call is');
					console.log(fetchBackendSystemDataLog);
					
					var responseStatus = AdminConsole.MyUtil.backendSystemResponseDecodeAction(fetchBackendSystemDataLog.errorCode);
					console.log(responseStatus);
					if('undefined' != responseStatus && null != responseStatus){
						if(AdminConsole.Constants.STATUS_SUCCESS.toUpperCase() == responseStatus.toUpperCase()){
							me.backendSystemDataLog = fetchBackendSystemDataLog;
							me.showLogForFetchDataFromBackendSystem(fetchBackendSystemDataLog);
						}else if(AdminConsole.Constants.STATUS_FAIL.toUpperCase() == responseStatus.toUpperCase()){
							Ext.Msg.alert(fetch.label.error,fetch.label.sysError);
						}
					}					
					
				},
				failure : function(response) {
					Ext.getBody().unmask();	
					Ext.Msg.alert(fetch.label.fail,fetch.label.communicationFail);
				}
			});
		
		
		console.log('fetchDataFromBackendSystem method of BackendSystemController : End');	
	},
	
	showLogForFetchDataFromBackendSystem :function(fetchBackendSystemDataLog){
		console.log('showLogForFetchDataFromBackendSystem method of BackendSystemController : Start');
		var winHeight = (Ext.getBody().getHeight() < 650 )? Ext.getBody().getHeight() : 650  ;
		
		var detailPanel = Ext.create('AdminConsole.view.backendSystem.FetchBackendSystemDataLog',{
							width:950,
							maxHeight:winHeight
						});
		
		if(parseInt(fetchBackendSystemDataLog.commodityLogs.length) < 1 && parseInt(fetchBackendSystemDataLog.statusLogs.length) < 1 
			&& parseInt(fetchBackendSystemDataLog.roleLogs.length) < 1){
				
			console.log('No data is fecthed from the backeend system ');
			detailPanel.down('#messagePanel').hidden = false;
			detailPanel.down('#messagePanel').html=fetch.label.noDataUpdatedMsg;			
		}else{
			//detailPanel.down('#buttonContainer').down('#downloadLogBtn').hidden = false;
			detailPanel.down('#messagePanel').hidden = true;
		}
		
		var commodityLogGridPanel=detailPanel.down('#roleLogGridPanel');
		
		var commodityLogStore = detailPanel.down('#commodityLogGridPanel').getStore();		
		Ext.Array.each(fetchBackendSystemDataLog.commodityLogs, function(commodityLog, index) {
		
					commodityLogStore.add({
						code:commodityLog.code,
						description:commodityLog.description,
						action:commodityLog.action,
					})
				
				})
		
		
		var statusLogGridPanel=detailPanel.down('#statusLogGridPanel');
		
			var statusLogStore = statusLogGridPanel.getStore();		
			Ext.Array.each(fetchBackendSystemDataLog.statusLogs, function(statusLog, index) {
			
						statusLogStore.add({
							code:statusLog.code,
							description:statusLog.description,
							action:statusLog.action,
						})
					})
		
		
		var roleLogGridPanel=detailPanel.down('#roleLogGridPanel');
		
			var roleLogStore = roleLogGridPanel.getStore();		
			Ext.Array.each(fetchBackendSystemDataLog.roleLogs, function(roleLog, index) {
			
						roleLogStore.add({
							code:roleLog.code,
							description:roleLog.description,
							action:roleLog.action,
						})
					})
			
		AdminConsole.MyUtil.showPopUp(detailPanel,'');
		console.log('showLogForFetchDataFromBackendSystem method of BackendSystemController : End');
	},
	
	downloadBackendSysDataLog :function(fetchBackendSystemDataLog){
		console.log('downloadBackendSysDataLog method of BackendSystemController : Start');
		var me = this;
		
		console.log(me.backendSystemDataLog);
		
		var backendSystemDataLog = me.backendSystemDataLog;
		
		var logData="";
		var commodityLogData="";
		var ststusLogData="";
		var roleLogData="";
		
		commodityLogData = (commodityLogData.concat(fetch.label.commodityLog)).concat(AdminConsole.Constants.NEW_LINE_CHARACTER);
		
		if(parseInt(backendSystemDataLog.commodityLogs.length) < 1){
			commodityLogData = (commodityLogData.concat(fetch.label.commodityCodeFetchMsg)).concat(AdminConsole.Constants.NEW_LINE_CHARACTER);
		}else{
			Ext.Array.each(backendSystemDataLog.commodityLogs, function(commodityLog, index) {
																
					commodityLogData = (commodityLogData.concat(commodityLog.code)).concat(AdminConsole.Constants.TAB_CHARACTER);
					commodityLogData = (commodityLogData.concat(commodityLog.description)).concat(AdminConsole.Constants.TAB_CHARACTER);
					commodityLogData = (commodityLogData.concat(commodityLog.action)).concat(AdminConsole.Constants.NEW_LINE_CHARACTER);
			})
		}
		
		ststusLogData = (ststusLogData.concat(fetch.label.statusLog)).concat(AdminConsole.Constants.NEW_LINE_CHARACTER);
		
		if(parseInt(backendSystemDataLog.statusLogs.length) < 1){
			ststusLogData = (ststusLogData.concat(fetch.label.classStatusFetchMsg)).concat(AdminConsole.Constants.NEW_LINE_CHARACTER);
		}else{
			Ext.Array.each(backendSystemDataLog.statusLogs, function(statusLog, index) {																
					ststusLogData = (ststusLogData.concat(statusLog.code)).concat(AdminConsole.Constants.TAB_CHARACTER);
					ststusLogData = (ststusLogData.concat(statusLog.description)).concat(AdminConsole.Constants.TAB_CHARACTER);
					ststusLogData = (ststusLogData.concat(statusLog.action)).concat(AdminConsole.Constants.NEW_LINE_CHARACTER);
			})
		}
		
		roleLogData = (roleLogData.concat(fetch.label.roleLog)).concat(AdminConsole.Constants.NEW_LINE_CHARACTER);
		
		if(parseInt(backendSystemDataLog.roleLogs.length) < 1){
			roleLogData = (roleLogData.concat(fetch.label.contactRoleFetchMsg)).concat(AdminConsole.Constants.NEW_LINE_CHARACTER);
		}else{
			Ext.Array.each(backendSystemDataLog.roleLogs, function(roleLog, index) {																
					roleLogData = (roleLogData.concat(roleLog.code)).concat(AdminConsole.Constants.TAB_CHARACTER);
					roleLogData = (roleLogData.concat(roleLog.description)).concat(AdminConsole.Constants.TAB_CHARACTER);
					roleLogData = (roleLogData.concat(roleLog.action)).concat(AdminConsole.Constants.NEW_LINE_CHARACTER);
			})
		} 
		
		var logData = ((logData.concat(commodityLogData)).concat(ststusLogData)).concat(roleLogData);
		
		//window.open('data:text/tsv;charset=utf-8,' + escape(data));
		
		console.log(logData);
		
		console.log('downloadBackendSysDataLog method of BackendSystemController : End');
	}
	
	
	
});

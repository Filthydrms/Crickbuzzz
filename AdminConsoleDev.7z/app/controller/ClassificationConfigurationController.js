Ext.define('AdminConsole.controller.ClassificationConfigurationController', {
	extend : 'Ext.app.Controller',
			refs:[
					{
					   ref:'clsConfigForm',
					   selector:'#clsConfigForm'
					}
					
					
				],
				
			init:function(){
				
				this.control({
					
					
						'button[action=saveClsConfAction]':{
								click:this.onSaveClsConfAction
						 },
						
				});
				
			},

		onClassificationConfiguration:function(){
				var me=this;
				console.log("inside classification configuration");
				var form=me.getClsConfigForm().getForm();
				form.reset();
				Ext.getCmp('index').getLayout().setActiveItem('homePage');	
				Ext.getCmp('adminhome').getLayout().setActiveItem('clsConfig');
				
				form.findField('label1Text').allowBlank=true,
				form.findField('label1Text').setFieldLabel(fetch.label.label1Text);
				form.findField('Label1Pattern').allowBlank=true,
				form.findField('Label1Pattern').setFieldLabel(fetch.label.label1Pattern);
				form.findField('label2Text').allowBlank=true,
				form.findField('label2Text').setFieldLabel(fetch.label.label2Text);
				form.findField('Label2Pattern').allowBlank=true,
				form.findField('Label2Pattern').setFieldLabel(fetch.label.label2Pattern);
				form.findField('label3Text').allowBlank=true,
				form.findField('label3Text').setFieldLabel(fetch.label.label3Text);
				form.findField('Label3Pattern').allowBlank=true,
				form.findField('Label3Pattern').setFieldLabel(fetch.label.label3Pattern);
				form.findField('label4Text').allowBlank=true,
				form.findField('label4Text').setFieldLabel(fetch.label.label4Text);
				form.findField('Label4Pattern').allowBlank=true
				form.findField('Label4Pattern').setFieldLabel(fetch.label.label4Pattern);
				
				Ext.Ajax.request({
				url: AdminConsole.Constants.baseURL+'/oem/loadClassificationConfig.htm',
				method : 'POST',
				timeout:180000,
				//params : {"classConfId":form.findField('classConfId').getValue()},
				headers :
				{
					'Content-Type' : 'application/json',
				},
			    success : function(response) {
				
					//console.log(response.responseText);
					
					var decodedData=Ext.JSON.decode(response.responseText);
					//console.log(decodedData);
					form.findField('classConfId').setValue(decodedData.classConfId);
					form.findField('label1Text').setValue(decodedData.label1Text);
					form.findField('Label1Pattern').setValue(decodedData.label1Pattern);
					form.findField('label2Text').setValue(decodedData.label2Text);
					form.findField('Label2Pattern').setValue(decodedData.label2Pattern);
					form.findField('label3Text').setValue(decodedData.label3Text);
					form.findField('Label3Pattern').setValue(decodedData.label3Pattern);
					form.findField('label4Text').setValue(decodedData.label4Text);
					form.findField('Label4Pattern').setValue(decodedData.label4Pattern);
					form.findField('levels').setValue(decodedData.levels);
					
					},
					failure : function(response) {
						Ext.Msg.alert(fetch.label.communicationMsg);
						AdminConsole.MyUtil.hideMask();	
					}
			
			   
			   });
				
			},
				
			onSaveClsConfAction:function(btn){
				var form=btn.up('form');
				var formValues = form.getForm().getValues();
				console.log("inside save classification configuration");
				console.log(formValues);
									
				if (!form.getForm().isValid()) {
					console.log("form is not valid");
					return;
				}
				
				var dataSaveClsConf={
						classConfId:formValues.classConfId?formValues.classConfId:0,
						levels:formValues.levels,
						label1Text:formValues.label1Text,
						label2Text:formValues.label2Text,
						label3Text:formValues.label3Text,
						label4Text:formValues.label4Text,
						label1Pattern:formValues.Label1Pattern,
						label2Pattern:formValues.Label2Pattern,
						label3Pattern:formValues.Label3Pattern,
						label4Pattern:formValues.Label4Pattern,
				};
				AdminConsole.MyUtil.showMask(form,fetch.label.saving);
				Ext.Ajax.request({
				url: AdminConsole.Constants.baseURL+'/oem/saveUpdateClassificationConfig.htm',
				method : 'POST',
				timeout:180000,
				params : Ext.JSON.encode(dataSaveClsConf),
				headers :
				{
					'Content-Type' : 'application/json',
				},
			    success : function(response) {
				
					//console.log(response.responseText);
					
					var decodedData=Ext.JSON.decode(response.responseText);
					form.getForm().findField('classConfId').setValue(decodedData.classConfId);
					console.log(decodedData);
					
					Ext.Msg.alert(fetch.label.success, fetch.label.clsConfSavedMsg,function(btn1){
						//if(btn1=='ok'){
							AdminConsole.MyUtil.hideMask();	
							//form.getForm().findField('user').setReadOnly(true);
							
							if(btn.up('window'))
							btn.up('window').close();
					
						});
					
					},
					failure : function(response) {
						Ext.Msg.alert(fetch.label.communicationMsg);
						AdminConsole.MyUtil.hideMask();	
					}
			
			   
			   });
			
			},
			
			
});
Ext.define('AdminConsole.controller.Main', {
    extend: 'Ext.app.Controller'
});

Ext.define('AdminConsole.controller.UserController', {
	extend : 'Ext.app.Controller',
	
	refs : [ 
		{
			ref : 'addUserForm',
			selector : '#addUserForm'
		},
		{
			ref : 'queryUserForm',
			selector : '#queryUserForm'
		},
		{
			ref:'userGrid',
			selector:'#userGrid'
		},
		{
			ref:'queryUserResultGrid',
			selector:'gridpanel#userGrid'
		},
		
		],
	init :function()
	{
		this.control({
			'button[action=searchUser]':{
				click : this.onSearchUser
			},
			'button[action=saveAddUserAction]':{
				click : this.onSaveAddUserAction
			},
			'#userGrid' : {
				itemclick : this.onQueryUserSearchListItemClick
			},
			
			});
			
			
	},
	
	
	onQueryUser:function(){
		var me=this;
		console.log("inside query user");
		var form = me.getQueryUserForm();
		form.getForm().reset();
		var grid = form.up('#queryUser').down('#userGrid');
		grid.setVisible(false);
		Ext.getCmp('index').getLayout().setActiveItem('homePage');
		Ext.getCmp('adminhome').getLayout().setActiveItem('queryUser');
	},
	
	
	OnAddUser:function(){
		console.log("Inside onAddUser");
		var me =this;
		var form = me.getAddUserForm();
		form.getForm().findField('user').setReadOnly(false);
		form.getForm().reset();
		form.down('#services').update('');
		Ext.getCmp('index').getLayout().setActiveItem('homePage');
		Ext.getCmp('adminhome').getLayout().setActiveItem('addUser');
	},
	
	/*OnQueryUser:function(){
		  Ext.getCmp('adminhome').getLayout().setActiveItem('queryUser');
	},*/
	
	 onSearchUser:function(btn){
		console.log('inside search  button');
		var me=this;
		var form = me.getQueryUserForm();
		var grid = form.up('#queryUser').down('#userGrid');
		grid.setVisible(true);
		var store=Ext.getStore('UserStore');
		store.currentPage =1;
		store.load();
   },
	
	onSaveAddUserAction:function(btn){
			console.log("inside save add user");
			var form=btn.up('#addUser').down('form');
			var formValues = form.getForm().getValues();
			console.log(formValues);
			if (!form.getForm().isValid()) {
				console.log("Form is invalid");
				return;
			}
			var dataSaveAddUser = {
			firstName : formValues.firstName,
			lastName: formValues.lastName,
			email:formValues.email,
			contactNum : formValues.contactNo,
			address: formValues.address,
			city:formValues.city,
			country : formValues.country,
			enabled: formValues.enabled?true:false,
			language:formValues.prefLang,
			roleId:formValues.role,
			oemUser:formValues.user
			
		};
	      AdminConsole.MyUtil.showMask(form,fetch.label.saving);
		 // var url;	
          //url=User.json,		  
		 
		  Ext.Ajax.request({
		  //url : 'resources/data/User.json',
			url: AdminConsole.Constants.baseURL+'/oem/saveUser.htm',
			method : 'POST',
			timeout:180000,
			params : Ext.JSON.encode(dataSaveAddUser),
			headers :
			{
				'Content-Type' : 'application/json',
			},
			success : function(response) {
				
					console.log(response.responseText);
					
					var decodedData=Ext.JSON.decode(response.responseText);
					Ext.Msg.alert(fetch.label.success, fetch.label.userSavedMsg,function(btn1){
						//if(btn1=='ok'){
							AdminConsole.MyUtil.hideMask();	
							form.getForm().findField('user').setReadOnly(true);
							if(btn.up('window'))
							btn.up('window').close();
					
						});
					
					
			},
			failure : function(response) {
				Ext.Msg.alert(fetch.label.communicationMsg);
				AdminConsole.MyUtil.hideMask();	
			}
			
		});	
		},
		
		onQueryUserSearchListItemClick:function(me, record, item, index, e, eOpts)
	{
		var controllerRef=this;		
		var detailPanel = Ext.create('AdminConsole.view.AddUser',{
			
			width:800,
			height:350	
		});
		console.log('inside query user search',record);
		//var me=this;
		//var form = me.getQueryUserForm();
		//form.getForm().findField('userId').setValue(decodeData.user[0].userId);
		
		detailPanel.down('#role').getStore().load();
		detailPanel.down('#addUserForm').setTitle(fetch.label.updateUser);
		detailPanel.down('#addUserForm').getForm().findField('user').setReadOnly(true);
		detailPanel.down('#addUserForm').getForm().findField('user').setValue(record.data.oemUser);
		detailPanel.down('form').getForm().findField('firstName').setValue(record.data.firstName);
		detailPanel.down('form').getForm().findField('lastName').setValue(record.data.lastName);
		detailPanel.down('form').getForm().findField('email').setValue(record.data.email);
		detailPanel.down('form').getForm().findField('contactNo').setValue(record.data.contactNum);
		detailPanel.down('form').getForm().findField('address').setValue(record.data.address);
		detailPanel.down('form').getForm().findField('city').setValue(record.data.city);
		detailPanel.down('form').getForm().findField('country').setValue(record.data.country);
		detailPanel.down('form').getForm().findField('enabled').setValue(record.data.enabled);
		detailPanel.down('form').getForm().findField('prefLang').setValue(record.data.language);
		detailPanel.down('form').getForm().findField('role').setValue(record.data.roleId);
		
	     		
		//detailPanel.down('button[action="deleteRole"]').setDisabled(false);
		var popup=controllerRef.createPopUp(true);
		popup.on('beforeremove',function(){
		Ext.getStore('UserStore').reload();
		},this);
		popup.add(detailPanel);
		popup.show();		
	},
	
	createPopUp:function(constrainFlag){
		var window=Ext.create("Ext.Window",{		  
				style:{					
					'font-size':13, 
					'font-family':'Verdana, Geneva, sans-serif', 
					'color':'#000000', 				
					'box-shadow': '0 0 20px rgba(0, 0, 0, 0.3)'
				},				
	
			    closable : true,
			    modal : true,
				autoScroll:true,
				constrain:constrainFlag,				
				layout:{					
					type : 'vbox',
					align : 'center'
				},
			    listeners:{
			    	beforeclose: function( win, eOpts ){
						
						console.log('inside before close');
						win.removeAll(true);
						win.hide();
						return false;
			    	}
				}
		});
		return window;
	},
		
	});